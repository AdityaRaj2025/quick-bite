"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Search, Filter, RefreshCw, AlertTriangle, Keyboard } from "lucide-react"
import { OrderCard } from "./shared/order-card"
import { OrderDetailDrawer } from "./order-detail-drawer"
import { useStaffOrders } from "@/hooks/use-staff-orders"
import { useKeyboardShortcuts } from "@/hooks/use-keyboard-shortcuts"
import type { StaffOrder, OrderStatus } from "@/types/staff"

const statusTabs: { value: OrderStatus; label: string; color: string }[] = [
  { value: "placed", label: "Placed", color: "bg-yellow-500" },
  { value: "acknowledged", label: "Acknowledged", color: "bg-blue-500" },
  { value: "in_kitchen", label: "In Kitchen", color: "bg-orange-500" },
  { value: "ready", label: "Ready", color: "bg-green-500" },
]

export function StaffDashboard() {
  const { ordersByStatus, loading, error, updateOrderStatus, refetch } = useStaffOrders()
  const [activeTab, setActiveTab] = useState<OrderStatus>("placed")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedOrder, setSelectedOrder] = useState<StaffOrder | null>(null)
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [showShortcuts, setShowShortcuts] = useState(false)

  const shortcuts = useKeyboardShortcuts([
    {
      key: "1",
      callback: () => setActiveTab("placed"),
      description: "Switch to Placed tab",
    },
    {
      key: "2",
      callback: () => setActiveTab("acknowledged"),
      description: "Switch to Acknowledged tab",
    },
    {
      key: "3",
      callback: () => setActiveTab("in_kitchen"),
      description: "Switch to In Kitchen tab",
    },
    {
      key: "4",
      callback: () => setActiveTab("ready"),
      description: "Switch to Ready tab",
    },
    {
      key: "r",
      callback: () => refetch(),
      description: "Refresh orders",
    },
    {
      key: "/",
      callback: () => {
        const searchInput = document.querySelector('input[placeholder*="Search"]') as HTMLInputElement
        searchInput?.focus()
      },
      description: "Focus search",
    },
    {
      key: "Escape",
      callback: () => {
        setDrawerOpen(false)
        setShowShortcuts(false)
      },
      description: "Close drawer/shortcuts",
    },
    {
      key: "?",
      callback: () => setShowShortcuts(!showShortcuts),
      description: "Show/hide shortcuts",
    },
  ])

  const handleOrderAction = async (action: string, orderId: string) => {
    const statusMap: Record<string, OrderStatus> = {
      acknowledge: "acknowledged",
      send_to_kitchen: "in_kitchen",
      mark_ready: "ready",
      mark_served: "served",
      cancel: "cancelled",
    }

    const newStatus = statusMap[action]
    if (newStatus) {
      await updateOrderStatus(orderId, newStatus)
    }
  }

  const handleOrderClick = (order: StaffOrder) => {
    setSelectedOrder(order)
    setDrawerOpen(true)
  }

  const filteredOrders = (orders: StaffOrder[]) => {
    if (!searchQuery) return orders
    return orders.filter(
      (order) =>
        order.tableName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        order.tableCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
        order.items.some((item) => item.name.toLowerCase().includes(searchQuery.toLowerCase())),
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <p className="text-lg font-semibold text-gray-900">Failed to load orders</p>
          <p className="text-gray-600 mb-4">{error}</p>
          <Button onClick={refetch}>Try Again</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900">Staff Dashboard</h1>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search orders, tables, items... (Press / to focus)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
            <Button variant="outline" size="sm" onClick={() => setShowShortcuts(!showShortcuts)}>
              <Keyboard className="h-4 w-4 mr-2" />
              Shortcuts
            </Button>
            <Button variant="outline" size="sm" onClick={refetch} disabled={loading}>
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </Button>
          </div>
        </div>
      </div>

      {showShortcuts && (
        <div className="absolute top-20 right-4 bg-white border border-gray-200 rounded-lg shadow-lg p-4 z-50 max-w-sm">
          <h3 className="text-lg font-bold mb-3">Keyboard Shortcuts</h3>
          <div className="space-y-2 text-sm">
            {shortcuts.map((shortcut, index) => (
              <div key={index} className="flex justify-between">
                <kbd className="bg-gray-100 px-2 py-1 rounded text-xs font-mono border">
                  {shortcut.key === "Escape" ? "Esc" : shortcut.key}
                </kbd>
                <span className="text-gray-600">{shortcut.description}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 p-4">
        <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as OrderStatus)} className="h-full">
          <TabsList className="grid w-full grid-cols-4 mb-4">
            {statusTabs.map((tab) => {
              const count = ordersByStatus[tab.value]?.length || 0
              return (
                <TabsTrigger key={tab.value} value={tab.value} className="relative">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${tab.color}`} />
                    {tab.label}
                    {count > 0 && (
                      <Badge variant="secondary" className="ml-1">
                        {count}
                      </Badge>
                    )}
                  </div>
                </TabsTrigger>
              )
            })}
          </TabsList>

          {statusTabs.map((tab) => (
            <TabsContent key={tab.value} value={tab.value} className="h-full">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 h-full overflow-auto">
                {loading ? (
                  // Loading skeletons
                  Array.from({ length: 6 }).map((_, i) => (
                    <div key={i} className="bg-white rounded-lg border p-4 animate-pulse">
                      <div className="h-4 bg-gray-200 rounded mb-3" />
                      <div className="space-y-2">
                        <div className="h-3 bg-gray-200 rounded" />
                        <div className="h-3 bg-gray-200 rounded w-3/4" />
                      </div>
                    </div>
                  ))
                ) : filteredOrders(ordersByStatus[tab.value] || []).length === 0 ? (
                  <div className="col-span-full flex items-center justify-center h-64">
                    <div className="text-center">
                      <div className={`w-16 h-16 rounded-full ${tab.color} opacity-20 mx-auto mb-4`} />
                      <p className="text-lg font-semibold text-gray-900">No {tab.label.toLowerCase()} orders</p>
                      <p className="text-gray-600">
                        {searchQuery ? "Try adjusting your search" : "Orders will appear here when available"}
                      </p>
                    </div>
                  </div>
                ) : (
                  filteredOrders(ordersByStatus[tab.value] || []).map((order) => (
                    <OrderCard
                      key={order.id}
                      order={order}
                      onAction={handleOrderAction}
                      variant="dashboard"
                      className="cursor-pointer hover:shadow-lg transition-shadow"
                      onClick={() => handleOrderClick(order)}
                    />
                  ))
                )}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>

      {/* Order Detail Drawer */}
      <OrderDetailDrawer
        order={selectedOrder}
        open={drawerOpen}
        onOpenChange={setDrawerOpen}
        onAction={handleOrderAction}
      />
    </div>
  )
}
