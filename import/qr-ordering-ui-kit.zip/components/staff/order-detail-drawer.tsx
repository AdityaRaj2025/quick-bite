"use client"

import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Clock, Users, AlertCircle, CheckCircle, XCircle, ArrowRight } from "lucide-react"
import type { StaffOrder, OrderStatus } from "@/types/staff"

interface OrderDetailDrawerProps {
  order: StaffOrder | null
  open: boolean
  onOpenChange: (open: boolean) => void
  onAction: (action: string, orderId: string) => void
}

const statusColors: Record<OrderStatus, string> = {
  placed: "bg-yellow-100 text-yellow-800 border-yellow-200",
  acknowledged: "bg-blue-100 text-blue-800 border-blue-200",
  in_kitchen: "bg-orange-100 text-orange-800 border-orange-200",
  ready: "bg-green-100 text-green-800 border-green-200",
  served: "bg-gray-100 text-gray-800 border-gray-200",
  cancelled: "bg-red-100 text-red-800 border-red-200",
}

const statusLabels: Record<OrderStatus, string> = {
  placed: "Placed",
  acknowledged: "Acknowledged",
  in_kitchen: "In Kitchen",
  ready: "Ready",
  served: "Served",
  cancelled: "Cancelled",
}

export function OrderDetailDrawer({ order, open, onOpenChange, onAction }: OrderDetailDrawerProps) {
  if (!order) return null

  const getTimeElapsed = (timestamp: string) => {
    const elapsed = Date.now() - new Date(timestamp).getTime()
    const minutes = Math.floor(elapsed / 60000)
    return minutes < 60 ? `${minutes} minutes` : `${Math.floor(minutes / 60)}h ${minutes % 60}m`
  }

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  const getActionButtons = () => {
    const buttons = []

    switch (order.status) {
      case "placed":
        buttons.push(
          <Button
            key="acknowledge"
            onClick={() => onAction("acknowledge", order.id)}
            className="bg-saffron hover:bg-saffron/90"
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            Acknowledge Order
          </Button>,
        )
        break
      case "acknowledged":
        buttons.push(
          <Button
            key="kitchen"
            onClick={() => onAction("send_to_kitchen", order.id)}
            className="bg-deep-green hover:bg-deep-green/90"
          >
            <ArrowRight className="h-4 w-4 mr-2" />
            Send to Kitchen
          </Button>,
        )
        break
      case "ready":
        buttons.push(
          <Button
            key="served"
            onClick={() => onAction("mark_served", order.id)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            Mark as Served
          </Button>,
        )
        break
    }

    // Cancel button (available for non-served orders)
    if (!["served", "cancelled"].includes(order.status)) {
      buttons.push(
        <Button key="cancel" variant="destructive" onClick={() => onAction("cancel", order.id)}>
          <XCircle className="h-4 w-4 mr-2" />
          Cancel Order
        </Button>,
      )
    }

    return buttons
  }

  const timeline = [
    { label: "Placed", timestamp: order.placedAt, completed: true },
    { label: "Acknowledged", timestamp: order.acknowledgedAt, completed: !!order.acknowledgedAt },
    { label: "In Kitchen", timestamp: order.kitchenAt, completed: !!order.kitchenAt },
    { label: "Ready", timestamp: order.readyAt, completed: !!order.readyAt },
    { label: "Served", timestamp: order.servedAt, completed: !!order.servedAt },
  ]

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-lg">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-3">
            <Users className="h-5 w-5" />
            {order.tableName}
            <Badge variant="outline" className={statusColors[order.status]}>
              {statusLabels[order.status]}
            </Badge>
          </SheetTitle>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* Order Timeline */}
          <div>
            <h3 className="font-semibold mb-3">Order Timeline</h3>
            <div className="space-y-3">
              {timeline.map((step, index) => (
                <div key={step.label} className="flex items-center gap-3">
                  <div
                    className={`w-3 h-3 rounded-full ${step.completed ? "bg-green-500" : "bg-gray-300"} flex-shrink-0`}
                  />
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className={`text-sm ${step.completed ? "text-gray-900" : "text-gray-500"}`}>
                        {step.label}
                      </span>
                      {step.timestamp && <span className="text-xs text-gray-500">{formatTime(step.timestamp)}</span>}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-3 flex items-center gap-1 text-sm text-gray-600">
              <Clock className="h-4 w-4" />
              Total time: {getTimeElapsed(order.placedAt)}
            </div>
          </div>

          <Separator />

          {/* Order Items */}
          <div>
            <h3 className="font-semibold mb-3">Order Items</h3>
            <div className="space-y-3">
              {order.items.map((item, index) => (
                <div key={index} className="flex justify-between items-start p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <div className="font-medium">
                      {item.quantity}x {item.name}
                    </div>
                    {item.modifiers && item.modifiers.length > 0 && (
                      <div className="text-sm text-gray-600 mt-1">{item.modifiers.join(", ")}</div>
                    )}
                    {item.notes && (
                      <div className="flex items-center gap-1 text-sm text-amber-600 mt-1">
                        <AlertCircle className="h-3 w-3" />
                        {item.notes}
                      </div>
                    )}
                    {item.course && (
                      <Badge variant="outline" className="mt-2 text-xs">
                        {item.course}
                      </Badge>
                    )}
                  </div>
                  <span className="text-sm font-medium">${item.price.toFixed(2)}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Order Notes */}
          {order.notes && (
            <>
              <Separator />
              <div>
                <h3 className="font-semibold mb-3">Order Notes</h3>
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                  <div className="flex items-center gap-2 text-amber-700 mb-2">
                    <AlertCircle className="h-4 w-4" />
                    <span className="font-medium">Special Instructions</span>
                  </div>
                  <p className="text-amber-800">{order.notes}</p>
                </div>
              </div>
            </>
          )}

          <Separator />

          {/* Order Total */}
          <div className="flex justify-between items-center text-lg font-semibold">
            <span>Total</span>
            <span>${order.total.toFixed(2)}</span>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2">{getActionButtons()}</div>
        </div>
      </SheetContent>
    </Sheet>
  )
}
