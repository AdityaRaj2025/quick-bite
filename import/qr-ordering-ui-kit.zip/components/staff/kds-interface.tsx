"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Users, AlertCircle, Volume2, VolumeX, Keyboard } from "lucide-react"
import { useStaffOrders } from "@/hooks/use-staff-orders"
import { useKeyboardShortcuts } from "@/hooks/use-keyboard-shortcuts"
import type { StaffOrder } from "@/types/staff"
import { cn } from "@/lib/utils"

export function KDSInterface() {
  const { ordersByStatus, loading, error, updateOrderStatus, refetch } = useStaffOrders(undefined, 15000)
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [lastOrderCount, setLastOrderCount] = useState(0)
  const [selectedTicketIndex, setSelectedTicketIndex] = useState(0)
  const [showShortcuts, setShowShortcuts] = useState(false)
  const audioRef = useRef<HTMLAudioElement>(null)

  const kdsOrders = [...(ordersByStatus.in_kitchen || []), ...(ordersByStatus.ready || [])]

  const shortcuts = useKeyboardShortcuts([
    {
      key: "ArrowRight",
      callback: () => setSelectedTicketIndex((prev) => Math.min(prev + 1, kdsOrders.length - 1)),
      description: "Select next ticket",
    },
    {
      key: "ArrowLeft",
      callback: () => setSelectedTicketIndex((prev) => Math.max(prev - 1, 0)),
      description: "Select previous ticket",
    },
    {
      key: "Enter",
      callback: () => {
        if (kdsOrders[selectedTicketIndex]) {
          handleBump(kdsOrders[selectedTicketIndex].id)
        }
      },
      description: "Bump selected ticket",
    },
    {
      key: "Backspace",
      callback: () => {
        if (kdsOrders[selectedTicketIndex]) {
          handleUndo(kdsOrders[selectedTicketIndex].id)
        }
      },
      description: "Undo selected ticket",
    },
    {
      key: "r",
      callback: () => refetch(),
      description: "Refresh orders",
    },
    {
      key: "s",
      callback: () => setSoundEnabled(!soundEnabled),
      description: "Toggle sound",
    },
    {
      key: "?",
      callback: () => setShowShortcuts(!showShortcuts),
      description: "Show/hide shortcuts",
    },
  ])

  useEffect(() => {
    if (selectedTicketIndex >= kdsOrders.length) {
      setSelectedTicketIndex(Math.max(0, kdsOrders.length - 1))
    }
  }, [kdsOrders.length, selectedTicketIndex])

  useEffect(() => {
    const currentCount = ordersByStatus.in_kitchen?.length || 0
    if (currentCount > lastOrderCount && soundEnabled && audioRef.current) {
      audioRef.current.play().catch(() => {
        // Ignore audio play errors (browser restrictions)
      })
    }
    setLastOrderCount(currentCount)
  }, [ordersByStatus.in_kitchen?.length, lastOrderCount, soundEnabled])

  const handleBump = async (orderId: string) => {
    const order = kdsOrders.find((o) => o.id === orderId)
    if (order?.status === "in_kitchen") {
      await updateOrderStatus(orderId, "ready")
    } else if (order?.status === "ready") {
      await updateOrderStatus(orderId, "served")
    }
  }

  const handleUndo = async (orderId: string) => {
    const order = kdsOrders.find((o) => o.id === orderId)
    if (order?.status === "ready") {
      await updateOrderStatus(orderId, "in_kitchen")
    }
  }

  const getTimeElapsed = (timestamp: string) => {
    const elapsed = Date.now() - new Date(timestamp).getTime()
    const minutes = Math.floor(elapsed / 60000)
    return minutes
  }

  const getTimeColor = (timestamp: string) => {
    const minutes = getTimeElapsed(timestamp)
    if (minutes > 20) return "text-red-400"
    if (minutes > 15) return "text-yellow-400"
    return "text-green-400"
  }

  const groupItemsByCourse = (items: StaffOrder["items"]) => {
    const grouped = items.reduce(
      (acc, item) => {
        const course = item.course || "main"
        if (!acc[course]) acc[course] = []
        acc[course].push(item)
        return acc
      },
      {} as Record<string, typeof items>,
    )

    const courseOrder = ["appetizer", "main", "dessert", "drink"]
    return courseOrder.reduce(
      (acc, course) => {
        if (grouped[course]) acc[course] = grouped[course]
        return acc
      },
      {} as Record<string, typeof items>,
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="h-16 w-16 text-red-400 mx-auto mb-4" />
          <p className="text-2xl font-bold mb-2">Connection Error</p>
          <p className="text-gray-400 mb-6">{error}</p>
          <Button onClick={refetch} size="lg" className="bg-red-600 hover:bg-red-700">
            Retry Connection
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white relative">
      <audio ref={audioRef} preload="auto">
        <source src="/notification-chime.mp3" type="audio/mpeg" />
      </audio>

      <div className="bg-gray-800 border-b border-gray-700 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-3xl font-bold">Kitchen Display</h1>
            <Badge variant="outline" className="bg-gray-700 text-white border-gray-600 text-lg px-3 py-1">
              {kdsOrders.length} Active Orders
            </Badge>
          </div>
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowShortcuts(!showShortcuts)}
              className="text-white hover:bg-gray-700"
            >
              <Keyboard className="h-5 w-5 mr-2" />
              Shortcuts
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="text-white hover:bg-gray-700"
            >
              {soundEnabled ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
              {soundEnabled ? "Sound On" : "Sound Off"}
            </Button>
            <div className="text-right">
              <div className="text-2xl font-mono">{new Date().toLocaleTimeString()}</div>
              <div className="text-sm text-gray-400">{new Date().toLocaleDateString()}</div>
            </div>
          </div>
        </div>
      </div>

      {showShortcuts && (
        <div className="absolute top-20 right-4 bg-gray-800 border border-gray-600 rounded-lg p-4 z-50 max-w-sm">
          <h3 className="text-lg font-bold mb-3">Keyboard Shortcuts</h3>
          <div className="space-y-2 text-sm">
            {shortcuts.map((shortcut, index) => (
              <div key={index} className="flex justify-between">
                <kbd className="bg-gray-700 px-2 py-1 rounded text-xs font-mono">
                  {shortcut.key === "ArrowRight"
                    ? "→"
                    : shortcut.key === "ArrowLeft"
                      ? "←"
                      : shortcut.key === "Enter"
                        ? "↵"
                        : shortcut.key === "Backspace"
                          ? "⌫"
                          : shortcut.key}
                </kbd>
                <span className="text-gray-300">{shortcut.description}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="p-6">
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-gray-800 rounded-lg p-6 animate-pulse">
                <div className="h-8 bg-gray-700 rounded mb-4" />
                <div className="space-y-3">
                  <div className="h-4 bg-gray-700 rounded" />
                  <div className="h-4 bg-gray-700 rounded w-3/4" />
                  <div className="h-4 bg-gray-700 rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : kdsOrders.length === 0 ? (
          <div className="flex items-center justify-center h-96">
            <div className="text-center">
              <div className="w-24 h-24 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="h-12 w-12 text-gray-500" />
              </div>
              <p className="text-3xl font-bold text-gray-400 mb-2">No Active Orders</p>
              <p className="text-xl text-gray-500">Kitchen is all caught up!</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {kdsOrders.map((order, index) => (
              <KDSTicket
                key={order.id}
                order={order}
                onBump={() => handleBump(order.id)}
                onUndo={() => handleUndo(order.id)}
                isSelected={index === selectedTicketIndex}
                onClick={() => setSelectedTicketIndex(index)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

interface KDSTicketProps {
  order: StaffOrder
  onBump: () => void
  onUndo: () => void
  isSelected?: boolean
  onClick?: () => void
}

function KDSTicket({ order, onBump, onUndo, isSelected, onClick }: KDSTicketProps) {
  const getTimeElapsed = (timestamp: string) => {
    const elapsed = Date.now() - new Date(timestamp).getTime()
    const minutes = Math.floor(elapsed / 60000)
    return minutes
  }

  const getTimeColor = (timestamp: string) => {
    const minutes = getTimeElapsed(timestamp)
    if (minutes > 20) return "text-red-400"
    if (minutes > 15) return "text-yellow-400"
    return "text-green-400"
  }

  const groupItemsByCourse = (items: StaffOrder["items"]) => {
    const grouped = items.reduce(
      (acc, item) => {
        const course = item.course || "main"
        if (!acc[course]) acc[course] = []
        acc[course].push(item)
        return acc
      },
      {} as Record<string, typeof items>,
    )

    const courseOrder = ["appetizer", "main", "dessert", "drink"]
    return courseOrder.reduce(
      (acc, course) => {
        if (grouped[course]) acc[course] = grouped[course]
        return acc
      },
      {} as Record<string, typeof items>,
    )
  }

  const groupedItems = groupItemsByCourse(order.items)
  const timeElapsed = getTimeElapsed(order.kitchenAt || order.placedAt)

  return (
    <div
      className={cn(
        "bg-gray-800 border-2 rounded-lg p-6 transition-all duration-200 cursor-pointer",
        order.status === "ready" ? "border-green-500 bg-green-900/20" : "border-orange-500 bg-orange-900/20",
        timeElapsed > 20 && "border-red-500 bg-red-900/20 animate-pulse",
        isSelected && "ring-4 ring-blue-500 ring-opacity-50",
      )}
      onClick={onClick}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <Users className="h-6 w-6 text-gray-400" />
          <span className="text-2xl font-bold">{order.tableName}</span>
          <Badge
            variant="outline"
            className={cn(
              "text-lg px-3 py-1",
              order.status === "ready"
                ? "bg-green-600 text-white border-green-500"
                : "bg-orange-600 text-white border-orange-500",
            )}
          >
            {order.status === "ready" ? "READY" : "COOKING"}
          </Badge>
        </div>
        <div className={cn("text-right", getTimeColor(order.kitchenAt || order.placedAt))}>
          <div className="text-2xl font-mono font-bold">{timeElapsed}m</div>
          <div className="text-sm">
            {new Date(order.kitchenAt || order.placedAt).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </div>
        </div>
      </div>

      <div className="space-y-4 mb-6">
        {Object.entries(groupedItems).map(([course, items]) => (
          <div key={course}>
            <h4 className="text-lg font-semibold text-gray-300 mb-2 uppercase tracking-wide">{course}</h4>
            <div className="space-y-2">
              {items.map((item, index) => (
                <div key={index} className="bg-gray-700 rounded p-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xl font-bold text-white">
                      {item.quantity}x {item.name}
                    </span>
                  </div>
                  {item.modifiers && item.modifiers.length > 0 && (
                    <div className="text-yellow-300 text-lg font-medium">{item.modifiers.join(", ")}</div>
                  )}
                  {item.notes && (
                    <div className="flex items-center gap-2 text-red-300 text-lg font-medium mt-2">
                      <AlertCircle className="h-5 w-5" />
                      {item.notes}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {order.notes && (
        <div className="bg-red-900/30 border border-red-500 rounded p-3 mb-6">
          <div className="flex items-center gap-2 text-red-300 mb-2">
            <AlertCircle className="h-5 w-5" />
            <span className="font-bold text-lg">SPECIAL INSTRUCTIONS</span>
          </div>
          <p className="text-red-200 text-lg font-medium">{order.notes}</p>
        </div>
      )}

      <div className="flex gap-3">
        <Button
          onClick={onBump}
          size="lg"
          className={cn(
            "flex-1 text-xl font-bold py-4",
            order.status === "ready"
              ? "bg-blue-600 hover:bg-blue-700 text-white"
              : "bg-green-600 hover:bg-green-700 text-white",
          )}
        >
          {order.status === "ready" ? "SERVE" : "READY"}
        </Button>
        <Button
          onClick={onUndo}
          variant="outline"
          size="lg"
          className="px-6 text-lg font-bold py-4 border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent"
        >
          UNDO
        </Button>
      </div>
    </div>
  )
}
