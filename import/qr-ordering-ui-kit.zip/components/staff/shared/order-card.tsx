"use client"

import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Clock, Users, AlertCircle } from "lucide-react"
import type { StaffOrder, OrderStatus } from "@/types/staff"
import { cn } from "@/lib/utils"

interface OrderCardProps {
  order: StaffOrder
  onAction?: (action: string, orderId: string) => void
  variant?: "dashboard" | "kds"
  className?: string
}

const statusColors: Record<OrderStatus, string> = {
  placed: "bg-yellow-100 text-yellow-800 border-yellow-200",
  acknowledged: "bg-blue-100 text-blue-800 border-blue-200",
  in_kitchen: "bg-orange-100 text-orange-800 border-orange-200",
  ready: "bg-green-100 text-green-800 border-green-200",
  served: "bg-gray-100 text-gray-800 border-gray-200",
  cancelled: "bg-red-100 text-red-800 border-red-200",
}

const statusLabels: Record<OrderStatus, string> = {
  placed: "Placed",
  acknowledged: "Acknowledged",
  in_kitchen: "In Kitchen",
  ready: "Ready",
  served: "Served",
  cancelled: "Cancelled",
}

export function OrderCard({ order, onAction, variant = "dashboard", className }: OrderCardProps) {
  const getTimeElapsed = (timestamp: string) => {
    const elapsed = Date.now() - new Date(timestamp).getTime()
    const minutes = Math.floor(elapsed / 60000)
    return minutes < 60 ? `${minutes}m` : `${Math.floor(minutes / 60)}h ${minutes % 60}m`
  }

  const getActionButtons = () => {
    switch (order.status) {
      case "placed":
        return (
          <Button
            size="sm"
            onClick={() => onAction?.("acknowledge", order.id)}
            className="bg-saffron hover:bg-saffron/90"
          >
            Acknowledge
          </Button>
        )
      case "acknowledged":
        return (
          <Button
            size="sm"
            onClick={() => onAction?.("send_to_kitchen", order.id)}
            className="bg-deep-green hover:bg-deep-green/90"
          >
            Send to Kitchen
          </Button>
        )
      case "in_kitchen":
        return variant === "kds" ? (
          <Button
            size="sm"
            onClick={() => onAction?.("mark_ready", order.id)}
            className="bg-green-600 hover:bg-green-700"
          >
            Mark Ready
          </Button>
        ) : null
      case "ready":
        return variant === "dashboard" ? (
          <Button
            size="sm"
            onClick={() => onAction?.("mark_served", order.id)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            Mark Served
          </Button>
        ) : null
      default:
        return null
    }
  }

  return (
    <Card
      className={cn(
        "transition-all duration-200 hover:shadow-md",
        variant === "kds" && "bg-gray-900 text-white border-gray-700",
        className,
      )}
    >
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-muted-foreground" />
            <span className="font-semibold">{order.tableName}</span>
            <Badge variant="outline" className={statusColors[order.status]}>
              {statusLabels[order.status]}
            </Badge>
          </div>
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Clock className="h-3 w-3" />
            {getTimeElapsed(order.placedAt)}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-3">
        <div className="space-y-2">
          {order.items.map((item, index) => (
            <div
              key={index}
              className={cn("flex justify-between items-start text-sm", variant === "kds" && "text-gray-100")}
            >
              <div className="flex-1">
                <span className="font-medium">
                  {item.quantity}x {item.name}
                </span>
                {item.modifiers && item.modifiers.length > 0 && (
                  <div className="text-xs text-muted-foreground mt-1">{item.modifiers.join(", ")}</div>
                )}
                {item.notes && (
                  <div className="flex items-center gap-1 text-xs text-amber-600 mt-1">
                    <AlertCircle className="h-3 w-3" />
                    {item.notes}
                  </div>
                )}
              </div>
              {variant === "dashboard" && <span className="text-muted-foreground">${item.price.toFixed(2)}</span>}
            </div>
          ))}
        </div>

        {order.notes && (
          <div className="p-2 bg-amber-50 border border-amber-200 rounded text-sm">
            <div className="flex items-center gap-1 text-amber-700">
              <AlertCircle className="h-3 w-3" />
              <span className="font-medium">Order Notes:</span>
            </div>
            <p className="text-amber-800 mt-1">{order.notes}</p>
          </div>
        )}

        <div className="flex items-center justify-between pt-2">
          {variant === "dashboard" && <span className="font-semibold">Total: ${order.total.toFixed(2)}</span>}
          <div className="flex gap-2 ml-auto">{getActionButtons()}</div>
        </div>
      </CardContent>
    </Card>
  )
}
