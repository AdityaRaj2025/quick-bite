"use client"

import React from "react"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Search, Download, Eye, RefreshCw, AlertTriangle, Info, AlertCircle, XCircle } from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"
import type { LogEntry } from "@/types/operator"

// Mock logs data
const mockLogs: LogEntry[] = [
  {
    id: "log-1",
    timestamp: "2024-01-15T14:32:15Z",
    service: "auth",
    tenantId: "tenant-1",
    severity: "error",
    message: "Failed authentication attempt from IP 192.168.1.100",
    details: {
      ip: "192.168.1.100",
      userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      attemptCount: 3,
      lockoutDuration: "15 minutes",
    },
  },
  {
    id: "log-2",
    timestamp: "2024-01-15T14:30:45Z",
    service: "order",
    tenantId: "tenant-2",
    severity: "warning",
    message: "Order processing took longer than expected",
    details: {
      orderId: "ord-12345",
      processingTime: "3.2s",
      threshold: "2.0s",
      queueSize: 15,
    },
  },
  {
    id: "log-3",
    timestamp: "2024-01-15T14:28:30Z",
    service: "menu",
    tenantId: "tenant-3",
    severity: "info",
    message: "Menu items updated successfully",
    details: {
      itemsUpdated: 12,
      categoriesAffected: 3,
      updateDuration: "0.8s",
    },
  },
  {
    id: "log-4",
    timestamp: "2024-01-15T14:25:12Z",
    service: "print",
    tenantId: "tenant-1",
    severity: "critical",
    message: "Print service connection lost to kitchen printer",
    details: {
      printerId: "kitchen-printer-01",
      lastSuccessfulPrint: "2024-01-15T14:20:00Z",
      errorCode: "CONN_TIMEOUT",
      retryAttempts: 5,
    },
  },
  {
    id: "log-5",
    timestamp: "2024-01-15T14:22:08Z",
    service: "qr",
    tenantId: "tenant-2",
    severity: "warning",
    message: "QR code generation rate limit approaching",
    details: {
      currentRate: "45 requests/minute",
      limit: "50 requests/minute",
      remainingQuota: 5,
    },
  },
  {
    id: "log-6",
    timestamp: "2024-01-15T14:20:33Z",
    service: "auth",
    tenantId: "system",
    severity: "info",
    message: "System health check completed successfully",
    details: {
      servicesChecked: 5,
      allHealthy: true,
      checkDuration: "1.2s",
    },
  },
  {
    id: "log-7",
    timestamp: "2024-01-15T14:18:45Z",
    service: "order",
    tenantId: "tenant-3",
    severity: "error",
    message: "Database connection pool exhausted",
    details: {
      activeConnections: 20,
      maxConnections: 20,
      queuedRequests: 8,
      avgConnectionTime: "2.5s",
    },
  },
]

const mockTenants = [
  { id: "tenant-1", name: "Sakura Sushi" },
  { id: "tenant-2", name: "Pizza Corner" },
  { id: "tenant-3", name: "The Gourmet Kitchen" },
  { id: "system", name: "System" },
]

const severityColors = {
  info: "bg-blue-100 text-blue-800",
  warning: "bg-yellow-100 text-yellow-800",
  error: "bg-orange-100 text-orange-800",
  critical: "bg-red-100 text-red-800",
}

const severityIcons = {
  info: Info,
  warning: AlertTriangle,
  error: AlertCircle,
  critical: XCircle,
}

export function LogsViewer() {
  const [searchTerm, setSearchTerm] = useState("")
  const [severityFilter, setSeverityFilter] = useState<string>("all")
  const [serviceFilter, setServiceFilter] = useState<string>("all")
  const [tenantFilter, setTenantFilter] = useState<string>("all")
  const [selectedLog, setSelectedLog] = useState<LogEntry | null>(null)
  const [logs, setLogs] = useState<LogEntry[]>(mockLogs)
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date())

  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      const tenant = mockTenants.find((t) => t.id === log.tenantId)
      const tenantName = tenant?.name || ""

      const matchesSearch =
        log.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.service.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tenantName.toLowerCase().includes(searchTerm.toLowerCase())

      const matchesSeverity = severityFilter === "all" || log.severity === severityFilter
      const matchesService = serviceFilter === "all" || log.service === serviceFilter
      const matchesTenant = tenantFilter === "all" || log.tenantId === tenantFilter

      return matchesSearch && matchesSeverity && matchesService && matchesTenant
    })
  }, [logs, searchTerm, severityFilter, serviceFilter, tenantFilter])

  const logStats = useMemo(() => {
    const totalLogs = filteredLogs.length
    const criticalCount = filteredLogs.filter((log) => log.severity === "critical").length
    const errorCount = filteredLogs.filter((log) => log.severity === "error").length
    const warningCount = filteredLogs.filter((log) => log.severity === "warning").length
    const infoCount = filteredLogs.filter((log) => log.severity === "info").length

    return {
      totalLogs,
      criticalCount,
      errorCount,
      warningCount,
      infoCount,
    }
  }, [filteredLogs])

  const refreshLogs = () => {
    // Simulate data refresh
    setLastRefresh(new Date())
    // In a real app, this would fetch fresh logs from the API
  }

  const exportToCSV = () => {
    const headers = ["Timestamp", "Service", "Tenant", "Severity", "Message"]
    const csvContent = [
      headers.join(","),
      ...filteredLogs.map((log) => {
        const tenant = mockTenants.find((t) => t.id === log.tenantId)
        return [
          format(new Date(log.timestamp), "yyyy-MM-dd HH:mm:ss"),
          log.service,
          tenant?.name || "Unknown",
          log.severity,
          `"${log.message}"`,
        ].join(",")
      }),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `system-logs-${format(new Date(), "yyyy-MM-dd")}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  const formatTimestamp = (timestamp: string) => {
    return format(new Date(timestamp), "MMM dd, HH:mm:ss")
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">System Logs</h1>
          <p className="text-sm text-gray-600">Monitor system events and troubleshoot issues</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="text-sm text-gray-500">Last updated: {lastRefresh.toLocaleTimeString()}</div>
          <Button onClick={refreshLogs} variant="outline" size="sm">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Button onClick={exportToCSV} variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
        </div>
      </div>

      {/* Log Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">{logStats.totalLogs}</div>
              <div className="text-sm text-gray-600">Total Logs</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{logStats.criticalCount}</div>
              <div className="text-sm text-gray-600">Critical</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">{logStats.errorCount}</div>
              <div className="text-sm text-gray-600">Errors</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">{logStats.warningCount}</div>
              <div className="text-sm text-gray-600">Warnings</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{logStats.infoCount}</div>
              <div className="text-sm text-gray-600">Info</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search logs..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={severityFilter} onValueChange={setSeverityFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Severity" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Severities</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
                <SelectItem value="error">Error</SelectItem>
                <SelectItem value="warning">Warning</SelectItem>
                <SelectItem value="info">Info</SelectItem>
              </SelectContent>
            </Select>
            <Select value={serviceFilter} onValueChange={setServiceFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Service" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Services</SelectItem>
                <SelectItem value="qr">QR Service</SelectItem>
                <SelectItem value="menu">Menu Service</SelectItem>
                <SelectItem value="order">Order Service</SelectItem>
                <SelectItem value="print">Print Service</SelectItem>
                <SelectItem value="auth">Auth Service</SelectItem>
              </SelectContent>
            </Select>
            <Select value={tenantFilter} onValueChange={setTenantFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Tenant" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Tenants</SelectItem>
                {mockTenants.map((tenant) => (
                  <SelectItem key={tenant.id} value={tenant.id}>
                    {tenant.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Logs Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Timestamp</TableHead>
                <TableHead>Service</TableHead>
                <TableHead>Tenant</TableHead>
                <TableHead>Severity</TableHead>
                <TableHead>Message</TableHead>
                <TableHead className="w-[50px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLogs.map((log) => {
                const tenant = mockTenants.find((t) => t.id === log.tenantId)
                const SeverityIcon = severityIcons[log.severity]

                return (
                  <TableRow key={log.id} className="cursor-pointer hover:bg-gray-50">
                    <TableCell className="text-sm font-mono">{formatTimestamp(log.timestamp)}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="capitalize">
                        {log.service}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm">{tenant?.name || "Unknown"}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <SeverityIcon className="w-4 h-4" />
                        <Badge className={cn("capitalize", severityColors[log.severity])}>{log.severity}</Badge>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm max-w-md truncate">{log.message}</TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm" onClick={() => setSelectedLog(log)}>
                        <Eye className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Log Detail Dialog */}
      {selectedLog && (
        <Dialog open={!!selectedLog} onOpenChange={() => setSelectedLog(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                {React.createElement(severityIcons[selectedLog.severity], { className: "w-5 h-5" })}
                Log Details
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-500">Timestamp</div>
                  <div className="text-sm font-mono">{format(new Date(selectedLog.timestamp), "PPpp")}</div>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-500">Service</div>
                  <Badge variant="outline" className="capitalize">
                    {selectedLog.service}
                  </Badge>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-500">Tenant</div>
                  <div className="text-sm">
                    {mockTenants.find((t) => t.id === selectedLog.tenantId)?.name || "Unknown"}
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-500">Severity</div>
                  <Badge className={cn("capitalize", severityColors[selectedLog.severity])}>
                    {selectedLog.severity}
                  </Badge>
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-sm font-medium text-gray-500">Message</div>
                <div className="text-sm p-3 bg-gray-50 rounded-md">{selectedLog.message}</div>
              </div>

              {selectedLog.details && (
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-500">Details</div>
                  <ScrollArea className="h-[200px] w-full border rounded-md">
                    <pre className="text-xs p-3">{JSON.stringify(selectedLog.details, null, 2)}</pre>
                  </ScrollArea>
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
