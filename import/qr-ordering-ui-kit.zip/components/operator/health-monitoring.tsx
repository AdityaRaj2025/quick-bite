"use client"

import React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  CheckCircle,
  AlertTriangle,
  XCircle,
  Activity,
  Clock,
  Shield,
  Printer,
  QrCode,
  ChefHat,
  Settings,
  RefreshCw,
} from "lucide-react"
import { cn } from "@/lib/utils"
import type { HealthStatus, LogEntry } from "@/types/operator"

// Mock health data
const mockHealthData: HealthStatus[] = [
  {
    service: "qr",
    status: "healthy",
    uptime: 99.9,
    latency: 145,
    lastIncident: "2024-01-10T14:30:00Z",
    alertThresholds: {
      latency: 500,
      errorRate: 5,
      uptime: 99.5,
    },
  },
  {
    service: "menu",
    status: "healthy",
    uptime: 99.8,
    latency: 120,
    lastIncident: "2024-01-08T09:15:00Z",
    alertThresholds: {
      latency: 300,
      errorRate: 3,
      uptime: 99.0,
    },
  },
  {
    service: "order",
    status: "warning",
    uptime: 99.2,
    latency: 380,
    lastIncident: "2024-01-15T11:20:00Z",
    alertThresholds: {
      latency: 400,
      errorRate: 5,
      uptime: 99.0,
    },
  },
  {
    service: "print",
    status: "healthy",
    uptime: 98.9,
    latency: 200,
    lastIncident: "2024-01-12T16:45:00Z",
    alertThresholds: {
      latency: 1000,
      errorRate: 10,
      uptime: 98.0,
    },
  },
  {
    service: "auth",
    status: "critical",
    uptime: 97.8,
    latency: 850,
    lastIncident: "2024-01-15T13:10:00Z",
    alertThresholds: {
      latency: 500,
      errorRate: 2,
      uptime: 99.5,
    },
  },
]

// Mock incidents data
const mockIncidents: LogEntry[] = [
  {
    id: "inc-1",
    timestamp: "2024-01-15T13:10:00Z",
    service: "auth",
    tenantId: "system",
    severity: "critical",
    message: "Authentication service experiencing high latency",
    details: {
      latency: "850ms",
      errorRate: "3.2%",
      affectedTenants: 15,
    },
  },
  {
    id: "inc-2",
    timestamp: "2024-01-15T11:20:00Z",
    service: "order",
    tenantId: "system",
    severity: "warning",
    message: "Order processing service latency above threshold",
    details: {
      latency: "380ms",
      threshold: "400ms",
      affectedTenants: 8,
    },
  },
  {
    id: "inc-3",
    timestamp: "2024-01-12T16:45:00Z",
    service: "print",
    tenantId: "system",
    severity: "warning",
    message: "Print service intermittent connectivity issues",
    details: {
      uptime: "98.9%",
      duration: "45 minutes",
    },
  },
]

const serviceIcons = {
  qr: QrCode,
  menu: ChefHat,
  order: Activity,
  print: Printer,
  auth: Shield,
}

const statusColors = {
  healthy: {
    bg: "bg-green-100",
    text: "text-green-800",
    border: "border-green-200",
    icon: CheckCircle,
    iconColor: "text-green-600",
  },
  warning: {
    bg: "bg-yellow-100",
    text: "text-yellow-800",
    border: "border-yellow-200",
    icon: AlertTriangle,
    iconColor: "text-yellow-600",
  },
  critical: {
    bg: "bg-red-100",
    text: "text-red-800",
    border: "border-red-200",
    icon: XCircle,
    iconColor: "text-red-600",
  },
}

const severityColors = {
  info: "bg-blue-100 text-blue-800",
  warning: "bg-yellow-100 text-yellow-800",
  error: "bg-orange-100 text-orange-800",
  critical: "bg-red-100 text-red-800",
}

export function HealthMonitoring() {
  const [healthData, setHealthData] = useState<HealthStatus[]>(mockHealthData)
  const [incidents, setIncidents] = useState<LogEntry[]>(mockIncidents)
  const [severityFilter, setSeverityFilter] = useState<string>("all")
  const [serviceFilter, setServiceFilter] = useState<string>("all")
  const [selectedService, setSelectedService] = useState<HealthStatus | null>(null)
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date())

  const refreshData = () => {
    // Simulate data refresh
    setLastRefresh(new Date())
    // In a real app, this would fetch fresh data from the API
  }

  useEffect(() => {
    const interval = setInterval(refreshData, 30000) // Refresh every 30 seconds
    return () => clearInterval(interval)
  }, [])

  const filteredIncidents = incidents.filter((incident) => {
    const matchesSeverity = severityFilter === "all" || incident.severity === severityFilter
    const matchesService = serviceFilter === "all" || incident.service === serviceFilter
    return matchesSeverity && matchesService
  })

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString()
  }

  const getOverallHealth = () => {
    const criticalCount = healthData.filter((s) => s.status === "critical").length
    const warningCount = healthData.filter((s) => s.status === "warning").length

    if (criticalCount > 0) return "critical"
    if (warningCount > 0) return "warning"
    return "healthy"
  }

  const overallHealth = getOverallHealth()
  const overallHealthConfig = statusColors[overallHealth]

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">System Health</h1>
          <p className="text-sm text-gray-600">Monitor microservice health and system performance</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="text-sm text-gray-500">Last updated: {lastRefresh.toLocaleTimeString()}</div>
          <Button onClick={refreshData} variant="outline" size="sm">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Overall Health Status */}
      <Card className={cn("border-2", overallHealthConfig.border)}>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={cn("w-12 h-12 rounded-lg flex items-center justify-center", overallHealthConfig.bg)}>
                <overallHealthConfig.icon className={cn("w-6 h-6", overallHealthConfig.iconColor)} />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-gray-900">System Status</h2>
                <Badge className={cn("capitalize", overallHealthConfig.bg, overallHealthConfig.text)}>
                  {overallHealth}
                </Badge>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-500">Services</div>
              <div className="text-2xl font-bold text-gray-900">{healthData.length}</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="services" className="space-y-6">
        <TabsList>
          <TabsTrigger value="services">Services</TabsTrigger>
          <TabsTrigger value="incidents">Incidents</TabsTrigger>
          <TabsTrigger value="alerts">Alert Thresholds</TabsTrigger>
        </TabsList>

        <TabsContent value="services" className="space-y-6">
          {/* Service Health Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {healthData.map((service) => {
              const ServiceIcon = serviceIcons[service.service]
              const statusConfig = statusColors[service.status]
              const StatusIcon = statusConfig.icon

              return (
                <Card
                  key={service.service}
                  className={cn("cursor-pointer transition-all hover:shadow-md border-2", statusConfig.border)}
                  onClick={() => setSelectedService(service)}
                >
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                          <ServiceIcon className="w-5 h-5 text-gray-600" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900 capitalize">{service.service} Service</h3>
                          <Badge className={cn("capitalize", statusConfig.bg, statusConfig.text)}>
                            {service.status}
                          </Badge>
                        </div>
                      </div>
                      <StatusIcon className={cn("w-6 h-6", statusConfig.iconColor)} />
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Activity className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-600">Uptime</span>
                        </div>
                        <span className="text-sm font-medium">{service.uptime}%</span>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-600">Latency</span>
                        </div>
                        <span className="text-sm font-medium">{service.latency}ms</span>
                      </div>

                      {service.lastIncident && (
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <AlertTriangle className="w-4 h-4 text-gray-400" />
                            <span className="text-sm text-gray-600">Last Incident</span>
                          </div>
                          <span className="text-sm font-medium">
                            {new Date(service.lastIncident).toLocaleDateString()}
                          </span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="incidents" className="space-y-6">
          {/* Incidents Filters */}
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-col sm:flex-row gap-4">
                <Select value={severityFilter} onValueChange={setSeverityFilter}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Severity" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Severities</SelectItem>
                    <SelectItem value="info">Info</SelectItem>
                    <SelectItem value="warning">Warning</SelectItem>
                    <SelectItem value="error">Error</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={serviceFilter} onValueChange={setServiceFilter}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Service" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Services</SelectItem>
                    <SelectItem value="qr">QR Service</SelectItem>
                    <SelectItem value="menu">Menu Service</SelectItem>
                    <SelectItem value="order">Order Service</SelectItem>
                    <SelectItem value="print">Print Service</SelectItem>
                    <SelectItem value="auth">Auth Service</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Incidents Table */}
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>Service</TableHead>
                    <TableHead>Severity</TableHead>
                    <TableHead>Message</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredIncidents.map((incident) => (
                    <TableRow key={incident.id}>
                      <TableCell className="text-sm">{formatTimestamp(incident.timestamp)}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="capitalize">
                          {incident.service}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={cn("capitalize", severityColors[incident.severity])}>
                          {incident.severity}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">{incident.message}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-6">
          {/* Alert Thresholds */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {healthData.map((service) => {
              const ServiceIcon = serviceIcons[service.service]

              return (
                <Card key={service.service}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <ServiceIcon className="w-5 h-5" />
                      {service.service.charAt(0).toUpperCase() + service.service.slice(1)} Service
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor={`${service.service}-latency`}>Latency Threshold (ms)</Label>
                      <Input
                        id={`${service.service}-latency`}
                        type="number"
                        defaultValue={service.alertThresholds.latency}
                        className="w-full"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor={`${service.service}-error`}>Error Rate Threshold (%)</Label>
                      <Input
                        id={`${service.service}-error`}
                        type="number"
                        defaultValue={service.alertThresholds.errorRate}
                        className="w-full"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor={`${service.service}-uptime`}>Uptime Threshold (%)</Label>
                      <Input
                        id={`${service.service}-uptime`}
                        type="number"
                        step="0.1"
                        defaultValue={service.alertThresholds.uptime}
                        className="w-full"
                      />
                    </div>
                    <Button size="sm" className="w-full">
                      <Settings className="w-4 h-4 mr-2" />
                      Update Thresholds
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>
      </Tabs>

      {/* Service Detail Dialog */}
      {selectedService && (
        <Dialog open={!!selectedService} onOpenChange={() => setSelectedService(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                {React.createElement(serviceIcons[selectedService.service], { className: "w-5 h-5" })}
                {selectedService.service.charAt(0).toUpperCase() + selectedService.service.slice(1)} Service Details
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-500">Status</div>
                  <Badge
                    className={cn(
                      "capitalize",
                      statusColors[selectedService.status].bg,
                      statusColors[selectedService.status].text,
                    )}
                  >
                    {selectedService.status}
                  </Badge>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-500">Uptime</div>
                  <div className="text-lg font-semibold">{selectedService.uptime}%</div>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-500">Current Latency</div>
                  <div className="text-lg font-semibold">{selectedService.latency}ms</div>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-500">Latency Threshold</div>
                  <div className="text-lg font-semibold">{selectedService.alertThresholds.latency}ms</div>
                </div>
              </div>

              {selectedService.lastIncident && (
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-500">Last Incident</div>
                  <div className="text-sm">{formatTimestamp(selectedService.lastIncident)}</div>
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
