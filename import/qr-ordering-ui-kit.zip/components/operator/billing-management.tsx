"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Line, LineChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Bar, BarChart } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Download, DollarSign, AlertCircle, CheckCircle, Clock, Search } from "lucide-react"
import { format, subMonths } from "date-fns"
import type { DateRange } from "react-day-picker"
import { cn } from "@/lib/utils"
import type { BillingRecord } from "@/types/operator"

// Mock billing data
const mockBillingRecords: BillingRecord[] = [
  {
    tenantId: "tenant-1",
    period: "2024-01",
    amount: 99,
    status: "paid",
    dueDate: "2024-02-01T00:00:00Z",
    items: [
      { description: "Professional Plan", quantity: 1, unitPrice: 99, total: 99 },
      { description: "Additional Seats", quantity: 2, unitPrice: 15, total: 30 },
      { description: "Extra Storage (100MB)", quantity: 1, unitPrice: 10, total: 10 },
    ],
  },
  {
    tenantId: "tenant-2",
    period: "2024-01",
    amount: 29,
    status: "pending",
    dueDate: "2024-02-01T00:00:00Z",
    items: [{ description: "Starter Plan", quantity: 1, unitPrice: 29, total: 29 }],
  },
  {
    tenantId: "tenant-3",
    period: "2024-01",
    amount: 299,
    status: "paid",
    dueDate: "2024-02-01T00:00:00Z",
    items: [
      { description: "Enterprise Plan", quantity: 1, unitPrice: 299, total: 299 },
      { description: "Premium Support", quantity: 1, unitPrice: 50, total: 50 },
    ],
  },
  {
    tenantId: "tenant-1",
    period: "2023-12",
    amount: 99,
    status: "paid",
    dueDate: "2024-01-01T00:00:00Z",
    items: [{ description: "Professional Plan", quantity: 1, unitPrice: 99, total: 99 }],
  },
  {
    tenantId: "tenant-2",
    period: "2023-12",
    amount: 29,
    status: "overdue",
    dueDate: "2024-01-01T00:00:00Z",
    items: [{ description: "Starter Plan", quantity: 1, unitPrice: 29, total: 29 }],
  },
]

const mockTenants = [
  { id: "tenant-1", name: "Sakura Sushi" },
  { id: "tenant-2", name: "Pizza Corner" },
  { id: "tenant-3", name: "The Gourmet Kitchen" },
]

// Generate mock revenue data
const generateRevenueData = (months: number) => {
  const data = []
  for (let i = months - 1; i >= 0; i--) {
    const date = subMonths(new Date(), i)
    const baseRevenue = 15000 + Math.random() * 5000
    data.push({
      month: format(date, "MMM yyyy"),
      revenue: Math.floor(baseRevenue),
      subscriptions: Math.floor(45 + Math.random() * 15),
    })
  }
  return data
}

const paymentStatusColors = {
  paid: "bg-green-100 text-green-800",
  pending: "bg-yellow-100 text-yellow-800",
  overdue: "bg-red-100 text-red-800",
  failed: "bg-red-100 text-red-800",
}

const paymentStatusIcons = {
  paid: CheckCircle,
  pending: Clock,
  overdue: AlertCircle,
  failed: AlertCircle,
}

export function BillingManagement() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [tenantFilter, setTenantFilter] = useState<string>("all")
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: subMonths(new Date(), 6),
    to: new Date(),
  })

  const revenueData = useMemo(() => generateRevenueData(12), [])

  const filteredRecords = useMemo(() => {
    return mockBillingRecords.filter((record) => {
      const tenant = mockTenants.find((t) => t.id === record.tenantId)
      const tenantName = tenant?.name || ""

      const matchesSearch =
        tenantName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        record.period.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesStatus = statusFilter === "all" || record.status === statusFilter
      const matchesTenant = tenantFilter === "all" || record.tenantId === tenantFilter

      return matchesSearch && matchesStatus && matchesTenant
    })
  }, [searchTerm, statusFilter, tenantFilter])

  const billingStats = useMemo(() => {
    const totalRevenue = filteredRecords.reduce((sum, record) => sum + record.amount, 0)
    const paidRecords = filteredRecords.filter((r) => r.status === "paid")
    const pendingRecords = filteredRecords.filter((r) => r.status === "pending")
    const overdueRecords = filteredRecords.filter((r) => r.status === "overdue")

    return {
      totalRevenue,
      paidAmount: paidRecords.reduce((sum, record) => sum + record.amount, 0),
      pendingAmount: pendingRecords.reduce((sum, record) => sum + record.amount, 0),
      overdueAmount: overdueRecords.reduce((sum, record) => sum + record.amount, 0),
      totalRecords: filteredRecords.length,
    }
  }, [filteredRecords])

  const exportToCSV = () => {
    const headers = ["Tenant", "Period", "Amount", "Status", "Due Date", "Items"]
    const csvContent = [
      headers.join(","),
      ...filteredRecords.map((record) => {
        const tenant = mockTenants.find((t) => t.id === record.tenantId)
        const itemsDescription = record.items.map((item) => item.description).join("; ")
        return [
          tenant?.name || "Unknown",
          record.period,
          record.amount,
          record.status,
          format(new Date(record.dueDate), "yyyy-MM-dd"),
          `"${itemsDescription}"`,
        ].join(",")
      }),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `billing-records-${format(new Date(), "yyyy-MM-dd")}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Billing Management</h1>
          <p className="text-sm text-gray-600">Monitor revenue, subscriptions, and payment status</p>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={exportToCSV} variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
        </div>
      </div>

      {/* Revenue KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                <p className="text-2xl font-bold text-gray-900">${billingStats.totalRevenue.toLocaleString()}</p>
              </div>
              <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                <DollarSign className="w-4 h-4 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Paid</p>
                <p className="text-2xl font-bold text-green-600">${billingStats.paidAmount.toLocaleString()}</p>
              </div>
              <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckCircle className="w-4 h-4 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pending</p>
                <p className="text-2xl font-bold text-yellow-600">${billingStats.pendingAmount.toLocaleString()}</p>
              </div>
              <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Clock className="w-4 h-4 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Overdue</p>
                <p className="text-2xl font-bold text-red-600">${billingStats.overdueAmount.toLocaleString()}</p>
              </div>
              <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
                <AlertCircle className="w-4 h-4 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Revenue Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Monthly Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                revenue: {
                  label: "Revenue",
                  color: "hsl(var(--chart-1))",
                },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line
                    type="monotone"
                    dataKey="revenue"
                    stroke="var(--color-revenue)"
                    strokeWidth={2}
                    dot={{ fill: "var(--color-revenue)", strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Active Subscriptions</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                subscriptions: {
                  label: "Subscriptions",
                  color: "hsl(var(--chart-2))",
                },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="subscriptions" fill="var(--color-subscriptions)" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search billing records..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="overdue">Overdue</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
              </SelectContent>
            </Select>
            <Select value={tenantFilter} onValueChange={setTenantFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Tenant" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Tenants</SelectItem>
                {mockTenants.map((tenant) => (
                  <SelectItem key={tenant.id} value={tenant.id}>
                    {tenant.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Billing Records Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tenant</TableHead>
                <TableHead>Period</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Due Date</TableHead>
                <TableHead>Items</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRecords.map((record, index) => {
                const tenant = mockTenants.find((t) => t.id === record.tenantId)
                const StatusIcon = paymentStatusIcons[record.status]

                return (
                  <TableRow key={`${record.tenantId}-${record.period}-${index}`}>
                    <TableCell>
                      <div className="font-medium text-gray-900">{tenant?.name || "Unknown"}</div>
                    </TableCell>
                    <TableCell className="font-medium">{record.period}</TableCell>
                    <TableCell className="font-medium">${record.amount}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <StatusIcon className="w-4 h-4" />
                        <Badge className={cn("capitalize", paymentStatusColors[record.status])}>{record.status}</Badge>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">{format(new Date(record.dueDate), "MMM dd, yyyy")}</TableCell>
                    <TableCell className="text-sm">
                      <div className="max-w-xs">
                        {record.items.map((item, i) => (
                          <div key={i} className="text-gray-600">
                            {item.description} (${item.total})
                          </div>
                        ))}
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
