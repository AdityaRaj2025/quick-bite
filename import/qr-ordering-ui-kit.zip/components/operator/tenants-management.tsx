"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuCheckboxItem,
} from "@/components/ui/dropdown-menu"
import { Search, Filter, Download, Eye, MoreHorizontal, TrendingUp } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Tenant } from "@/types/operator"
import { TenantDetailDrawer } from "./tenant-detail-drawer"

// Mock data
const mockTenants: Tenant[] = [
  {
    id: "tenant-1",
    restaurantName: "Sakura Sushi",
    plan: "professional",
    status: "active",
    lastActive: "2024-01-15T10:30:00Z",
    createdAt: "2023-06-15T00:00:00Z",
    contactEmail: "owner@sakurasushi.com",
    contactName: "Hiroshi Tanaka",
    domain: "sakurasushi.com",
    environment: "production",
    usageMetrics: {
      ordersToday: 45,
      ordersThisMonth: 1250,
      dailyActiveUsers: 120,
      monthlyActiveUsers: 2800,
      apiCalls: 15600,
      storageUsed: 245,
    },
    featureFlags: ["multilingual", "analytics", "custom_branding"],
    billingInfo: {
      seats: 5,
      quota: { orders: 2000, apiCalls: 50000, storage: 1000 },
      paymentStatus: "paid",
      nextBillingDate: "2024-02-15T00:00:00Z",
      amount: 99,
    },
  },
  {
    id: "tenant-2",
    restaurantName: "Pizza Corner",
    plan: "starter",
    status: "trial",
    lastActive: "2024-01-15T09:15:00Z",
    createdAt: "2024-01-01T00:00:00Z",
    contactEmail: "manager@pizzacorner.com",
    contactName: "Maria Rodriguez",
    environment: "production",
    usageMetrics: {
      ordersToday: 12,
      ordersThisMonth: 180,
      dailyActiveUsers: 35,
      monthlyActiveUsers: 450,
      apiCalls: 2400,
      storageUsed: 45,
    },
    featureFlags: ["basic_analytics"],
    billingInfo: {
      seats: 2,
      quota: { orders: 500, apiCalls: 10000, storage: 250 },
      paymentStatus: "pending",
      nextBillingDate: "2024-01-31T00:00:00Z",
      amount: 29,
    },
  },
  {
    id: "tenant-3",
    restaurantName: "The Gourmet Kitchen",
    plan: "enterprise",
    status: "active",
    lastActive: "2024-01-15T11:45:00Z",
    createdAt: "2023-03-10T00:00:00Z",
    contactEmail: "admin@gourmetkitchen.com",
    contactName: "James Wilson",
    domain: "gourmetkitchen.com",
    environment: "production",
    usageMetrics: {
      ordersToday: 89,
      ordersThisMonth: 3200,
      dailyActiveUsers: 280,
      monthlyActiveUsers: 8500,
      apiCalls: 45000,
      storageUsed: 890,
    },
    featureFlags: ["multilingual", "analytics", "custom_branding", "api_access", "white_label"],
    billingInfo: {
      seats: 15,
      quota: { orders: 10000, apiCalls: 200000, storage: 5000 },
      paymentStatus: "paid",
      nextBillingDate: "2024-02-10T00:00:00Z",
      amount: 299,
    },
  },
]

const statusColors = {
  active: "bg-green-100 text-green-800",
  inactive: "bg-gray-100 text-gray-800",
  suspended: "bg-red-100 text-red-800",
  trial: "bg-blue-100 text-blue-800",
}

const planColors = {
  starter: "bg-gray-100 text-gray-800",
  professional: "bg-blue-100 text-blue-800",
  enterprise: "bg-purple-100 text-purple-800",
}

export function TenantsManagement() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [planFilter, setPlanFilter] = useState<string>("all")
  const [selectedTenant, setSelectedTenant] = useState<Tenant | null>(null)
  const [visibleColumns, setVisibleColumns] = useState({
    name: true,
    plan: true,
    status: true,
    lastActive: true,
    orders: true,
    users: true,
    apiCalls: true,
  })

  const filteredTenants = useMemo(() => {
    return mockTenants.filter((tenant) => {
      const matchesSearch =
        tenant.restaurantName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tenant.contactEmail.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesStatus = statusFilter === "all" || tenant.status === statusFilter
      const matchesPlan = planFilter === "all" || tenant.plan === planFilter

      return matchesSearch && matchesStatus && matchesPlan
    })
  }, [searchTerm, statusFilter, planFilter])

  const exportToCSV = () => {
    const headers = [
      "Restaurant Name",
      "Plan",
      "Status",
      "Contact Email",
      "Orders Today",
      "Monthly Orders",
      "DAU",
      "MAU",
    ]
    const csvContent = [
      headers.join(","),
      ...filteredTenants.map((tenant) =>
        [
          tenant.restaurantName,
          tenant.plan,
          tenant.status,
          tenant.contactEmail,
          tenant.usageMetrics.ordersToday,
          tenant.usageMetrics.ordersThisMonth,
          tenant.usageMetrics.dailyActiveUsers,
          tenant.usageMetrics.monthlyActiveUsers,
        ].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "tenants-export.csv"
    a.click()
    URL.revokeObjectURL(url)
  }

  const formatLastActive = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60))

    if (diffInHours < 1) return "Just now"
    if (diffInHours < 24) return `${diffInHours}h ago`
    return `${Math.floor(diffInHours / 24)}d ago`
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Tenants</h1>
          <p className="text-sm text-gray-600">Manage restaurant tenants and monitor their usage</p>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={exportToCSV} variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search tenants..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="trial">Trial</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
                <SelectItem value="suspended">Suspended</SelectItem>
              </SelectContent>
            </Select>
            <Select value={planFilter} onValueChange={setPlanFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Plan" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Plans</SelectItem>
                <SelectItem value="starter">Starter</SelectItem>
                <SelectItem value="professional">Professional</SelectItem>
                <SelectItem value="enterprise">Enterprise</SelectItem>
              </SelectContent>
            </Select>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Filter className="w-4 h-4 mr-2" />
                  Columns
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {Object.entries(visibleColumns).map(([key, visible]) => (
                  <DropdownMenuCheckboxItem
                    key={key}
                    checked={visible}
                    onCheckedChange={(checked) => setVisibleColumns((prev) => ({ ...prev, [key]: checked }))}
                  >
                    {key.charAt(0).toUpperCase() + key.slice(1)}
                  </DropdownMenuCheckboxItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardContent>
      </Card>

      {/* Tenants Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                {visibleColumns.name && <TableHead>Restaurant</TableHead>}
                {visibleColumns.plan && <TableHead>Plan</TableHead>}
                {visibleColumns.status && <TableHead>Status</TableHead>}
                {visibleColumns.lastActive && <TableHead>Last Active</TableHead>}
                {visibleColumns.orders && <TableHead>Orders Today</TableHead>}
                {visibleColumns.users && <TableHead>DAU</TableHead>}
                {visibleColumns.apiCalls && <TableHead>API Calls</TableHead>}
                <TableHead className="w-[50px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTenants.map((tenant) => (
                <TableRow
                  key={tenant.id}
                  className="cursor-pointer hover:bg-gray-50"
                  onClick={() => setSelectedTenant(tenant)}
                >
                  {visibleColumns.name && (
                    <TableCell>
                      <div>
                        <div className="font-medium text-gray-900">{tenant.restaurantName}</div>
                        <div className="text-sm text-gray-500">{tenant.contactEmail}</div>
                      </div>
                    </TableCell>
                  )}
                  {visibleColumns.plan && (
                    <TableCell>
                      <Badge className={cn("capitalize", planColors[tenant.plan])}>{tenant.plan}</Badge>
                    </TableCell>
                  )}
                  {visibleColumns.status && (
                    <TableCell>
                      <Badge className={cn("capitalize", statusColors[tenant.status])}>{tenant.status}</Badge>
                    </TableCell>
                  )}
                  {visibleColumns.lastActive && (
                    <TableCell className="text-sm text-gray-600">{formatLastActive(tenant.lastActive)}</TableCell>
                  )}
                  {visibleColumns.orders && (
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <span className="font-medium">{tenant.usageMetrics.ordersToday}</span>
                        <TrendingUp className="w-3 h-3 text-green-500" />
                      </div>
                    </TableCell>
                  )}
                  {visibleColumns.users && (
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <span className="font-medium">{tenant.usageMetrics.dailyActiveUsers}</span>
                        <TrendingUp className="w-3 h-3 text-green-500" />
                      </div>
                    </TableCell>
                  )}
                  {visibleColumns.apiCalls && (
                    <TableCell>
                      <span className="font-medium">{tenant.usageMetrics.apiCalls.toLocaleString()}</span>
                    </TableCell>
                  )}
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setSelectedTenant(tenant)}>
                          <Eye className="w-4 h-4 mr-2" />
                          View Details
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Tenant Detail Drawer */}
      {selectedTenant && (
        <TenantDetailDrawer tenant={selectedTenant} open={!!selectedTenant} onClose={() => setSelectedTenant(null)} />
      )}
    </div>
  )
}
