"use client"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Separator } from "@/components/ui/separator"
import { Building2, Mail, Globe, Calendar, Users, CreditCard, Flag, Shield } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Tenant } from "@/types/operator"

interface TenantDetailDrawerProps {
  tenant: Tenant
  open: boolean
  onClose: () => void
}

const statusColors = {
  active: "bg-green-100 text-green-800",
  inactive: "bg-gray-100 text-gray-800",
  suspended: "bg-red-100 text-red-800",
  trial: "bg-blue-100 text-blue-800",
}

const planColors = {
  starter: "bg-gray-100 text-gray-800",
  professional: "bg-blue-100 text-blue-800",
  enterprise: "bg-purple-100 text-purple-800",
}

const paymentStatusColors = {
  paid: "bg-green-100 text-green-800",
  pending: "bg-yellow-100 text-yellow-800",
  overdue: "bg-red-100 text-red-800",
  failed: "bg-red-100 text-red-800",
}

export function TenantDetailDrawer({ tenant, open, onClose }: TenantDetailDrawerProps) {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const usagePercentage = (used: number, quota: number) => {
    return Math.round((used / quota) * 100)
  }

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent className="w-[600px] sm:max-w-[600px] overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Building2 className="w-5 h-5" />
            {tenant.restaurantName}
          </SheetTitle>
        </SheetHeader>

        <div className="space-y-6 py-6">
          {/* Overview */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Overview</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-500">Status</div>
                  <Badge className={cn("capitalize", statusColors[tenant.status])}>{tenant.status}</Badge>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-500">Plan</div>
                  <Badge className={cn("capitalize", planColors[tenant.plan])}>{tenant.plan}</Badge>
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-sm font-medium text-gray-500">Environment</div>
                <Badge variant={tenant.environment === "production" ? "default" : "secondary"}>
                  {tenant.environment}
                </Badge>
              </div>

              <div className="space-y-2">
                <div className="text-sm font-medium text-gray-500">Created</div>
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="w-4 h-4 text-gray-400" />
                  {formatDate(tenant.createdAt)}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Contact Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="text-sm font-medium text-gray-500">Contact Name</div>
                <div className="flex items-center gap-2 text-sm">
                  <Users className="w-4 h-4 text-gray-400" />
                  {tenant.contactName}
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-sm font-medium text-gray-500">Email</div>
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="w-4 h-4 text-gray-400" />
                  {tenant.contactEmail}
                </div>
              </div>

              {tenant.domain && (
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-500">Domain</div>
                  <div className="flex items-center gap-2 text-sm">
                    <Globe className="w-4 h-4 text-gray-400" />
                    {tenant.domain}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Usage Metrics */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Usage Metrics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <div className="text-sm font-medium text-gray-500">Orders Today</div>
                  <div className="text-2xl font-bold text-gray-900">{tenant.usageMetrics.ordersToday}</div>
                </div>
                <div className="space-y-1">
                  <div className="text-sm font-medium text-gray-500">Orders This Month</div>
                  <div className="text-2xl font-bold text-gray-900">{tenant.usageMetrics.ordersThisMonth}</div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <div className="text-sm font-medium text-gray-500">Daily Active Users</div>
                  <div className="text-2xl font-bold text-gray-900">{tenant.usageMetrics.dailyActiveUsers}</div>
                </div>
                <div className="space-y-1">
                  <div className="text-sm font-medium text-gray-500">Monthly Active Users</div>
                  <div className="text-2xl font-bold text-gray-900">{tenant.usageMetrics.monthlyActiveUsers}</div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <div className="text-sm font-medium text-gray-500">API Calls</div>
                  <div className="text-2xl font-bold text-gray-900">
                    {tenant.usageMetrics.apiCalls.toLocaleString()}
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="text-sm font-medium text-gray-500">Storage Used</div>
                  <div className="text-2xl font-bold text-gray-900">{tenant.usageMetrics.storageUsed} MB</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Billing Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Billing Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-500">Payment Status</div>
                  <Badge className={cn("capitalize", paymentStatusColors[tenant.billingInfo.paymentStatus])}>
                    {tenant.billingInfo.paymentStatus}
                  </Badge>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-500">Amount</div>
                  <div className="flex items-center gap-2 text-sm">
                    <CreditCard className="w-4 h-4 text-gray-400" />${tenant.billingInfo.amount}/month
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-sm font-medium text-gray-500">Next Billing Date</div>
                <div className="text-sm">{formatDate(tenant.billingInfo.nextBillingDate)}</div>
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="text-sm font-medium text-gray-500">Quota Usage</div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Orders</span>
                    <span>
                      {tenant.usageMetrics.ordersThisMonth} / {tenant.billingInfo.quota.orders}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-saffron h-2 rounded-full"
                      style={{
                        width: `${Math.min(usagePercentage(tenant.usageMetrics.ordersThisMonth, tenant.billingInfo.quota.orders), 100)}%`,
                      }}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>API Calls</span>
                    <span>
                      {tenant.usageMetrics.apiCalls.toLocaleString()} /{" "}
                      {tenant.billingInfo.quota.apiCalls.toLocaleString()}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-saffron h-2 rounded-full"
                      style={{
                        width: `${Math.min(usagePercentage(tenant.usageMetrics.apiCalls, tenant.billingInfo.quota.apiCalls), 100)}%`,
                      }}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Storage</span>
                    <span>
                      {tenant.usageMetrics.storageUsed} MB / {tenant.billingInfo.quota.storage} MB
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-saffron h-2 rounded-full"
                      style={{
                        width: `${Math.min(usagePercentage(tenant.usageMetrics.storageUsed, tenant.billingInfo.quota.storage), 100)}%`,
                      }}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Feature Flags */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Flag className="w-5 h-5" />
                Feature Flags
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {tenant.featureFlags.map((flag) => (
                  <Badge key={flag} variant="outline" className="capitalize">
                    {flag.replace("_", " ")}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Data Boundaries Notice */}
          <Card className="border-amber-200 bg-amber-50">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-amber-600 mt-0.5" />
                <div className="space-y-1">
                  <div className="text-sm font-medium text-amber-800">Data Boundaries Notice</div>
                  <div className="text-sm text-amber-700">
                    This tenant's data is isolated and encrypted. PII access is logged and minimal data is displayed in
                    this console for privacy compliance.
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </SheetContent>
    </Sheet>
  )
}
