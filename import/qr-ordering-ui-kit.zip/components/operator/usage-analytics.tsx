"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DatePickerWithRange } from "@/components/ui/date-range-picker"
import { Line, LineChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Bar, BarChart } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Download, TrendingUp, TrendingDown, Users, ShoppingCart, Zap, AlertTriangle } from "lucide-react"
import { format, subDays } from "date-fns"
import type { DateRange } from "react-day-picker"
import type { UsageData } from "@/types/operator"

// Mock usage data
const generateMockData = (tenantId: string, days: number): UsageData[] => {
  const data: UsageData[] = []
  const baseValues = {
    "tenant-1": { orders: 45, users: 120, apiCalls: 800, errors: 5 },
    "tenant-2": { orders: 12, users: 35, apiCalls: 150, errors: 2 },
    "tenant-3": { orders: 89, users: 280, apiCalls: 1200, errors: 8 },
  }

  const base = baseValues[tenantId as keyof typeof baseValues] || baseValues["tenant-1"]

  for (let i = days - 1; i >= 0; i--) {
    const date = format(subDays(new Date(), i), "yyyy-MM-dd")
    const variance = 0.7 + Math.random() * 0.6 // 0.7 to 1.3 multiplier

    data.push({
      tenantId,
      date,
      orders: Math.floor(base.orders * variance),
      activeUsers: Math.floor(base.users * variance),
      apiCalls: Math.floor(base.apiCalls * variance),
      errors: Math.floor(base.errors * variance),
      responseTime: 150 + Math.random() * 100, // 150-250ms
    })
  }

  return data
}

const mockTenants = [
  { id: "tenant-1", name: "Sakura Sushi" },
  { id: "tenant-2", name: "Pizza Corner" },
  { id: "tenant-3", name: "The Gourmet Kitchen" },
]

export function UsageAnalytics() {
  const [selectedTenant, setSelectedTenant] = useState("tenant-1")
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: subDays(new Date(), 30),
    to: new Date(),
  })

  const days =
    dateRange?.from && dateRange?.to
      ? Math.ceil((dateRange.to.getTime() - dateRange.from.getTime()) / (1000 * 60 * 60 * 24)) + 1
      : 30

  const usageData = useMemo(() => {
    return generateMockData(selectedTenant, days)
  }, [selectedTenant, days])

  const aggregatedData = useMemo(() => {
    const totalOrders = usageData.reduce((sum, day) => sum + day.orders, 0)
    const totalUsers = usageData.reduce((sum, day) => sum + day.activeUsers, 0)
    const totalApiCalls = usageData.reduce((sum, day) => sum + day.apiCalls, 0)
    const totalErrors = usageData.reduce((sum, day) => sum + day.errors, 0)
    const avgResponseTime = usageData.reduce((sum, day) => sum + day.responseTime, 0) / usageData.length

    const previousPeriodData = generateMockData(selectedTenant, days).slice(-days)
    const prevTotalOrders = previousPeriodData.reduce((sum, day) => sum + day.orders, 0)
    const prevTotalUsers = previousPeriodData.reduce((sum, day) => sum + day.activeUsers, 0)

    return {
      totalOrders,
      totalUsers,
      totalApiCalls,
      totalErrors,
      avgResponseTime,
      ordersChange: ((totalOrders - prevTotalOrders) / prevTotalOrders) * 100,
      usersChange: ((totalUsers - prevTotalUsers) / prevTotalUsers) * 100,
    }
  }, [usageData, selectedTenant, days])

  const exportToCSV = () => {
    const headers = ["Date", "Orders", "Active Users", "API Calls", "Errors", "Response Time (ms)"]
    const csvContent = [
      headers.join(","),
      ...usageData.map((day) =>
        [day.date, day.orders, day.activeUsers, day.apiCalls, day.errors, day.responseTime.toFixed(0)].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `usage-analytics-${selectedTenant}-${format(new Date(), "yyyy-MM-dd")}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  const selectedTenantName = mockTenants.find((t) => t.id === selectedTenant)?.name || "Unknown"

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Usage Analytics</h1>
          <p className="text-sm text-gray-600">Monitor tenant usage patterns and performance metrics</p>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={exportToCSV} variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <Select value={selectedTenant} onValueChange={setSelectedTenant}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Select tenant" />
              </SelectTrigger>
              <SelectContent>
                {mockTenants.map((tenant) => (
                  <SelectItem key={tenant.id} value={tenant.id}>
                    {tenant.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <DatePickerWithRange date={dateRange} onDateChange={setDateRange} />
          </div>
        </CardContent>
      </Card>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Orders</p>
                <p className="text-2xl font-bold text-gray-900">{aggregatedData.totalOrders.toLocaleString()}</p>
              </div>
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                <ShoppingCart className="w-4 h-4 text-blue-600" />
              </div>
            </div>
            <div className="flex items-center mt-2">
              {aggregatedData.ordersChange > 0 ? (
                <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
              ) : (
                <TrendingDown className="w-4 h-4 text-red-500 mr-1" />
              )}
              <span className={`text-sm ${aggregatedData.ordersChange > 0 ? "text-green-600" : "text-red-600"}`}>
                {Math.abs(aggregatedData.ordersChange).toFixed(1)}%
              </span>
              <span className="text-sm text-gray-500 ml-1">vs previous period</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Users</p>
                <p className="text-2xl font-bold text-gray-900">{aggregatedData.totalUsers.toLocaleString()}</p>
              </div>
              <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                <Users className="w-4 h-4 text-green-600" />
              </div>
            </div>
            <div className="flex items-center mt-2">
              {aggregatedData.usersChange > 0 ? (
                <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
              ) : (
                <TrendingDown className="w-4 h-4 text-red-500 mr-1" />
              )}
              <span className={`text-sm ${aggregatedData.usersChange > 0 ? "text-green-600" : "text-red-600"}`}>
                {Math.abs(aggregatedData.usersChange).toFixed(1)}%
              </span>
              <span className="text-sm text-gray-500 ml-1">vs previous period</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">API Calls</p>
                <p className="text-2xl font-bold text-gray-900">{aggregatedData.totalApiCalls.toLocaleString()}</p>
              </div>
              <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                <Zap className="w-4 h-4 text-purple-600" />
              </div>
            </div>
            <div className="flex items-center mt-2">
              <span className="text-sm text-gray-500">
                {(aggregatedData.totalApiCalls / days).toFixed(0)} per day avg
              </span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Errors</p>
                <p className="text-2xl font-bold text-gray-900">{aggregatedData.totalErrors}</p>
              </div>
              <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
                <AlertTriangle className="w-4 h-4 text-red-600" />
              </div>
            </div>
            <div className="flex items-center mt-2">
              <span className="text-sm text-gray-500">
                {((aggregatedData.totalErrors / aggregatedData.totalApiCalls) * 100).toFixed(2)}% error rate
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Orders Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Orders Over Time - {selectedTenantName}</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                orders: {
                  label: "Orders",
                  color: "hsl(var(--chart-1))",
                },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={usageData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" tickFormatter={(value) => format(new Date(value), "MMM dd")} />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line
                    type="monotone"
                    dataKey="orders"
                    stroke="var(--color-orders)"
                    strokeWidth={2}
                    dot={{ fill: "var(--color-orders)", strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        {/* Active Users Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Active Users Over Time - {selectedTenantName}</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                activeUsers: {
                  label: "Active Users",
                  color: "hsl(var(--chart-2))",
                },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={usageData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" tickFormatter={(value) => format(new Date(value), "MMM dd")} />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line
                    type="monotone"
                    dataKey="activeUsers"
                    stroke="var(--color-activeUsers)"
                    strokeWidth={2}
                    dot={{ fill: "var(--color-activeUsers)", strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        {/* API Calls Chart */}
        <Card>
          <CardHeader>
            <CardTitle>API Calls Over Time - {selectedTenantName}</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                apiCalls: {
                  label: "API Calls",
                  color: "hsl(var(--chart-3))",
                },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={usageData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" tickFormatter={(value) => format(new Date(value), "MMM dd")} />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="apiCalls" fill="var(--color-apiCalls)" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        {/* Response Time Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Response Time - {selectedTenantName}</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                responseTime: {
                  label: "Response Time (ms)",
                  color: "hsl(var(--chart-4))",
                },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={usageData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" tickFormatter={(value) => format(new Date(value), "MMM dd")} />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line
                    type="monotone"
                    dataKey="responseTime"
                    stroke="var(--color-responseTime)"
                    strokeWidth={2}
                    dot={{ fill: "var(--color-responseTime)", strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
