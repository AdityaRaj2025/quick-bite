"use client"

import { useTranslation } from "react-i18next"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { TrendingUp, Users, ShoppingBag, Clock, Plus, ArrowRight } from "lucide-react"
import { PageHeader } from "@/lib/ui/layout"

interface AdminDashboardProps {
  restaurantId: string
}

export function AdminDashboard({ restaurantId }: AdminDashboardProps) {
  const { t } = useTranslation()

  const stats = [
    {
      title: t("admin.dashboard.todaySales"),
      value: "¥45,230",
      change: "+12%",
      trend: "up",
      icon: TrendingUp,
    },
    {
      title: t("admin.dashboard.activeOrders"),
      value: "8",
      change: "3 new",
      trend: "neutral",
      icon: ShoppingBag,
    },
    {
      title: t("admin.dashboard.customersToday"),
      value: "127",
      change: "+8%",
      trend: "up",
      icon: Users,
    },
    {
      title: t("admin.dashboard.avgWaitTime"),
      value: "12 min",
      change: "-2 min",
      trend: "down",
      icon: Clock,
    },
  ]

  const recentOrders = [
    { id: "ORD-001", table: "T-05", items: 3, total: "¥2,340", status: "preparing", time: "2 min ago" },
    { id: "ORD-002", table: "T-12", items: 5, total: "¥4,120", status: "ready", time: "5 min ago" },
    { id: "ORD-003", table: "T-03", items: 2, total: "¥1,890", status: "served", time: "8 min ago" },
  ]

  const quickActions = [
    { label: t("admin.dashboard.addMenuItem"), href: `/admin/${restaurantId}/menu/new` },
    { label: t("admin.dashboard.generateQR"), href: `/admin/${restaurantId}/tables` },
    { label: t("admin.dashboard.inviteStaff"), href: `/admin/${restaurantId}/staff/invite` },
    { label: t("admin.dashboard.viewAnalytics"), href: `/admin/${restaurantId}/analytics` },
  ]

  return (
    <div className="p-6 space-y-6">
      <PageHeader title={t("admin.dashboard.title")} description={t("admin.dashboard.description")} />

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <Card key={stat.title}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                  <div className="flex items-center mt-2">
                    <Badge
                      variant={stat.trend === "up" ? "default" : stat.trend === "down" ? "secondary" : "outline"}
                      className="text-xs"
                    >
                      {stat.change}
                    </Badge>
                  </div>
                </div>
                <div className="w-12 h-12 bg-saffron/10 rounded-lg flex items-center justify-center">
                  <stat.icon className="w-6 h-6 text-saffron" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Orders */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              {t("admin.dashboard.recentOrders")}
              <Button variant="ghost" size="sm">
                {t("admin.dashboard.viewAll")}
                <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentOrders.map((order) => (
                <div key={order.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div>
                      <p className="font-medium text-sm">{order.id}</p>
                      <p className="text-xs text-gray-500">
                        {order.table} • {order.items} items
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-sm">{order.total}</p>
                    <div className="flex items-center gap-2">
                      <Badge variant={order.status === "ready" ? "default" : "secondary"} className="text-xs">
                        {order.status}
                      </Badge>
                      <span className="text-xs text-gray-500">{order.time}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>{t("admin.dashboard.quickActions")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-3">
              {quickActions.map((action) => (
                <Button key={action.label} variant="ghost" className="justify-start h-auto p-3" asChild>
                  <a href={action.href}>
                    <Plus className="w-4 h-4 mr-2" />
                    {action.label}
                  </a>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
