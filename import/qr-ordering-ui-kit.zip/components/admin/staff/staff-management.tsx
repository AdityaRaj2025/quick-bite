"use client"

import { useState } from "react"
import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { PageHeader } from "@/lib/ui/layout"
import { LabeledField } from "@/lib/ui/forms"
import { Plus, MoreHorizontal, Edit, UserX, Mail, Shield } from "lucide-react"

interface StaffManagementProps {
  restaurantId: string
}

export function StaffManagement({ restaurantId }: StaffManagementProps) {
  const { t } = useTranslation()
  const [inviteDialogOpen, setInviteDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [editingUser, setEditingUser] = useState<any>(null)

  // Mock data
  const [staff, setStaff] = useState([
    {
      id: "1",
      name: "Takeshi Yamamoto",
      email: "takeshi@sakurasushi.com",
      role: "owner",
      status: "active",
      lastLogin: "2024-01-15 14:30",
      invitedBy: null,
      joinedAt: "2023-06-01",
    },
    {
      id: "2",
      name: "Sarah Johnson",
      email: "sarah@sakurasushi.com",
      role: "manager",
      status: "active",
      lastLogin: "2024-01-15 12:15",
      invitedBy: "Takeshi Yamamoto",
      joinedAt: "2023-08-15",
    },
    {
      id: "3",
      name: "Kenji Tanaka",
      email: "kenji@sakurasushi.com",
      role: "kitchen",
      status: "active",
      lastLogin: "2024-01-15 09:45",
      invitedBy: "Sarah Johnson",
      joinedAt: "2023-10-01",
    },
    {
      id: "4",
      name: "Maria Garcia",
      email: "maria@sakurasushi.com",
      role: "staff",
      status: "pending",
      lastLogin: null,
      invitedBy: "Sarah Johnson",
      joinedAt: null,
    },
  ])

  const roles = [
    { value: "owner", label: t("admin.roles.owner"), description: t("admin.roles.ownerDescription") },
    { value: "manager", label: t("admin.roles.manager"), description: t("admin.roles.managerDescription") },
    { value: "staff", label: t("admin.roles.staff"), description: t("admin.roles.staffDescription") },
    { value: "kitchen", label: t("admin.roles.kitchen"), description: t("admin.roles.kitchenDescription") },
  ]

  const openEditDialog = (user: any) => {
    setEditingUser(user)
    setEditDialogOpen(true)
  }

  const toggleUserStatus = (userId: string) => {
    setStaff(
      staff.map((user) =>
        user.id === userId ? { ...user, status: user.status === "active" ? "disabled" : "active" } : user,
      ),
    )
  }

  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case "owner":
        return "destructive"
      case "manager":
        return "default"
      case "staff":
        return "secondary"
      case "kitchen":
        return "outline"
      default:
        return "secondary"
    }
  }

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title={t("admin.staff.title")}
        description={t("admin.staff.description")}
        action={
          <Button onClick={() => setInviteDialogOpen(true)} className="bg-saffron hover:bg-saffron/90">
            <Plus className="w-4 h-4 mr-2" />
            {t("admin.staff.inviteUser")}
          </Button>
        }
      />

      {/* Access Policy Summary */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
          <div>
            <h3 className="font-medium text-blue-900">{t("admin.staff.accessPolicy")}</h3>
            <div className="text-sm text-blue-800 mt-2 space-y-1">
              <p>
                <strong>{t("admin.roles.owner")}:</strong> {t("admin.roles.ownerDescription")}
              </p>
              <p>
                <strong>{t("admin.roles.manager")}:</strong> {t("admin.roles.managerDescription")}
              </p>
              <p>
                <strong>{t("admin.roles.staff")}:</strong> {t("admin.roles.staffDescription")}
              </p>
              <p>
                <strong>{t("admin.roles.kitchen")}:</strong> {t("admin.roles.kitchenDescription")}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Staff Table */}
      <div className="bg-white rounded-lg border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>{t("admin.staff.user")}</TableHead>
              <TableHead>{t("admin.staff.role")}</TableHead>
              <TableHead>{t("admin.staff.status")}</TableHead>
              <TableHead>{t("admin.staff.lastLogin")}</TableHead>
              <TableHead>{t("admin.staff.joinedAt")}</TableHead>
              <TableHead className="w-24">{t("admin.staff.actions")}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {staff.map((user) => (
              <TableRow key={user.id}>
                <TableCell>
                  <div>
                    <p className="font-medium">{user.name}</p>
                    <p className="text-sm text-gray-500">{user.email}</p>
                    {user.invitedBy && (
                      <p className="text-xs text-gray-400">
                        {t("admin.staff.invitedBy")} {user.invitedBy}
                      </p>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant={getRoleBadgeVariant(user.role)}>{t(`admin.roles.${user.role}`)}</Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Badge
                      variant={
                        user.status === "active" ? "default" : user.status === "pending" ? "secondary" : "outline"
                      }
                    >
                      {t(`admin.staff.${user.status}`)}
                    </Badge>
                    {user.status !== "pending" && (
                      <Switch
                        checked={user.status === "active"}
                        onCheckedChange={() => toggleUserStatus(user.id)}
                        size="sm"
                      />
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <span className="text-sm text-gray-600">
                    {user.lastLogin ? new Date(user.lastLogin).toLocaleString() : t("admin.staff.neverLoggedIn")}
                  </span>
                </TableCell>
                <TableCell>
                  <span className="text-sm text-gray-600">
                    {user.joinedAt ? new Date(user.joinedAt).toLocaleDateString() : t("admin.staff.pending")}
                  </span>
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => openEditDialog(user)}>
                        <Edit className="w-4 h-4 mr-2" />
                        {t("admin.staff.editUser")}
                      </DropdownMenuItem>
                      {user.status === "pending" && (
                        <DropdownMenuItem>
                          <Mail className="w-4 h-4 mr-2" />
                          {t("admin.staff.resendInvite")}
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuItem className="text-red-600">
                        <UserX className="w-4 h-4 mr-2" />
                        {t("admin.staff.removeUser")}
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Invite User Dialog */}
      <Dialog open={inviteDialogOpen} onOpenChange={setInviteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t("admin.staff.inviteUser")}</DialogTitle>
            <DialogDescription>{t("admin.staff.inviteUserDescription")}</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <LabeledField label={t("admin.staff.emailAddress")} required>
              <Input type="email" placeholder="user@example.com" />
            </LabeledField>

            <LabeledField label={t("admin.staff.role")} required>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder={t("admin.staff.selectRole")} />
                </SelectTrigger>
                <SelectContent>
                  {roles.map((role) => (
                    <SelectItem key={role.value} value={role.value}>
                      <div>
                        <p className="font-medium">{role.label}</p>
                        <p className="text-sm text-gray-500">{role.description}</p>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </LabeledField>

            <div className="flex items-center gap-3 pt-4 border-t">
              <Button className="bg-saffron hover:bg-saffron/90">
                <Mail className="w-4 h-4 mr-2" />
                {t("admin.staff.sendInvite")}
              </Button>
              <Button variant="outline" onClick={() => setInviteDialogOpen(false)}>
                {t("admin.staff.cancel")}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t("admin.staff.editUser")}</DialogTitle>
            <DialogDescription>{t("admin.staff.editUserDescription")}</DialogDescription>
          </DialogHeader>

          {editingUser && (
            <div className="space-y-4">
              <LabeledField label={t("admin.staff.name")}>
                <Input defaultValue={editingUser.name} />
              </LabeledField>

              <LabeledField label={t("admin.staff.emailAddress")}>
                <Input type="email" defaultValue={editingUser.email} disabled />
              </LabeledField>

              <LabeledField label={t("admin.staff.role")} required>
                <Select defaultValue={editingUser.role}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {roles.map((role) => (
                      <SelectItem key={role.value} value={role.value}>
                        <div>
                          <p className="font-medium">{role.label}</p>
                          <p className="text-sm text-gray-500">{role.description}</p>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </LabeledField>

              <div className="flex items-center gap-3 pt-4 border-t">
                <Button className="bg-saffron hover:bg-saffron/90">{t("admin.staff.updateUser")}</Button>
                <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
                  {t("admin.staff.cancel")}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
