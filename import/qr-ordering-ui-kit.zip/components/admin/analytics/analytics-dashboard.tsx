"use client"

import { useState } from "react"
import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { PageHeader } from "@/lib/ui/layout"
import { TrendingUp, Users, ShoppingBag, Clock, Download } from "lucide-react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

interface AnalyticsDashboardProps {
  restaurantId: string
}

export function AnalyticsDashboard({ restaurantId }: AnalyticsDashboardProps) {
  const { t } = useTranslation()
  const [dateRange, setDateRange] = useState("7d")

  // Mock data
  const kpis = [
    {
      title: t("admin.analytics.totalSales"),
      value: "¥324,580",
      change: "+12.5%",
      trend: "up",
      icon: TrendingUp,
    },
    {
      title: t("admin.analytics.totalOrders"),
      value: "156",
      change: "+8.2%",
      trend: "up",
      icon: ShoppingBag,
    },
    {
      title: t("admin.analytics.totalCustomers"),
      value: "89",
      change: "+15.3%",
      trend: "up",
      icon: Users,
    },
    {
      title: t("admin.analytics.avgOrderValue"),
      value: "¥2,082",
      change: "+3.7%",
      trend: "up",
      icon: Clock,
    },
  ]

  const salesByHour = [
    { hour: "09:00", sales: 12000 },
    { hour: "10:00", sales: 8000 },
    { hour: "11:00", sales: 15000 },
    { hour: "12:00", sales: 45000 },
    { hour: "13:00", sales: 52000 },
    { hour: "14:00", sales: 38000 },
    { hour: "15:00", sales: 22000 },
    { hour: "16:00", sales: 18000 },
    { hour: "17:00", sales: 25000 },
    { hour: "18:00", sales: 48000 },
    { hour: "19:00", sales: 65000 },
    { hour: "20:00", sales: 58000 },
    { hour: "21:00", sales: 42000 },
  ]

  const topDishes = [
    { name: "Salmon Sashimi", orders: 45, revenue: "¥58,050", percentage: 18.5 },
    { name: "Chicken Teriyaki Rice", orders: 38, revenue: "¥60,420", percentage: 15.2 },
    { name: "Pork Gyoza", orders: 32, revenue: "¥28,480", percentage: 12.8 },
    { name: "Spicy Tuna Roll", orders: 28, revenue: "¥33,600", percentage: 11.2 },
    { name: "Miso Soup", orders: 24, revenue: "¥14,400", percentage: 9.6 },
  ]

  const busiestTables = [
    { table: "T-05", orders: 18, revenue: "¥42,160", avgTime: "45 min" },
    { table: "T-12", orders: 16, revenue: "¥38,720", avgTime: "38 min" },
    { table: "T-03", orders: 14, revenue: "¥32,890", avgTime: "42 min" },
    { table: "T-08", orders: 12, revenue: "¥28,440", avgTime: "35 min" },
    { table: "T-01", orders: 11, revenue: "¥25,630", avgTime: "40 min" },
  ]

  const exportData = () => {
    // Mock CSV export
    console.log("Exporting analytics data for date range:", dateRange)
  }

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title={t("admin.analytics.title")}
        description={t("admin.analytics.description")}
        action={
          <div className="flex items-center gap-2">
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1d">{t("admin.analytics.today")}</SelectItem>
                <SelectItem value="7d">{t("admin.analytics.last7Days")}</SelectItem>
                <SelectItem value="30d">{t("admin.analytics.last30Days")}</SelectItem>
                <SelectItem value="90d">{t("admin.analytics.last90Days")}</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={exportData}>
              <Download className="w-4 h-4 mr-2" />
              {t("admin.analytics.exportCSV")}
            </Button>
          </div>
        }
      />

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpis.map((kpi) => (
          <Card key={kpi.title}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{kpi.title}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">{kpi.value}</p>
                  <p className="text-sm text-green-600 mt-2">{kpi.change}</p>
                </div>
                <div className="w-12 h-12 bg-saffron/10 rounded-lg flex items-center justify-center">
                  <kpi.icon className="w-6 h-6 text-saffron" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sales by Hour */}
        <Card>
          <CardHeader>
            <CardTitle>{t("admin.analytics.salesByHour")}</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={salesByHour}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="hour" />
                <YAxis />
                <Tooltip formatter={(value) => [`¥${Number(value).toLocaleString()}`, "Sales"]} />
                <Line type="monotone" dataKey="sales" stroke="#FF9933" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Top Dishes */}
        <Card>
          <CardHeader>
            <CardTitle>{t("admin.analytics.topDishes")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topDishes.map((dish, index) => (
                <div key={dish.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 bg-saffron text-white rounded-full flex items-center justify-center text-sm font-bold">
                      {index + 1}
                    </span>
                    <div>
                      <p className="font-medium">{dish.name}</p>
                      <p className="text-sm text-gray-500">{dish.orders} orders</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">{dish.revenue}</p>
                    <p className="text-sm text-gray-500">{dish.percentage}%</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Busiest Tables */}
      <Card>
        <CardHeader>
          <CardTitle>{t("admin.analytics.busiestTables")}</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("admin.analytics.table")}</TableHead>
                <TableHead>{t("admin.analytics.orders")}</TableHead>
                <TableHead>{t("admin.analytics.revenue")}</TableHead>
                <TableHead>{t("admin.analytics.avgTime")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {busiestTables.map((table) => (
                <TableRow key={table.table}>
                  <TableCell className="font-medium">{table.table}</TableCell>
                  <TableCell>{table.orders}</TableCell>
                  <TableCell>{table.revenue}</TableCell>
                  <TableCell>{table.avgTime}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
