"use client"

import { useState } from "react"
import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LabeledField } from "@/lib/ui/forms"
import { Upload, X } from "lucide-react"

interface MenuItemDrawerProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  item?: any
  restaurantId: string
}

export function MenuItemDrawer({ open, onOpenChange, item, restaurantId }: MenuItemDrawerProps) {
  const { t } = useTranslation()
  const [formData, setFormData] = useState(
    item || {
      name: { en: "", ja: "", ne: "", hi: "" },
      description: { en: "", ja: "", ne: "", hi: "" },
      category: "",
      price: 0,
      active: true,
      allergens: [],
      optionGroups: [],
    },
  )

  const categories = [
    { id: "appetizers", name: "Appetizers" },
    { id: "sushi", name: "Sushi & Sashimi" },
    { id: "mains", name: "Main Dishes" },
    { id: "desserts", name: "Desserts" },
  ]

  const allergenOptions = ["gluten", "dairy", "eggs", "fish", "shellfish", "nuts", "peanuts", "soy", "sesame"]

  const handleSave = () => {
    console.log("Saving item:", formData)
    onOpenChange(false)
  }

  const toggleAllergen = (allergen: string) => {
    const newAllergens = formData.allergens.includes(allergen)
      ? formData.allergens.filter((a: string) => a !== allergen)
      : [...formData.allergens, allergen]

    setFormData({ ...formData, allergens: newAllergens })
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-2xl overflow-y-auto">
        <SheetHeader>
          <SheetTitle>{item ? t("admin.menu.editItem") : t("admin.menu.addItem")}</SheetTitle>
          <SheetDescription>{t("admin.menu.itemFormDescription")}</SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* Basic Info */}
          <div className="space-y-4">
            <h3 className="font-medium">{t("admin.menu.basicInfo")}</h3>

            <LabeledField label={t("admin.menu.category")} required>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData({ ...formData, category: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder={t("admin.menu.selectCategory")} />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </LabeledField>

            <LabeledField label={t("admin.menu.price")} required>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">¥</span>
                <Input
                  type="number"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: Number.parseInt(e.target.value) || 0 })}
                  className="pl-8"
                />
              </div>
            </LabeledField>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">{t("admin.menu.active")}</p>
                <p className="text-sm text-gray-600">{t("admin.menu.activeDescription")}</p>
              </div>
              <Switch
                checked={formData.active}
                onCheckedChange={(checked) => setFormData({ ...formData, active: checked })}
              />
            </div>
          </div>

          {/* Translations */}
          <div className="space-y-4">
            <h3 className="font-medium">{t("admin.menu.translations")}</h3>

            <Tabs defaultValue="en" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="en">English</TabsTrigger>
                <TabsTrigger value="ja">日本語</TabsTrigger>
                <TabsTrigger value="ne">नेपाली</TabsTrigger>
                <TabsTrigger value="hi">हिन्दी</TabsTrigger>
              </TabsList>

              {["en", "ja", "ne", "hi"].map((lang) => (
                <TabsContent key={lang} value={lang} className="space-y-4">
                  <LabeledField label={t("admin.menu.itemName")} required>
                    <Input
                      value={formData.name[lang]}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          name: { ...formData.name, [lang]: e.target.value },
                        })
                      }
                      placeholder={t("admin.menu.itemNamePlaceholder")}
                    />
                  </LabeledField>

                  <LabeledField label={t("admin.menu.description")}>
                    <Textarea
                      value={formData.description[lang]}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          description: { ...formData.description, [lang]: e.target.value },
                        })
                      }
                      placeholder={t("admin.menu.descriptionPlaceholder")}
                      rows={3}
                    />
                  </LabeledField>
                </TabsContent>
              ))}
            </Tabs>
          </div>

          {/* Image Upload */}
          <div className="space-y-4">
            <h3 className="font-medium">{t("admin.menu.image")}</h3>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <p className="text-sm text-gray-600 mb-2">{t("admin.menu.uploadImage")}</p>
              <Button variant="outline" size="sm">
                {t("admin.menu.chooseFile")}
              </Button>
            </div>
          </div>

          {/* Allergens */}
          <div className="space-y-4">
            <h3 className="font-medium">{t("admin.menu.allergens")}</h3>
            <div className="flex flex-wrap gap-2">
              {allergenOptions.map((allergen) => (
                <Badge
                  key={allergen}
                  variant={formData.allergens.includes(allergen) ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => toggleAllergen(allergen)}
                >
                  {allergen}
                  {formData.allergens.includes(allergen) && <X className="w-3 h-3 ml-1" />}
                </Badge>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3 pt-6 border-t">
            <Button onClick={handleSave} className="bg-saffron hover:bg-saffron/90">
              {item ? t("admin.menu.updateItem") : t("admin.menu.createItem")}
            </Button>
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              {t("admin.menu.cancel")}
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}
