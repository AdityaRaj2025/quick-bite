"use client"

import { useState } from "react"
import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { PageHeader } from "@/lib/ui/layout"
import { LabeledField } from "@/lib/ui/forms"
import { Plus, GripVertical, Edit, Trash2 } from "lucide-react"

interface CategoriesManagementProps {
  restaurantId: string
}

export function CategoriesManagement({ restaurantId }: CategoriesManagementProps) {
  const { t } = useTranslation()
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingCategory, setEditingCategory] = useState<any>(null)

  // Mock data
  const [categories, setCategories] = useState([
    {
      id: "1",
      name: { en: "Appetizers", ja: "前菜", ne: "खाजा", hi: "स्टार्टर" },
      active: true,
      sortOrder: 1,
      itemCount: 8,
    },
    {
      id: "2",
      name: { en: "Sushi & Sashimi", ja: "寿司・刺身", ne: "सुशी र साशिमी", hi: "सुशी और साशिमी" },
      active: true,
      sortOrder: 2,
      itemCount: 12,
    },
    {
      id: "3",
      name: { en: "Main Dishes", ja: "メイン料理", ne: "मुख्य खाना", hi: "मुख्य व्यंजन" },
      active: true,
      sortOrder: 3,
      itemCount: 15,
    },
    {
      id: "4",
      name: { en: "Desserts", ja: "デザート", ne: "मिठाई", hi: "मिठाई" },
      active: false,
      sortOrder: 4,
      itemCount: 6,
    },
  ])

  const openDialog = (category?: any) => {
    setEditingCategory(category || null)
    setDialogOpen(true)
  }

  const toggleCategoryActive = (categoryId: string) => {
    setCategories(categories.map((cat) => (cat.id === categoryId ? { ...cat, active: !cat.active } : cat)))
  }

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title={t("admin.categories.title")}
        description={t("admin.categories.description")}
        action={
          <Button onClick={() => openDialog()} className="bg-saffron hover:bg-saffron/90">
            <Plus className="w-4 h-4 mr-2" />
            {t("admin.categories.addCategory")}
          </Button>
        }
      />

      {/* Categories Table */}
      <div className="bg-white rounded-lg border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12"></TableHead>
              <TableHead>{t("admin.categories.category")}</TableHead>
              <TableHead>{t("admin.categories.items")}</TableHead>
              <TableHead>{t("admin.categories.status")}</TableHead>
              <TableHead>{t("admin.categories.translations")}</TableHead>
              <TableHead className="w-24">{t("admin.categories.actions")}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {categories.map((category) => (
              <TableRow key={category.id}>
                <TableCell>
                  <GripVertical className="w-4 h-4 text-gray-400 cursor-move" />
                </TableCell>
                <TableCell>
                  <div>
                    <p className="font-medium">{category.name.en}</p>
                    <p className="text-sm text-gray-500">Sort order: {category.sortOrder}</p>
                  </div>
                </TableCell>
                <TableCell>
                  <span className="text-sm text-gray-600">{category.itemCount} items</span>
                </TableCell>
                <TableCell>
                  <Switch checked={category.active} onCheckedChange={() => toggleCategoryActive(category.id)} />
                </TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">EN</span>
                    <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">JA</span>
                    <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">NE</span>
                    <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">HI</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" onClick={() => openDialog(category)}>
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" className="text-red-600">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Category Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingCategory ? t("admin.categories.editCategory") : t("admin.categories.addCategory")}
            </DialogTitle>
            <DialogDescription>{t("admin.categories.categoryFormDescription")}</DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <LabeledField label="English Name" required>
                <Input placeholder="e.g., Appetizers" />
              </LabeledField>
              <LabeledField label="日本語名" required>
                <Input placeholder="例：前菜" />
              </LabeledField>
              <LabeledField label="नेपाली नाम" required>
                <Input placeholder="उदाहरण: खाजा" />
              </LabeledField>
              <LabeledField label="हिन्दी नाम" required>
                <Input placeholder="उदाहरण: स्टार्टर" />
              </LabeledField>
            </div>

            <LabeledField label={t("admin.categories.sortOrder")}>
              <Input type="number" min="1" placeholder="1" />
            </LabeledField>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">{t("admin.categories.active")}</p>
                <p className="text-sm text-gray-600">{t("admin.categories.activeDescription")}</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex items-center gap-3 pt-4 border-t">
              <Button className="bg-saffron hover:bg-saffron/90">
                {editingCategory ? t("admin.categories.updateCategory") : t("admin.categories.createCategory")}
              </Button>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                {t("admin.categories.cancel")}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
