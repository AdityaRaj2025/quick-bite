"use client"

import { useState } from "react"
import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { PageHeader } from "@/lib/ui/layout"
import { Plus, Search, MoreHorizontal, Edit, Trash2, Upload, Download } from "lucide-react"
import { MenuItemDrawer } from "./menu-item-drawer"

interface MenuManagementProps {
  restaurantId: string
}

export function MenuManagement({ restaurantId }: MenuManagementProps) {
  const { t } = useTranslation()
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [selectedItem, setSelectedItem] = useState<any>(null)

  // Mock data
  const categories = [
    { id: "all", name: t("admin.menu.allCategories") },
    { id: "appetizers", name: "Appetizers" },
    { id: "sushi", name: "Sushi & Sashimi" },
    { id: "mains", name: "Main Dishes" },
    { id: "desserts", name: "Desserts" },
  ]

  const menuItems = [
    {
      id: "1",
      name: { en: "Pork Gyoza", ja: "豚餃子", ne: "सुँगुरको मोमो", hi: "पोर्क गयोज़ा" },
      category: "appetizers",
      price: 890,
      active: true,
      description: {
        en: "Pan-fried pork dumplings",
        ja: "焼き豚餃子",
        ne: "तलेको सुँगुरको मोमो",
        hi: "तली हुई पोर्क डम्पलिंग",
      },
      allergens: ["gluten", "soy"],
      image: "/pork-gyoza.png",
    },
    {
      id: "2",
      name: { en: "Salmon Sashimi", ja: "サーモン刺身", ne: "साल्मन साशिमी", hi: "सैल्मन साशिमी" },
      category: "sushi",
      price: 1290,
      active: true,
      description: {
        en: "Fresh salmon slices",
        ja: "新鮮なサーモンスライス",
        ne: "ताजा साल्मन टुक्रा",
        hi: "ताज़ा सैल्मन स्लाइस",
      },
      allergens: ["fish"],
      image: "/salmon-sashimi.png",
    },
    {
      id: "3",
      name: { en: "Chicken Teriyaki Rice", ja: "チキン照り焼き丼", ne: "चिकन टेरियाकी भात", hi: "चिकन तेरियाकी चावल" },
      category: "mains",
      price: 1590,
      active: false,
      description: {
        en: "Grilled chicken with teriyaki sauce over rice",
        ja: "照り焼きチキン丼",
        ne: "टेरियाकी चिकन भातमा",
        hi: "चावल के साथ तेरियाकी चिकन",
      },
      allergens: ["soy", "sesame"],
      image: "/chicken-teriyaki-rice.png",
    },
  ]

  const filteredItems = menuItems.filter((item) => {
    const matchesSearch = item.name.en.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "all" || item.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const openDrawer = (item?: any) => {
    setSelectedItem(item || null)
    setDrawerOpen(true)
  }

  const toggleItemActive = (itemId: string) => {
    // Mock toggle functionality
    console.log("Toggle active for item:", itemId)
  }

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title={t("admin.menu.title")}
        description={t("admin.menu.description")}
        action={
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Upload className="w-4 h-4 mr-2" />
              {t("admin.menu.import")}
            </Button>
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              {t("admin.menu.export")}
            </Button>
            <Button onClick={() => openDrawer()} className="bg-saffron hover:bg-saffron/90">
              <Plus className="w-4 h-4 mr-2" />
              {t("admin.menu.addItem")}
            </Button>
          </div>
        }
      />

      {/* Filters */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder={t("admin.menu.searchItems")}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="px-3 py-2 border border-gray-300 rounded-md text-sm"
        >
          {categories.map((category) => (
            <option key={category.id} value={category.id}>
              {category.name}
            </option>
          ))}
        </select>
      </div>

      {/* Items Table */}
      <div className="bg-white rounded-lg border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>{t("admin.menu.item")}</TableHead>
              <TableHead>{t("admin.menu.category")}</TableHead>
              <TableHead>{t("admin.menu.price")}</TableHead>
              <TableHead>{t("admin.menu.status")}</TableHead>
              <TableHead>{t("admin.menu.translations")}</TableHead>
              <TableHead className="w-12"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredItems.map((item) => (
              <TableRow key={item.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <img
                      src={item.image || "/placeholder.svg"}
                      alt={item.name.en}
                      className="w-12 h-12 rounded-lg object-cover"
                    />
                    <div>
                      <p className="font-medium">{item.name.en}</p>
                      <p className="text-sm text-gray-500">{item.description.en}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="secondary">{categories.find((c) => c.id === item.category)?.name}</Badge>
                </TableCell>
                <TableCell className="font-medium">¥{item.price.toLocaleString()}</TableCell>
                <TableCell>
                  <Switch checked={item.active} onCheckedChange={() => toggleItemActive(item.id)} />
                </TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    <Badge variant="outline" className="text-xs">
                      EN
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      JA
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      NE
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      HI
                    </Badge>
                  </div>
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => openDrawer(item)}>
                        <Edit className="w-4 h-4 mr-2" />
                        {t("admin.menu.edit")}
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-red-600">
                        <Trash2 className="w-4 h-4 mr-2" />
                        {t("admin.menu.delete")}
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <MenuItemDrawer open={drawerOpen} onOpenChange={setDrawerOpen} item={selectedItem} restaurantId={restaurantId} />
    </div>
  )
}
