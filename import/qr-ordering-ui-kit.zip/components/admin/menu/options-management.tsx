"use client"

import { useState } from "react"
import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { PageHeader } from "@/lib/ui/layout"
import { LabeledField } from "@/lib/ui/forms"
import { Plus, Edit, Trash2 } from "lucide-react"

interface OptionsManagementProps {
  restaurantId: string
}

export function OptionsManagement({ restaurantId }: OptionsManagementProps) {
  const { t } = useTranslation()
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingGroup, setEditingGroup] = useState<any>(null)

  // Mock data
  const [optionGroups, setOptionGroups] = useState([
    {
      id: "1",
      name: { en: "Spice Level", ja: "辛さレベル", ne: "तीखोपन स्तर", hi: "मसाला स्तर" },
      type: "single",
      required: true,
      minSelections: 1,
      maxSelections: 1,
      options: [
        { id: "1a", name: { en: "Mild", ja: "マイルド", ne: "हल्का", hi: "हल्का" }, priceAdjustment: 0 },
        { id: "1b", name: { en: "Medium", ja: "中辛", ne: "मध्यम", hi: "मध्यम" }, priceAdjustment: 0 },
        { id: "1c", name: { en: "Hot", ja: "辛口", ne: "तीखो", hi: "तीखा" }, priceAdjustment: 50 },
      ],
    },
    {
      id: "2",
      name: { en: "Extra Toppings", ja: "追加トッピング", ne: "अतिरिक्त टपिङ", hi: "अतिरिक्त टॉपिंग" },
      type: "multiple",
      required: false,
      minSelections: 0,
      maxSelections: 3,
      options: [
        {
          id: "2a",
          name: { en: "Extra Cheese", ja: "チーズ追加", ne: "अतिरिक्त चीज", hi: "अतिरिक्त चीज़" },
          priceAdjustment: 200,
        },
        { id: "2b", name: { en: "Avocado", ja: "アボカド", ne: "एभोकाडो", hi: "एवोकाडो" }, priceAdjustment: 150 },
        {
          id: "2c",
          name: { en: "Extra Sauce", ja: "ソース追加", ne: "अतिरिक्त चटनी", hi: "अतिरिक्त सॉस" },
          priceAdjustment: 100,
        },
      ],
    },
  ])

  const openDialog = (group?: any) => {
    setEditingGroup(group || null)
    setDialogOpen(true)
  }

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title={t("admin.options.title")}
        description={t("admin.options.description")}
        action={
          <Button onClick={() => openDialog()} className="bg-saffron hover:bg-saffron/90">
            <Plus className="w-4 h-4 mr-2" />
            {t("admin.options.addOptionGroup")}
          </Button>
        }
      />

      {/* Option Groups Table */}
      <div className="bg-white rounded-lg border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>{t("admin.options.optionGroup")}</TableHead>
              <TableHead>{t("admin.options.type")}</TableHead>
              <TableHead>{t("admin.options.options")}</TableHead>
              <TableHead>{t("admin.options.required")}</TableHead>
              <TableHead>{t("admin.options.selections")}</TableHead>
              <TableHead className="w-24">{t("admin.options.actions")}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {optionGroups.map((group) => (
              <TableRow key={group.id}>
                <TableCell>
                  <div>
                    <p className="font-medium">{group.name.en}</p>
                    <p className="text-sm text-gray-500">{group.name.ja}</p>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant={group.type === "single" ? "default" : "secondary"}>
                    {group.type === "single" ? t("admin.options.singleChoice") : t("admin.options.multipleChoice")}
                  </Badge>
                </TableCell>
                <TableCell>
                  <span className="text-sm text-gray-600">{group.options.length} options</span>
                </TableCell>
                <TableCell>
                  <Badge variant={group.required ? "destructive" : "outline"}>
                    {group.required ? t("admin.options.required") : t("admin.options.optional")}
                  </Badge>
                </TableCell>
                <TableCell>
                  <span className="text-sm text-gray-600">
                    {group.minSelections}-{group.maxSelections}
                  </span>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" onClick={() => openDialog(group)}>
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" className="text-red-600">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Option Group Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingGroup ? t("admin.options.editOptionGroup") : t("admin.options.addOptionGroup")}
            </DialogTitle>
            <DialogDescription>{t("admin.options.optionGroupFormDescription")}</DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {/* Group Settings */}
            <div className="space-y-4">
              <h3 className="font-medium">{t("admin.options.groupSettings")}</h3>

              <div className="grid grid-cols-2 gap-4">
                <LabeledField label="English Name" required>
                  <Input placeholder="e.g., Spice Level" />
                </LabeledField>
                <LabeledField label="日本語名" required>
                  <Input placeholder="例：辛さレベル" />
                </LabeledField>
                <LabeledField label="नेपाली नाम" required>
                  <Input placeholder="उदाहरण: तीखोपन स्तर" />
                </LabeledField>
                <LabeledField label="हिन्दी नाम" required>
                  <Input placeholder="उदाहरण: मसाला स्तर" />
                </LabeledField>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <LabeledField label={t("admin.options.selectionType")}>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-md">
                    <option value="single">{t("admin.options.singleChoice")}</option>
                    <option value="multiple">{t("admin.options.multipleChoice")}</option>
                  </select>
                </LabeledField>
                <LabeledField label={t("admin.options.minSelections")}>
                  <Input type="number" min="0" placeholder="0" />
                </LabeledField>
                <LabeledField label={t("admin.options.maxSelections")}>
                  <Input type="number" min="1" placeholder="1" />
                </LabeledField>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">{t("admin.options.required")}</p>
                  <p className="text-sm text-gray-600">{t("admin.options.requiredDescription")}</p>
                </div>
                <Switch />
              </div>
            </div>

            {/* Options List */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-medium">{t("admin.options.options")}</h3>
                <Button variant="outline" size="sm">
                  <Plus className="w-4 h-4 mr-2" />
                  {t("admin.options.addOption")}
                </Button>
              </div>

              <div className="space-y-3">
                {/* Mock option items */}
                <div className="p-4 border rounded-lg">
                  <div className="grid grid-cols-5 gap-4 items-center">
                    <Input placeholder="English name" />
                    <Input placeholder="日本語名" />
                    <Input placeholder="नेपाली नाम" />
                    <Input placeholder="हिन्दी नाम" />
                    <div className="flex items-center gap-2">
                      <span className="text-sm">¥</span>
                      <Input type="number" placeholder="0" className="w-20" />
                      <Button variant="ghost" size="sm" className="text-red-600">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-4 border-t">
              <Button className="bg-saffron hover:bg-saffron/90">
                {editingGroup ? t("admin.options.updateOptionGroup") : t("admin.options.createOptionGroup")}
              </Button>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                {t("admin.options.cancel")}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
