"use client"

import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { PageHeader } from "@/lib/ui/layout"
import { Printer, Monitor, Settings, TestTube } from "lucide-react"

interface PrintersManagementProps {
  restaurantId: string
}

export function PrintersManagement({ restaurantId }: PrintersManagementProps) {
  const { t } = useTranslation()

  return (
    <div className="p-6 space-y-6">
      <PageHeader title={t("admin.printers.title")} description={t("admin.printers.description")} />

      {/* KDS Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Monitor className="w-5 h-5" />
            {t("admin.printers.kdsSettings")}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">{t("admin.printers.enableKDS")}</p>
              <p className="text-sm text-gray-600">{t("admin.printers.enableKDSDescription")}</p>
            </div>
            <Switch defaultChecked />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">{t("admin.printers.soundNotifications")}</p>
              <p className="text-sm text-gray-600">{t("admin.printers.soundNotificationsDescription")}</p>
            </div>
            <Switch defaultChecked />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">{t("admin.printers.autoSort")}</p>
              <p className="text-sm text-gray-600">{t("admin.printers.autoSortDescription")}</p>
            </div>
            <Switch defaultChecked />
          </div>

          <div className="pt-4 border-t">
            <Button variant="outline">
              <Settings className="w-4 h-4 mr-2" />
              {t("admin.printers.configureKDS")}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Printer Setup */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Printer className="w-5 h-5" />
            {t("admin.printers.printerSetup")}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <h4 className="font-medium text-blue-900 mb-2">{t("admin.printers.cloudPrintNote")}</h4>
            <p className="text-sm text-blue-800 mb-3">{t("admin.printers.cloudPrintDescription")}</p>
            <Button variant="outline" size="sm">
              {t("admin.printers.learnMore")}
            </Button>
          </div>

          <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
            <h4 className="font-medium text-gray-900 mb-2">{t("admin.printers.localPrintBridge")}</h4>
            <p className="text-sm text-gray-600 mb-3">{t("admin.printers.localPrintBridgeDescription")}</p>
            <div className="space-y-2">
              <p className="text-sm">
                <strong>1.</strong> {t("admin.printers.step1")}
              </p>
              <p className="text-sm">
                <strong>2.</strong> {t("admin.printers.step2")}
              </p>
              <p className="text-sm">
                <strong>3.</strong> {t("admin.printers.step3")}
              </p>
            </div>
            <div className="mt-3">
              <Button variant="outline" size="sm">
                {t("admin.printers.downloadBridge")}
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="font-medium">{t("admin.printers.connectedPrinters")}</h4>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  <Printer className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="font-medium">Kitchen Printer</p>
                    <p className="text-sm text-gray-500">Epson TM-T88VI</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="default">{t("admin.printers.connected")}</Badge>
                  <Button variant="ghost" size="sm">
                    <TestTube className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  <Printer className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="font-medium">Receipt Printer</p>
                    <p className="text-sm text-gray-500">Star TSP143III</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">{t("admin.printers.offline")}</Badge>
                  <Button variant="ghost" size="sm">
                    <TestTube className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t">
            <Button className="bg-saffron hover:bg-saffron/90">
              <TestTube className="w-4 h-4 mr-2" />
              {t("admin.printers.testPrint")}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
