"use client"

import type React from "react"

import { useState } from "react"
import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Badge } from "@/components/ui/badge"
import {
  LayoutDashboard,
  MenuIcon,
  FolderOpen,
  Settings,
  QrCode,
  Users,
  Printer,
  Clock,
  BarChart3,
  Search,
  Globe,
  User,
  ChevronDown,
  Bell,
} from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

interface AdminShellProps {
  children: React.ReactNode
  restaurantId: string
}

const navigationItems = [
  { icon: LayoutDashboard, label: "dashboard", href: "" },
  { icon: MenuIcon, label: "menu", href: "/menu" },
  { icon: FolderOpen, label: "categories", href: "/categories" },
  { icon: Settings, label: "options", href: "/options" },
  { icon: QrCode, label: "tablesQr", href: "/tables" },
  { icon: Users, label: "staff", href: "/staff" },
  { icon: Printer, label: "printers", href: "/printers" },
  { icon: Clock, label: "hoursSettings", href: "/settings" },
  { icon: BarChart3, label: "analytics", href: "/analytics" },
]

export function AdminShell({ children, restaurantId }: AdminShellProps) {
  const { t } = useTranslation()
  const pathname = usePathname()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const currentRestaurant = {
    id: restaurantId,
    name: "Sakura Sushi",
    plan: "Pro",
  }

  const Sidebar = ({ mobile = false }: { mobile?: boolean }) => (
    <div className={cn("flex flex-col h-full bg-white border-r border-gray-200", mobile ? "w-full" : "w-64")}>
      {/* Logo */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-saffron rounded-lg flex items-center justify-center">
            <QrCode className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-lg text-gray-900">QR Order</h1>
            <p className="text-sm text-gray-500">{t("admin.title")}</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1">
        {navigationItems.map((item) => {
          const href = `/admin/${restaurantId}${item.href}`
          const isActive = pathname === href

          return (
            <Link
              key={item.label}
              href={href}
              onClick={() => mobile && setSidebarOpen(false)}
              className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                isActive ? "bg-saffron text-white" : "text-gray-700 hover:bg-gray-100",
              )}
            >
              <item.icon className="w-5 h-5" />
              {t(`admin.nav.${item.label}`)}
            </Link>
          )
        })}
      </nav>

      {/* Restaurant Info */}
      <div className="p-4 border-t border-gray-200">
        <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
          <div className="w-10 h-10 bg-deep-green rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-sm">{currentRestaurant.name.charAt(0)}</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-medium text-sm text-gray-900 truncate">{currentRestaurant.name}</p>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="text-xs">
                {currentRestaurant.plan}
              </Badge>
            </div>
          </div>
        </div>
      </div>
    </div>
  )

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block">
        <Sidebar />
      </div>

      {/* Mobile Sidebar */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="p-0 w-80">
          <Sidebar mobile />
        </SheetContent>
      </Sheet>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Topbar */}
        <header className="bg-white border-b border-gray-200 px-4 lg:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {/* Mobile Menu Button */}
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="sm" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
                    <MenuIcon className="w-5 h-5" />
                  </Button>
                </SheetTrigger>
              </Sheet>

              {/* Restaurant Switcher */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center gap-2">
                    <div className="w-6 h-6 bg-deep-green rounded flex items-center justify-center">
                      <span className="text-white font-bold text-xs">{currentRestaurant.name.charAt(0)}</span>
                    </div>
                    <span className="font-medium">{currentRestaurant.name}</span>
                    <ChevronDown className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-64">
                  <DropdownMenuItem>
                    <div className="flex items-center gap-3 w-full">
                      <div className="w-8 h-8 bg-deep-green rounded flex items-center justify-center">
                        <span className="text-white font-bold text-sm">{currentRestaurant.name.charAt(0)}</span>
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">{currentRestaurant.name}</p>
                        <p className="text-sm text-gray-500">{currentRestaurant.plan} Plan</p>
                      </div>
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>{t("admin.addRestaurant")}</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            <div className="flex items-center gap-4">
              {/* Search */}
              <div className="hidden md:block relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input placeholder={t("admin.search")} className="pl-10 w-64" />
              </div>

              {/* Language Selector */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm">
                    <Globe className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>English</DropdownMenuItem>
                  <DropdownMenuItem>日本語</DropdownMenuItem>
                  <DropdownMenuItem>नेपाली</DropdownMenuItem>
                  <DropdownMenuItem>हिन्दी</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Notifications */}
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="w-4 h-4" />
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-accent-red rounded-full"></span>
              </Button>

              {/* Profile Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm">
                    <User className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>{t("admin.profile")}</DropdownMenuItem>
                  <DropdownMenuItem>{t("admin.settings")}</DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>{t("admin.signOut")}</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto">{children}</main>
      </div>
    </div>
  )
}
