"use client"

import { useTranslation } from "react-i18next"
import { Input } from "@/components/ui/input"
import { LabeledField } from "@/lib/ui/forms"

interface TablesSetupStepProps {
  data: any
  updateData: (data: any) => void
}

export function TablesSetupStep({ data, updateData }: TablesSetupStepProps) {
  const { t } = useTranslation()

  const handleChange = (field: string, value: string | number) => {
    updateData({
      tables: {
        ...data.tables,
        [field]: value,
      },
    })
  }

  return (
    <div className="space-y-6">
      <LabeledField label={t("admin.onboarding.tableCount")} helpText={t("admin.onboarding.tableCountHelp")}>
        <Input
          type="number"
          min="1"
          max="100"
          value={data.tables.count}
          onChange={(e) => handleChange("count", Number.parseInt(e.target.value) || 1)}
        />
      </LabeledField>

      <LabeledField label={t("admin.onboarding.tablePrefix")} helpText={t("admin.onboarding.tablePrefixHelp")}>
        <Input
          value={data.tables.prefix}
          onChange={(e) => handleChange("prefix", e.target.value)}
          placeholder="T"
          maxLength={3}
        />
      </LabeledField>

      <div className="p-4 bg-blue-50 rounded-lg">
        <h4 className="font-medium text-blue-900 mb-2">{t("admin.onboarding.tablePreview")}</h4>
        <div className="flex flex-wrap gap-2">
          {Array.from({ length: Math.min(data.tables.count, 8) }, (_, i) => (
            <span key={i} className="px-2 py-1 bg-white rounded text-sm font-mono">
              {data.tables.prefix}-{String(i + 1).padStart(2, "0")}
            </span>
          ))}
          {data.tables.count > 8 && (
            <span className="px-2 py-1 text-gray-500 text-sm">
              +{data.tables.count - 8} {t("admin.onboarding.more")}
            </span>
          )}
        </div>
      </div>
    </div>
  )
}
