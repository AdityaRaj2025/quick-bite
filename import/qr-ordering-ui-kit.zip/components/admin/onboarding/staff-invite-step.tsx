"use client"

import { useState } from "react"
import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Plus, X } from "lucide-react"

interface StaffInviteStepProps {
  data: any
  updateData: (data: any) => void
}

export function StaffInviteStep({ data, updateData }: StaffInviteStepProps) {
  const { t } = useTranslation()
  const [email, setEmail] = useState("")
  const [role, setRole] = useState("staff")

  const addInvite = () => {
    if (email && role) {
      const newInvites = [...data.staff.invites, { email, role }]
      updateData({
        staff: {
          invites: newInvites,
        },
      })
      setEmail("")
      setRole("staff")
    }
  }

  const removeInvite = (index: number) => {
    const newInvites = data.staff.invites.filter((_: any, i: number) => i !== index)
    updateData({
      staff: {
        invites: newInvites,
      },
    })
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="font-medium mb-2">{t("admin.onboarding.inviteStaff")}</h3>
        <p className="text-sm text-gray-600">{t("admin.onboarding.inviteStaffHelp")}</p>
      </div>

      <div className="flex gap-3">
        <div className="flex-1">
          <Input
            type="email"
            placeholder={t("admin.onboarding.emailAddress")}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <Select value={role} onValueChange={setRole}>
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="owner">{t("admin.roles.owner")}</SelectItem>
            <SelectItem value="manager">{t("admin.roles.manager")}</SelectItem>
            <SelectItem value="staff">{t("admin.roles.staff")}</SelectItem>
            <SelectItem value="kitchen">{t("admin.roles.kitchen")}</SelectItem>
          </SelectContent>
        </Select>
        <Button onClick={addInvite} disabled={!email} size="sm">
          <Plus className="w-4 h-4" />
        </Button>
      </div>

      {data.staff.invites.length > 0 && (
        <div className="space-y-2">
          <h4 className="font-medium text-sm">{t("admin.onboarding.pendingInvites")}</h4>
          {data.staff.invites.map((invite: any, index: number) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <span className="text-sm">{invite.email}</span>
                <Badge variant="secondary" className="text-xs">
                  {t(`admin.roles.${invite.role}`)}
                </Badge>
              </div>
              <Button variant="ghost" size="sm" onClick={() => removeInvite(index)}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>
      )}

      <div className="p-4 bg-blue-50 rounded-lg">
        <p className="text-sm text-blue-800">{t("admin.onboarding.skipInviteNote")}</p>
      </div>
    </div>
  )
}
