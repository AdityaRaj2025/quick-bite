"use client"

import { useTranslation } from "react-i18next"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { LabeledField } from "@/lib/ui/forms"

interface TaxSetupStepProps {
  data: any
  updateData: (data: any) => void
}

export function TaxSetupStep({ data, updateData }: TaxSetupStepProps) {
  const { t } = useTranslation()

  const handleChange = (field: string, value: number | boolean) => {
    updateData({
      taxes: {
        ...data.taxes,
        [field]: value,
      },
    })
  }

  return (
    <div className="space-y-6">
      <LabeledField label={t("admin.onboarding.taxRate")} helpText={t("admin.onboarding.taxRateHelp")}>
        <div className="relative">
          <Input
            type="number"
            min="0"
            max="100"
            step="0.1"
            value={data.taxes.taxRate}
            onChange={(e) => handleChange("taxRate", Number.parseFloat(e.target.value) || 0)}
            className="pr-8"
          />
          <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500">%</span>
        </div>
      </LabeledField>

      <LabeledField label={t("admin.onboarding.serviceCharge")} helpText={t("admin.onboarding.serviceChargeHelp")}>
        <div className="relative">
          <Input
            type="number"
            min="0"
            max="100"
            step="0.1"
            value={data.taxes.serviceChargeRate}
            onChange={(e) => handleChange("serviceChargeRate", Number.parseFloat(e.target.value) || 0)}
            className="pr-8"
          />
          <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500">%</span>
        </div>
      </LabeledField>

      <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
        <div>
          <Label className="text-sm font-medium">{t("admin.onboarding.taxInclusive")}</Label>
          <p className="text-sm text-gray-600">{t("admin.onboarding.taxInclusiveHelp")}</p>
        </div>
        <Switch
          checked={data.taxes.taxInclusive}
          onCheckedChange={(checked) => handleChange("taxInclusive", checked)}
        />
      </div>
    </div>
  )
}
