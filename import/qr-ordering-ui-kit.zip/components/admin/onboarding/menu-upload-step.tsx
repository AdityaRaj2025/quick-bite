"use client"

import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Upload, FileText, Plus } from "lucide-react"

interface MenuUploadStepProps {
  data: any
  updateData: (data: any) => void
}

export function MenuUploadStep({ data, updateData }: MenuUploadStepProps) {
  const { t } = useTranslation()

  const handleMethodChange = (method: string) => {
    updateData({
      menu: {
        ...data.menu,
        uploadMethod: method,
      },
    })
  }

  return (
    <div className="space-y-6">
      <div>
        <Label className="text-base font-medium">{t("admin.onboarding.menuSetupMethod")}</Label>
        <p className="text-sm text-gray-600 mt-1">{t("admin.onboarding.menuSetupMethodHelp")}</p>
      </div>

      <RadioGroup value={data.menu.uploadMethod} onValueChange={handleMethodChange}>
        <div className="space-y-4">
          <div className="flex items-start space-x-3 p-4 border rounded-lg hover:bg-gray-50">
            <RadioGroupItem value="sample" id="sample" className="mt-1" />
            <div className="flex-1">
              <Label htmlFor="sample" className="font-medium cursor-pointer">
                {t("admin.onboarding.useSampleMenu")}
              </Label>
              <p className="text-sm text-gray-600 mt-1">{t("admin.onboarding.useSampleMenuHelp")}</p>
            </div>
            <FileText className="w-5 h-5 text-gray-400" />
          </div>

          <div className="flex items-start space-x-3 p-4 border rounded-lg hover:bg-gray-50">
            <RadioGroupItem value="csv" id="csv" className="mt-1" />
            <div className="flex-1">
              <Label htmlFor="csv" className="font-medium cursor-pointer">
                {t("admin.onboarding.uploadCSV")}
              </Label>
              <p className="text-sm text-gray-600 mt-1">{t("admin.onboarding.uploadCSVHelp")}</p>
              {data.menu.uploadMethod === "csv" && (
                <div className="mt-3">
                  <Button variant="outline" size="sm">
                    <Upload className="w-4 h-4 mr-2" />
                    {t("admin.onboarding.chooseFile")}
                  </Button>
                </div>
              )}
            </div>
            <Upload className="w-5 h-5 text-gray-400" />
          </div>

          <div className="flex items-start space-x-3 p-4 border rounded-lg hover:bg-gray-50">
            <RadioGroupItem value="manual" id="manual" className="mt-1" />
            <div className="flex-1">
              <Label htmlFor="manual" className="font-medium cursor-pointer">
                {t("admin.onboarding.createManually")}
              </Label>
              <p className="text-sm text-gray-600 mt-1">{t("admin.onboarding.createManuallyHelp")}</p>
            </div>
            <Plus className="w-5 h-5 text-gray-400" />
          </div>
        </div>
      </RadioGroup>
    </div>
  )
}
