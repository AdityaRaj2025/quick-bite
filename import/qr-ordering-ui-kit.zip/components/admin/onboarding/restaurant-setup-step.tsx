"use client"

import { useTranslation } from "react-i18next"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { LabeledField } from "@/lib/ui/forms"

interface RestaurantSetupStepProps {
  data: any
  updateData: (data: any) => void
}

export function RestaurantSetupStep({ data, updateData }: RestaurantSetupStepProps) {
  const { t } = useTranslation()

  const handleChange = (field: string, value: string) => {
    updateData({
      restaurant: {
        ...data.restaurant,
        [field]: value,
      },
    })
  }

  return (
    <div className="space-y-6">
      <LabeledField label={t("admin.onboarding.restaurantName")} required>
        <Input
          value={data.restaurant.name}
          onChange={(e) => handleChange("name", e.target.value)}
          placeholder={t("admin.onboarding.restaurantNamePlaceholder")}
        />
      </LabeledField>

      <LabeledField label={t("admin.onboarding.primaryLanguage")} required>
        <Select value={data.restaurant.locale} onValueChange={(value) => handleChange("locale", value)}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="en">English</SelectItem>
            <SelectItem value="ja">日本語 (Japanese)</SelectItem>
            <SelectItem value="ne">नेपाली (Nepali)</SelectItem>
            <SelectItem value="hi">हिन्दी (Hindi)</SelectItem>
          </SelectContent>
        </Select>
      </LabeledField>

      <LabeledField label={t("admin.onboarding.timezone")} required>
        <Select value={data.restaurant.timezone} onValueChange={(value) => handleChange("timezone", value)}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Asia/Tokyo">Asia/Tokyo (JST)</SelectItem>
            <SelectItem value="Asia/Kathmandu">Asia/Kathmandu (NPT)</SelectItem>
            <SelectItem value="Asia/Kolkata">Asia/Kolkata (IST)</SelectItem>
            <SelectItem value="UTC">UTC</SelectItem>
          </SelectContent>
        </Select>
      </LabeledField>
    </div>
  )
}
