"use client"

import { useState } from "react"
import { useTranslation } from "react-i18next"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { RestaurantSetupStep } from "./restaurant-setup-step"
import { TaxSetupStep } from "./tax-setup-step"
import { TablesSetupStep } from "./tables-setup-step"
import { MenuUploadStep } from "./menu-upload-step"
import { StaffInviteStep } from "./staff-invite-step"

interface OnboardingData {
  restaurant: {
    name: string
    locale: string
    timezone: string
  }
  taxes: {
    taxRate: number
    serviceChargeRate: number
    taxInclusive: boolean
  }
  tables: {
    count: number
    prefix: string
  }
  menu: {
    uploadMethod: "sample" | "csv" | "manual"
    file?: File
  }
  staff: {
    invites: Array<{ email: string; role: string }>
  }
}

const steps = [
  { id: "restaurant", title: "Restaurant Setup", component: RestaurantSetupStep },
  { id: "taxes", title: "Tax & Service Charges", component: TaxSetupStep },
  { id: "tables", title: "Tables Setup", component: TablesSetupStep },
  { id: "menu", title: "Menu Upload", component: MenuUploadStep },
  { id: "staff", title: "Staff Invitations", component: StaffInviteStep },
]

export function OnboardingWizard() {
  const { t } = useTranslation()
  const [currentStep, setCurrentStep] = useState(0)
  const [data, setData] = useState<OnboardingData>({
    restaurant: { name: "", locale: "en", timezone: "Asia/Tokyo" },
    taxes: { taxRate: 10, serviceChargeRate: 0, taxInclusive: true },
    tables: { count: 10, prefix: "T" },
    menu: { uploadMethod: "sample" },
    staff: { invites: [] },
  })

  const updateData = (stepData: Partial<OnboardingData>) => {
    setData((prev) => ({ ...prev, ...stepData }))
  }

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    }
  }

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleComplete = async () => {
    // Save onboarding data and redirect to dashboard
    console.log("Onboarding completed:", data)
    // Redirect to admin dashboard
    window.location.href = `/admin/${data.restaurant.name.toLowerCase().replace(/\s+/g, "-")}`
  }

  const CurrentStepComponent = steps[currentStep].component
  const progress = ((currentStep + 1) / steps.length) * 100

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-saffron rounded-2xl flex items-center justify-center mx-auto mb-4">
            <span className="text-2xl font-bold text-white">QR</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{t("admin.onboarding.title")}</h1>
          <p className="text-gray-600">{t("admin.onboarding.description")}</p>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">
              {t("admin.onboarding.step")} {currentStep + 1} {t("admin.onboarding.of")} {steps.length}
            </span>
            <span className="text-sm text-gray-500">
              {Math.round(progress)}% {t("admin.onboarding.complete")}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Step Content */}
        <Card>
          <CardContent className="p-8">
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-2">{steps[currentStep].title}</h2>
            </div>

            <CurrentStepComponent data={data} updateData={updateData} />

            {/* Navigation */}
            <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-200">
              <Button variant="ghost" onClick={prevStep} disabled={currentStep === 0}>
                <ChevronLeft className="w-4 h-4 mr-1" />
                {t("admin.onboarding.previous")}
              </Button>

              <div className="flex items-center gap-2">
                {steps.map((_, index) => (
                  <div
                    key={index}
                    className={`w-2 h-2 rounded-full ${index <= currentStep ? "bg-saffron" : "bg-gray-300"}`}
                  />
                ))}
              </div>

              {currentStep === steps.length - 1 ? (
                <Button onClick={handleComplete} className="bg-saffron hover:bg-saffron/90">
                  {t("admin.onboarding.complete")}
                </Button>
              ) : (
                <Button onClick={nextStep} className="bg-saffron hover:bg-saffron/90">
                  {t("admin.onboarding.next")}
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
