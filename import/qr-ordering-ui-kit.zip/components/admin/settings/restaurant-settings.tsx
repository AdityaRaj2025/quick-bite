"use client"

import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PageHeader } from "@/lib/ui/layout"
import { LabeledField } from "@/lib/ui/forms"
import { Clock, Globe, CreditCard, Bell } from "lucide-react"

interface RestaurantSettingsProps {
  restaurantId: string
}

export function RestaurantSettings({ restaurantId }: RestaurantSettingsProps) {
  const { t } = useTranslation()

  return (
    <div className="p-6 space-y-6">
      <PageHeader title={t("admin.settings.title")} description={t("admin.settings.description")} />

      {/* Restaurant Info */}
      <Card>
        <CardHeader>
          <CardTitle>{t("admin.settings.restaurantInfo")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <LabeledField label={t("admin.settings.restaurantName")} required>
              <Input defaultValue="Sakura Sushi" />
            </LabeledField>
            <LabeledField label={t("admin.settings.cuisine")}>
              <Input defaultValue="Japanese" />
            </LabeledField>
          </div>

          <LabeledField label={t("admin.settings.description")}>
            <Textarea defaultValue="Authentic Japanese cuisine with fresh sushi and traditional dishes" rows={3} />
          </LabeledField>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <LabeledField label={t("admin.settings.phone")}>
              <Input defaultValue="+81-3-1234-5678" />
            </LabeledField>
            <LabeledField label={t("admin.settings.email")}>
              <Input type="email" defaultValue="info@sakurasushi.com" />
            </LabeledField>
          </div>

          <LabeledField label={t("admin.settings.address")}>
            <Textarea defaultValue="1-2-3 Shibuya, Tokyo 150-0002, Japan" rows={2} />
          </LabeledField>
        </CardContent>
      </Card>

      {/* Operating Hours */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            {t("admin.settings.operatingHours")}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"].map((day) => (
            <div key={day} className="flex items-center gap-4">
              <div className="w-24">
                <span className="font-medium">{t(`admin.settings.${day}`)}</span>
              </div>
              <Switch defaultChecked={day !== "sunday"} />
              <div className="flex items-center gap-2">
                <Input type="time" defaultValue="11:00" className="w-32" />
                <span>-</span>
                <Input type="time" defaultValue="22:00" className="w-32" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Localization */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="w-5 h-5" />
            {t("admin.settings.localization")}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <LabeledField label={t("admin.settings.primaryLanguage")}>
              <Select defaultValue="ja">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="ja">日本語</SelectItem>
                  <SelectItem value="ne">नेपाली</SelectItem>
                  <SelectItem value="hi">हिन्दी</SelectItem>
                </SelectContent>
              </Select>
            </LabeledField>
            <LabeledField label={t("admin.settings.timezone")}>
              <Select defaultValue="Asia/Tokyo">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Asia/Tokyo">Asia/Tokyo (JST)</SelectItem>
                  <SelectItem value="Asia/Kathmandu">Asia/Kathmandu (NPT)</SelectItem>
                  <SelectItem value="Asia/Kolkata">Asia/Kolkata (IST)</SelectItem>
                  <SelectItem value="UTC">UTC</SelectItem>
                </SelectContent>
              </Select>
            </LabeledField>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <LabeledField label={t("admin.settings.currency")}>
              <Select defaultValue="JPY">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="JPY">Japanese Yen (¥)</SelectItem>
                  <SelectItem value="USD">US Dollar ($)</SelectItem>
                  <SelectItem value="EUR">Euro (€)</SelectItem>
                  <SelectItem value="NPR">Nepalese Rupee (₨)</SelectItem>
                  <SelectItem value="INR">Indian Rupee (₹)</SelectItem>
                </SelectContent>
              </Select>
            </LabeledField>
            <LabeledField label={t("admin.settings.dateFormat")}>
              <Select defaultValue="YYYY-MM-DD">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                  <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                  <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                </SelectContent>
              </Select>
            </LabeledField>
          </div>
        </CardContent>
      </Card>

      {/* Payment & Tax */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="w-5 h-5" />
            {t("admin.settings.paymentTax")}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <LabeledField label={t("admin.settings.taxRate")}>
              <div className="relative">
                <Input type="number" step="0.1" defaultValue="10" className="pr-8" />
                <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500">%</span>
              </div>
            </LabeledField>
            <LabeledField label={t("admin.settings.serviceCharge")}>
              <div className="relative">
                <Input type="number" step="0.1" defaultValue="0" className="pr-8" />
                <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500">%</span>
              </div>
            </LabeledField>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">{t("admin.settings.taxInclusive")}</p>
              <p className="text-sm text-gray-600">{t("admin.settings.taxInclusiveDescription")}</p>
            </div>
            <Switch defaultChecked />
          </div>
        </CardContent>
      </Card>

      {/* Notifications */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5" />
            {t("admin.settings.notifications")}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">{t("admin.settings.emailNotifications")}</p>
              <p className="text-sm text-gray-600">{t("admin.settings.emailNotificationsDescription")}</p>
            </div>
            <Switch defaultChecked />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">{t("admin.settings.orderAlerts")}</p>
              <p className="text-sm text-gray-600">{t("admin.settings.orderAlertsDescription")}</p>
            </div>
            <Switch defaultChecked />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">{t("admin.settings.dailyReports")}</p>
              <p className="text-sm text-gray-600">{t("admin.settings.dailyReportsDescription")}</p>
            </div>
            <Switch defaultChecked />
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button className="bg-saffron hover:bg-saffron/90">{t("admin.settings.saveSettings")}</Button>
      </div>
    </div>
  )
}
