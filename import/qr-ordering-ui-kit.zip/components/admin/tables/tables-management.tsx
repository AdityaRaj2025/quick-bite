"use client"

import { useState } from "react"
import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { PageHeader } from "@/lib/ui/layout"
import { LabeledField } from "@/lib/ui/forms"
import { Plus, QrCode, Edit, Trash2, ExternalLink, MoreHorizontal } from "lucide-react"
import { QRCodeGenerator } from "./qr-code-generator"

interface TablesManagementProps {
  restaurantId: string
}

export function TablesManagement({ restaurantId }: TablesManagementProps) {
  const { t } = useTranslation()
  const [dialogOpen, setDialogOpen] = useState(false)
  const [qrDialogOpen, setQrDialogOpen] = useState(false)
  const [editingTable, setEditingTable] = useState<any>(null)
  const [selectedTables, setSelectedTables] = useState<string[]>([])
  const [selectedTableForQR, setSelectedTableForQR] = useState<any>(null)

  // Mock data
  const [tables, setTables] = useState([
    {
      id: "1",
      code: "T-01",
      displayName: "Table 1 - Window",
      capacity: 4,
      active: true,
      qrGenerated: true,
      lastQrGenerated: "2024-01-15",
    },
    {
      id: "2",
      code: "T-02",
      displayName: "Table 2 - Corner",
      capacity: 2,
      active: true,
      qrGenerated: true,
      lastQrGenerated: "2024-01-15",
    },
    {
      id: "3",
      code: "T-03",
      displayName: "Table 3 - Center",
      capacity: 6,
      active: true,
      qrGenerated: false,
      lastQrGenerated: null,
    },
    {
      id: "4",
      code: "T-04",
      displayName: "Table 4 - Patio",
      capacity: 4,
      active: false,
      qrGenerated: true,
      lastQrGenerated: "2024-01-10",
    },
  ])

  const openDialog = (table?: any) => {
    setEditingTable(table || null)
    setDialogOpen(true)
  }

  const openQRDialog = (table?: any) => {
    setSelectedTableForQR(table || null)
    setQrDialogOpen(true)
  }

  const toggleTableSelection = (tableId: string) => {
    setSelectedTables((prev) => (prev.includes(tableId) ? prev.filter((id) => id !== tableId) : [...prev, tableId]))
  }

  const selectAllTables = () => {
    setSelectedTables(selectedTables.length === tables.length ? [] : tables.map((t) => t.id))
  }

  const generateBatchQR = () => {
    const selectedTableData = tables.filter((t) => selectedTables.includes(t.id))
    setSelectedTableForQR(selectedTableData)
    setQrDialogOpen(true)
  }

  const getDeepLink = (tableCode: string, lang = "en") => {
    return `${window.location.origin}/t/${restaurantId}/${tableCode}${lang !== "en" ? `?lang=${lang}` : ""}`
  }

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title={t("admin.tables.title")}
        description={t("admin.tables.description")}
        action={
          <div className="flex items-center gap-2">
            {selectedTables.length > 0 && (
              <Button variant="outline" onClick={generateBatchQR}>
                <QrCode className="w-4 h-4 mr-2" />
                {t("admin.tables.generateBatchQR")} ({selectedTables.length})
              </Button>
            )}
            <Button onClick={() => openDialog()} className="bg-saffron hover:bg-saffron/90">
              <Plus className="w-4 h-4 mr-2" />
              {t("admin.tables.addTable")}
            </Button>
          </div>
        }
      />

      {/* Tables Table */}
      <div className="bg-white rounded-lg border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12">
                <Checkbox checked={selectedTables.length === tables.length} onCheckedChange={selectAllTables} />
              </TableHead>
              <TableHead>{t("admin.tables.table")}</TableHead>
              <TableHead>{t("admin.tables.capacity")}</TableHead>
              <TableHead>{t("admin.tables.status")}</TableHead>
              <TableHead>{t("admin.tables.qrCode")}</TableHead>
              <TableHead>{t("admin.tables.deepLink")}</TableHead>
              <TableHead className="w-24">{t("admin.tables.actions")}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {tables.map((table) => (
              <TableRow key={table.id}>
                <TableCell>
                  <Checkbox
                    checked={selectedTables.includes(table.id)}
                    onCheckedChange={() => toggleTableSelection(table.id)}
                  />
                </TableCell>
                <TableCell>
                  <div>
                    <p className="font-medium">{table.code}</p>
                    <p className="text-sm text-gray-500">{table.displayName}</p>
                  </div>
                </TableCell>
                <TableCell>
                  <span className="text-sm">{table.capacity} seats</span>
                </TableCell>
                <TableCell>
                  <Badge variant={table.active ? "default" : "secondary"}>
                    {table.active ? t("admin.tables.active") : t("admin.tables.inactive")}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    {table.qrGenerated ? (
                      <Badge variant="outline" className="text-green-600">
                        {t("admin.tables.generated")}
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-gray-500">
                        {t("admin.tables.notGenerated")}
                      </Badge>
                    )}
                    <Button variant="ghost" size="sm" onClick={() => openQRDialog(table)}>
                      <QrCode className="w-4 h-4" />
                    </Button>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <code className="text-xs bg-gray-100 px-2 py-1 rounded">
                      /t/{restaurantId}/{table.code}
                    </code>
                    <Button variant="ghost" size="sm" onClick={() => window.open(getDeepLink(table.code), "_blank")}>
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  </div>
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => openDialog(table)}>
                        <Edit className="w-4 h-4 mr-2" />
                        {t("admin.tables.edit")}
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => openQRDialog(table)}>
                        <QrCode className="w-4 h-4 mr-2" />
                        {t("admin.tables.generateQR")}
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-red-600">
                        <Trash2 className="w-4 h-4 mr-2" />
                        {t("admin.tables.delete")}
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Table Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingTable ? t("admin.tables.editTable") : t("admin.tables.addTable")}</DialogTitle>
            <DialogDescription>{t("admin.tables.tableFormDescription")}</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <LabeledField label={t("admin.tables.tableCode")} required>
              <Input placeholder="T-01" defaultValue={editingTable?.code} />
            </LabeledField>

            <LabeledField label={t("admin.tables.displayName")} required>
              <Input placeholder="Table 1 - Window" defaultValue={editingTable?.displayName} />
            </LabeledField>

            <LabeledField label={t("admin.tables.capacity")}>
              <Input type="number" min="1" placeholder="4" defaultValue={editingTable?.capacity} />
            </LabeledField>

            <div className="flex items-center gap-3 pt-4 border-t">
              <Button className="bg-saffron hover:bg-saffron/90">
                {editingTable ? t("admin.tables.updateTable") : t("admin.tables.createTable")}
              </Button>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                {t("admin.tables.cancel")}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* QR Code Generator Dialog */}
      <QRCodeGenerator
        open={qrDialogOpen}
        onOpenChange={setQrDialogOpen}
        table={selectedTableForQR}
        restaurantId={restaurantId}
      />
    </div>
  )
}
