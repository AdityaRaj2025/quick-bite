"use client"

import { useState } from "react"
import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { LabeledField } from "@/lib/ui/forms"
import { Download, Printer, Copy, Check } from "lucide-react"

interface QRCodeGeneratorProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  table: any
  restaurantId: string
}

export function QRCodeGenerator({ open, onOpenChange, table, restaurantId }: QRCodeGeneratorProps) {
  const { t } = useTranslation()
  const [format, setFormat] = useState("png")
  const [size, setSize] = useState("256")
  const [language, setLanguage] = useState("en")
  const [copied, setCopied] = useState(false)

  const isBatch = Array.isArray(table)
  const tables = isBatch ? table : table ? [table] : []

  const getDeepLink = (tableCode: string) => {
    const baseUrl = `${window.location.origin}/t/${restaurantId}/${tableCode}`
    return language !== "en" ? `${baseUrl}?lang=${language}` : baseUrl
  }

  const generateQRCodeUrl = (tableCode: string) => {
    const url = getDeepLink(tableCode)
    // Mock QR code generation - in real app, this would call an API
    return `/placeholder.svg?height=${size}&width=${size}&query=QR code for ${url}`
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const downloadQR = (tableCode: string) => {
    const qrUrl = generateQRCodeUrl(tableCode)
    const link = document.createElement("a")
    link.href = qrUrl
    link.download = `qr-${tableCode}.${format}`
    link.click()
  }

  const downloadBatchQR = () => {
    // Mock batch download - in real app, this would generate a ZIP file
    console.log(
      "Downloading batch QR codes for tables:",
      tables.map((t) => t.code),
    )
  }

  const printQR = () => {
    const printWindow = window.open("", "_blank")
    if (!printWindow) return

    const printContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>QR Codes - ${isBatch ? "Batch" : table.code}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .qr-item { 
              display: inline-block; 
              margin: 20px; 
              text-align: center; 
              page-break-inside: avoid;
              border: 1px solid #ddd;
              padding: 20px;
              border-radius: 8px;
            }
            .qr-code { margin-bottom: 10px; }
            .table-info { margin-top: 10px; }
            .table-code { font-size: 18px; font-weight: bold; }
            .table-name { font-size: 14px; color: #666; }
            .deep-link { font-size: 12px; color: #888; margin-top: 5px; }
            @media print {
              .qr-item { margin: 10px; }
            }
          </style>
        </head>
        <body>
          ${tables
            .map(
              (t) => `
            <div class="qr-item">
              <div class="qr-code">
                <img src="${generateQRCodeUrl(t.code)}" alt="QR Code for ${t.code}" width="${size}" height="${size}" />
              </div>
              <div class="table-info">
                <div class="table-code">${t.code}</div>
                <div class="table-name">${t.displayName}</div>
                <div class="deep-link">${getDeepLink(t.code)}</div>
              </div>
            </div>
          `,
            )
            .join("")}
        </body>
      </html>
    `

    printWindow.document.write(printContent)
    printWindow.document.close()
    printWindow.print()
  }

  if (!table) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {isBatch ? t("admin.tables.generateBatchQR") : `${t("admin.tables.generateQR")} - ${table.code}`}
          </DialogTitle>
          <DialogDescription>
            {isBatch ? t("admin.tables.batchQRDescription", { count: tables.length }) : t("admin.tables.qrDescription")}
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="preview" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="preview">{t("admin.tables.preview")}</TabsTrigger>
            <TabsTrigger value="settings">{t("admin.tables.settings")}</TabsTrigger>
          </TabsList>

          <TabsContent value="preview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {tables.map((t) => (
                <div key={t.id} className="border rounded-lg p-4 text-center">
                  <div className="mb-4">
                    <img
                      src={generateQRCodeUrl(t.code) || "/placeholder.svg"}
                      alt={`QR Code for ${t.code}`}
                      className="mx-auto"
                      width={size}
                      height={size}
                    />
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-lg">{t.code}</h3>
                    <p className="text-sm text-gray-600">{t.displayName}</p>
                    <div className="flex items-center gap-2 justify-center">
                      <code className="text-xs bg-gray-100 px-2 py-1 rounded">{getDeepLink(t.code)}</code>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(getDeepLink(t.code))}
                        className="h-6 w-6 p-0"
                      >
                        {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      </Button>
                    </div>
                    {!isBatch && (
                      <Button variant="outline" size="sm" onClick={() => downloadQR(t.code)}>
                        <Download className="w-4 h-4 mr-2" />
                        {t("admin.tables.download")}
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-3 pt-4 border-t">
              {isBatch ? (
                <Button onClick={downloadBatchQR} className="bg-saffron hover:bg-saffron/90">
                  <Download className="w-4 h-4 mr-2" />
                  {t("admin.tables.downloadBatch")}
                </Button>
              ) : (
                <Button onClick={() => downloadQR(table.code)} className="bg-saffron hover:bg-saffron/90">
                  <Download className="w-4 h-4 mr-2" />
                  {t("admin.tables.download")}
                </Button>
              )}
              <Button variant="outline" onClick={printQR}>
                <Printer className="w-4 h-4 mr-2" />
                {t("admin.tables.print")}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <LabeledField label={t("admin.tables.format")}>
                <Select value={format} onValueChange={setFormat}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="png">PNG</SelectItem>
                    <SelectItem value="svg">SVG</SelectItem>
                    <SelectItem value="pdf">PDF</SelectItem>
                  </SelectContent>
                </Select>
              </LabeledField>

              <LabeledField label={t("admin.tables.size")}>
                <Select value={size} onValueChange={setSize}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="128">128x128</SelectItem>
                    <SelectItem value="256">256x256</SelectItem>
                    <SelectItem value="512">512x512</SelectItem>
                    <SelectItem value="1024">1024x1024</SelectItem>
                  </SelectContent>
                </Select>
              </LabeledField>

              <LabeledField label={t("admin.tables.defaultLanguage")}>
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="ja">日本語</SelectItem>
                    <SelectItem value="ne">नेपाली</SelectItem>
                    <SelectItem value="hi">हिन्दी</SelectItem>
                  </SelectContent>
                </Select>
              </LabeledField>
            </div>

            <div className="p-4 bg-blue-50 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">{t("admin.tables.deepLinkFormat")}</h4>
              <div className="space-y-2">
                <code className="block text-sm bg-white p-2 rounded">
                  {window.location.origin}/t/{restaurantId}/[TABLE_CODE]
                </code>
                <code className="block text-sm bg-white p-2 rounded">
                  {window.location.origin}/t/{restaurantId}/[TABLE_CODE]?lang=[LANGUAGE]
                </code>
              </div>
              <p className="text-sm text-blue-800 mt-2">{t("admin.tables.deepLinkDescription")}</p>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
