"use client"

import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { useCart } from "@/hooks/use-cart"
import type { CartItem } from "@/types/cart"

interface CartLineItemProps {
  item: CartItem
}

export function CartLineItem({ item }: CartLineItemProps) {
  const { t } = useTranslation()
  const { updateItemQuantity, removeItem } = useCart()

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("ja-JP", {
      style: "currency",
      currency: "JPY",
      minimumFractionDigits: 0,
    }).format(price)
  }

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity <= 0) {
      removeItem(item.itemId, item.options)
    } else {
      updateItemQuantity(item.itemId, item.options, newQuantity)
    }
  }

  return (
    <div className="flex gap-3 p-3 bg-muted/30 rounded-lg">
      <div className="flex-1 min-w-0">
        <h4 className="font-medium text-sm leading-tight">{item.name}</h4>

        {/* Options */}
        {item.options && item.options.length > 0 && (
          <div className="mt-1 space-y-1">
            {item.options.map((option, index) => (
              <p key={index} className="text-xs text-muted-foreground">
                {option.optionName}: {option.choiceName}
                {option.priceDelta !== 0 && (
                  <span className="ml-1">
                    ({option.priceDelta > 0 ? "+" : ""}
                    {formatPrice(option.priceDelta)})
                  </span>
                )}
              </p>
            ))}
          </div>
        )}

        {/* Price per item */}
        <p className="text-sm font-medium text-primary mt-1">
          {formatPrice(item.totalPrice / item.quantity)} {t("customer.cart.each")}
        </p>
      </div>

      <div className="flex flex-col items-end gap-2">
        {/* Quantity Controls */}
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleQuantityChange(item.quantity - 1)}
            className="h-8 w-8 p-0"
          >
            -
          </Button>
          <span className="w-8 text-center text-sm font-medium">{item.quantity}</span>
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleQuantityChange(item.quantity + 1)}
            className="h-8 w-8 p-0"
          >
            +
          </Button>
        </div>

        {/* Line Total */}
        <p className="text-sm font-semibold">{formatPrice(item.totalPrice)}</p>

        {/* Remove Button */}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => removeItem(item.itemId, item.options)}
          className="h-6 px-2 text-xs text-destructive hover:text-destructive"
        >
          {t("customer.cart.remove")}
        </Button>
      </div>
    </div>
  )
}
