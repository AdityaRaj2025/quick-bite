"use client"

import { useTranslation } from "react-i18next"
import { cn } from "@/lib/utils"
import { CheckCircle, Clock, ChefHat, Bell, Utensils } from "lucide-react"

interface OrderStatusTimelineProps {
  currentStatus: string
  updatedAt: string
}

const statusSteps = [
  { key: "placed", icon: CheckCircle, label: "customer.orderStatus.steps.placed" },
  { key: "acknowledged", icon: Clock, label: "customer.orderStatus.steps.acknowledged" },
  { key: "in_kitchen", icon: ChefHat, label: "customer.orderStatus.steps.inKitchen" },
  { key: "ready", icon: Bell, label: "customer.orderStatus.steps.ready" },
  { key: "served", icon: Utensils, label: "customer.orderStatus.steps.served" },
]

export function OrderStatusTimeline({ currentStatus, updatedAt }: OrderStatusTimelineProps) {
  const { t } = useTranslation()

  const currentStepIndex = statusSteps.findIndex((step) => step.key === currentStatus)
  const isCompleted = currentStatus === "served"

  return (
    <div className="space-y-6">
      {/* Current Status Card */}
      <div className="bg-primary/10 border border-primary/20 rounded-lg p-4 text-center">
        <div className="flex items-center justify-center gap-2 mb-2">
          {statusSteps[currentStepIndex]?.icon && (\
            <statusSteps[currentStepIndex].icon className="w-5 h-5 text-primary" />
          )}
          <h2 className="font-semibold text-primary">
            {currentStepIndex >= 0 ? t(statusSteps[currentStepIndex].label) : t("customer.orderStatus.unknown")}
          </h2>
        </div>
        <p className="text-sm text-muted-foreground">
          {currentStatus === "placed" && t("customer.orderStatus.messages.placed")}
          {currentStatus === "acknowledged" && t("customer.orderStatus.messages.acknowledged")}
          {currentStatus === "in_kitchen" && t("customer.orderStatus.messages.inKitchen")}
          {currentStatus === "ready" && t("customer.orderStatus.messages.ready")}
          {currentStatus === "served" && t("customer.orderStatus.messages.served")}
        </p>
      </div>

      {/* Timeline Steps */}
      <div className="relative">
        {/* Progress Line */}
        <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-border" />
        <div
          className="absolute left-6 top-0 w-0.5 bg-primary transition-all duration-500"
          style={{
            height: isCompleted ? "100%" : `${(currentStepIndex / (statusSteps.length - 1)) * 100}%`,
          }}
        />

        {/* Steps */}
        <div className="space-y-6">
          {statusSteps.map((step, index) => {
            const isActive = index === currentStepIndex
            const isCompleted = index < currentStepIndex || currentStatus === "served"
            const Icon = step.icon

            return (
              <div key={step.key} className="relative flex items-center gap-4">
                {/* Step Icon */}
                <div
                  className={cn(
                    "relative z-10 w-12 h-12 rounded-full border-2 flex items-center justify-center transition-colors",
                    isCompleted
                      ? "bg-primary border-primary text-primary-foreground"
                      : isActive
                        ? "bg-primary/10 border-primary text-primary"
                        : "bg-background border-border text-muted-foreground",
                  )}
                >
                  <Icon className="w-5 h-5" />
                </div>

                {/* Step Content */}
                <div className="flex-1">
                  <h3
                    className={cn(
                      "font-medium",
                      isCompleted || isActive ? "text-foreground" : "text-muted-foreground",
                    )}
                  >
                    {t(step.label)}
                  </h3>
                  {isActive && (
                    <p className="text-sm text-muted-foreground mt-1">
                      {new Date(updatedAt).toLocaleTimeString()}
                    </p>
                  )}
                </div>

                {/* Status Indicator */}
                {isCompleted && (
                  <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                )}
                {isActive && !isCompleted && (
                  <div className="w-2 h-2 bg-primary rounded-full animate-pulse flex-shrink-0" />
                )}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
