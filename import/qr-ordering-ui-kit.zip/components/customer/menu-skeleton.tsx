"use client"

import { Card } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

export function MenuSkeleton() {
  return (
    <div className="space-y-6">
      {/* Category Navigation Skeleton */}
      <div className="sticky top-[73px] bg-background/95 backdrop-blur border-b z-30">
        <div className="px-4 py-3">
          <div className="flex gap-2 overflow-x-auto">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="flex-shrink-0 h-9 w-20 rounded-full" />
            ))}
          </div>
        </div>
      </div>

      {/* Menu Items Skeleton */}
      <div className="px-4 space-y-8">
        {Array.from({ length: 3 }).map((_, categoryIndex) => (
          <div key={categoryIndex} className="space-y-4">
            <div className="space-y-2">
              <Skeleton className="h-6 w-32" />
              <Skeleton className="h-4 w-48" />
            </div>

            <div className="grid gap-4">
              {Array.from({ length: 4 }).map((_, itemIndex) => (
                <Card key={itemIndex} className="p-4">
                  <div className="flex gap-4">
                    <Skeleton className="flex-shrink-0 w-20 h-20 rounded-lg" />
                    <div className="flex-1 space-y-2">
                      <div className="flex justify-between">
                        <Skeleton className="h-5 w-32" />
                        <Skeleton className="h-5 w-16" />
                      </div>
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-3/4" />
                      <div className="flex gap-2">
                        <Skeleton className="h-5 w-12 rounded-full" />
                        <Skeleton className="h-5 w-16 rounded-full" />
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
