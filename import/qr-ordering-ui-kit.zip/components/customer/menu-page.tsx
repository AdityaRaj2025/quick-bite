"use client"

import { useState, useEffect, useRef } from "react"
import { useTranslation } from "react-i18next"
import { CustomerLayout } from "./customer-layout"
import { CategoryNav } from "./category-nav"
import { MenuItemCard } from "./menu-item-card"
import { MenuItemModal } from "./menu-item-modal"
import { MenuSkeleton } from "./menu-skeleton"
import { MenuEmpty } from "./menu-empty"
import { MenuError } from "./menu-error"
import { useMenu } from "@/hooks/use-menu"
import type { MenuItem } from "@/types/menu"

interface MenuPageProps {
  restaurantId: string
  tableCode: string
}

export function MenuPage({ restaurantId, tableCode }: MenuPageProps) {
  const { t } = useTranslation()
  const { data, loading, error } = useMenu(restaurantId)
  const [selectedCategory, setSelectedCategory] = useState<string>("")
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null)
  const categoryRefs = useRef<Record<string, HTMLElement | null>>({})

  // Set initial category when data loads
  useEffect(() => {
    if (data?.categories && data.categories.length > 0 && !selectedCategory) {
      setSelectedCategory(data.categories[0].id)
    }
  }, [data, selectedCategory])

  // Scroll to category section
  const scrollToCategory = (categoryId: string) => {
    const element = categoryRefs.current[categoryId]
    if (element) {
      const headerHeight = 120 // Account for sticky header + category nav
      const elementPosition = element.offsetTop - headerHeight
      window.scrollTo({
        top: elementPosition,
        behavior: "smooth",
      })
    }
    setSelectedCategory(categoryId)
  }

  if (loading) {
    return (
      <CustomerLayout restaurantName="Loading..." tableCode={tableCode}>
        <MenuSkeleton />
      </CustomerLayout>
    )
  }

  if (error) {
    return (
      <CustomerLayout restaurantName="Error" tableCode={tableCode}>
        <MenuError onRetry={() => window.location.reload()} />
      </CustomerLayout>
    )
  }

  if (!data || !data.categories || data.categories.length === 0) {
    return (
      <CustomerLayout restaurantName="Menu" tableCode={tableCode}>
        <MenuEmpty />
      </CustomerLayout>
    )
  }

  const { categories, items, restaurant } = data

  return (
    <CustomerLayout restaurantName={restaurant?.name || "Menu"} tableCode={tableCode}>
      {/* Category Navigation */}
      <CategoryNav categories={categories} selectedCategory={selectedCategory} onCategorySelect={scrollToCategory} />

      {/* Menu Items by Category */}
      <div className="px-4 pb-4 space-y-8">
        {categories.map((category) => {
          const categoryItems = items.filter((item) => item.categoryId === category.id)

          if (categoryItems.length === 0) return null

          return (
            <section
              key={category.id}
              ref={(el) => {
                categoryRefs.current[category.id] = el
              }}
              className="space-y-4"
            >
              <div className="sticky top-[120px] bg-background/95 backdrop-blur py-2 -mx-4 px-4 z-30">
                <h2 className="text-xl font-semibold">{category.name}</h2>
                {category.description && <p className="text-sm text-muted-foreground mt-1">{category.description}</p>}
              </div>

              <div className="grid gap-4">
                {categoryItems.map((item) => (
                  <MenuItemCard key={item.id} item={item} onSelect={() => setSelectedItem(item)} />
                ))}
              </div>
            </section>
          )
        })}
      </div>

      {/* Item Detail Modal */}
      {selectedItem && (
        <MenuItemModal
          item={selectedItem}
          onClose={() => setSelectedItem(null)}
          restaurantId={restaurantId}
          tableCode={tableCode}
        />
      )}
    </CustomerLayout>
  )
}
