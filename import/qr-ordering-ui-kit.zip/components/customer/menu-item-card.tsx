"use client"

import { useTranslation } from "react-i18next"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { MenuItem } from "@/types/menu"

interface MenuItemCardProps {
  item: MenuItem
  onSelect: () => void
}

export function MenuItemCard({ item, onSelect }: MenuItemCardProps) {
  const { t } = useTranslation()

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("ja-JP", {
      style: "currency",
      currency: "JPY",
      minimumFractionDigits: 0,
    }).format(price)
  }

  return (
    <Card className="overflow-hidden cursor-pointer hover:shadow-md transition-shadow" onClick={onSelect}>
      <div className="flex gap-4 p-4">
        {/* Item Image */}
        <div className="flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden bg-muted">
          {item.imageUrl ? (
            <img
              src={item.imageUrl || "/placeholder.svg"}
              alt={item.name}
              className="w-full h-full object-cover"
              loading="lazy"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <svg className="w-8 h-8 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                />
              </svg>
            </div>
          )}
        </div>

        {/* Item Details */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-medium text-base leading-tight">{item.name}</h3>
            <span className="flex-shrink-0 font-semibold text-primary">{formatPrice(item.basePrice)}</span>
          </div>

          {item.description && <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{item.description}</p>}

          {/* Badges */}
          {item.badges && item.badges.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {item.badges.map((badge) => (
                <Badge key={badge} variant={badge === "spicy" ? "destructive" : "secondary"} className="text-xs">
                  {t(`customer.badges.${badge}`)}
                </Badge>
              ))}
            </div>
          )}

          {/* Options indicator */}
          {item.options && item.options.length > 0 && (
            <p className="text-xs text-muted-foreground mt-2">{t("customer.menu.hasOptions")}</p>
          )}
        </div>
      </div>
    </Card>
  )
}
