"use client"

import { useTranslation } from "react-i18next"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import type { Order } from "@/types/order"

interface OrderDetailsProps {
  order: Order
}

export function OrderDetails({ order }: OrderDetailsProps) {
  const { t } = useTranslation()

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("ja-JP", {
      style: "currency",
      currency: "JPY",
      minimumFractionDigits: 0,
    }).format(price)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">{t("customer.orderStatus.orderDetails")}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Order Items */}
        <div className="space-y-3">
          {order.items.map((item, index) => (
            <div key={index} className="flex justify-between items-start gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-medium">{item.nameSnapshot}</span>
                  <span className="text-sm text-muted-foreground">×{item.quantity}</span>
                </div>

                {/* Item Options */}
                {item.options && item.options.length > 0 && (
                  <div className="mt-1 space-y-1">
                    {item.options.map((option, optionIndex) => (
                      <p key={optionIndex} className="text-xs text-muted-foreground">
                        {option.nameSnapshot}
                        {option.priceDeltaJpy !== 0 && (
                          <span className="ml-1">
                            ({option.priceDeltaJpy > 0 ? "+" : ""}
                            {formatPrice(option.priceDeltaJpy)})
                          </span>
                        )}
                      </p>
                    ))}
                  </div>
                )}
              </div>

              <span className="font-medium text-sm">{formatPrice(item.lineTotalJpy)}</span>
            </div>
          ))}
        </div>

        <Separator />

        {/* Order Summary */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>{t("customer.cart.subtotal")}</span>
            <span>{formatPrice(order.subtotalJpy)}</span>
          </div>

          <div className="flex justify-between text-sm">
            <span>{t("customer.cart.tax")}</span>
            <span>{formatPrice(order.taxJpy)}</span>
          </div>

          {order.serviceChargeJpy > 0 && (
            <div className="flex justify-between text-sm">
              <span>{t("customer.cart.serviceCharge")}</span>
              <span>{formatPrice(order.serviceChargeJpy)}</span>
            </div>
          )}

          <Separator />

          <div className="flex justify-between font-semibold">
            <span>{t("customer.cart.total")}</span>
            <span className="text-primary">{formatPrice(order.totalJpy)}</span>
          </div>
        </div>

        {/* Notes */}
        {order.notes && (
          <>
            <Separator />
            <div>
              <h4 className="font-medium text-sm mb-2">{t("customer.cart.notes.label")}</h4>
              <p className="text-sm text-muted-foreground bg-muted p-3 rounded-md">{order.notes}</p>
            </div>
          </>
        )}

        {/* Order Info */}
        <Separator />
        <div className="text-xs text-muted-foreground space-y-1">
          <p>
            {t("customer.orderStatus.placedAt")}: {new Date(order.createdAt).toLocaleString()}
          </p>
          <p>
            {t("customer.orderStatus.locale")}: {order.locale.toUpperCase()}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
