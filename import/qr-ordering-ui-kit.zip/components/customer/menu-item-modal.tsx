"use client"

import { useState, useEffect } from "react"
import { useTranslation } from "react-i18next"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { useCart } from "@/hooks/use-cart"
import type { MenuItem } from "@/types/menu"

interface MenuItemModalProps {
  item: MenuItem
  onClose: () => void
  restaurantId: string
  tableCode: string
}

export function MenuItemModal({ item, onClose, restaurantId, tableCode }: MenuItemModalProps) {
  const { t } = useTranslation()
  const { addItem } = useCart()
  const [quantity, setQuantity] = useState(1)
  const [selectedOptions, setSelectedOptions] = useState<Record<string, string[]>>({})
  const [currentPrice, setCurrentPrice] = useState(item.basePrice)

  // Initialize selected options
  useEffect(() => {
    const initialOptions: Record<string, string[]> = {}
    item.options?.forEach((option) => {
      if (option.required && option.choices.length > 0) {
        initialOptions[option.id] = [option.choices[0].id]
      }
    })
    setSelectedOptions(initialOptions)
  }, [item])

  // Calculate current price based on selected options
  useEffect(() => {
    let price = item.basePrice
    Object.entries(selectedOptions).forEach(([optionId, choiceIds]) => {
      const option = item.options?.find((opt) => opt.id === optionId)
      if (option) {
        choiceIds.forEach((choiceId) => {
          const choice = option.choices.find((c) => c.id === choiceId)
          if (choice) {
            price += choice.priceDelta || 0
          }
        })
      }
    })
    setCurrentPrice(price)
  }, [selectedOptions, item])

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("ja-JP", {
      style: "currency",
      currency: "JPY",
      minimumFractionDigits: 0,
    }).format(price)
  }

  const handleOptionChange = (optionId: string, choiceId: string, isMultiple: boolean) => {
    setSelectedOptions((prev) => {
      if (isMultiple) {
        const current = prev[optionId] || []
        const updated = current.includes(choiceId) ? current.filter((id) => id !== choiceId) : [...current, choiceId]
        return { ...prev, [optionId]: updated }
      } else {
        return { ...prev, [optionId]: [choiceId] }
      }
    })
  }

  const canAddToCart = () => {
    return (
      item.options?.every((option) => {
        if (!option.required) return true
        const selected = selectedOptions[option.id] || []
        return selected.length >= (option.minChoices || 1)
      }) ?? true
    )
  }

  const handleAddToCart = () => {
    if (!canAddToCart()) return

    const selectedOptionsForCart = Object.entries(selectedOptions).flatMap(([optionId, choiceIds]) => {
      const option = item.options?.find((opt) => opt.id === optionId)
      if (!option) return []

      return choiceIds.map((choiceId) => {
        const choice = option.choices.find((c) => c.id === choiceId)
        return {
          optionId,
          optionName: option.name,
          choiceId,
          choiceName: choice?.name || "",
          priceDelta: choice?.priceDelta || 0,
        }
      })
    })

    addItem({
      itemId: item.id,
      name: item.name,
      basePrice: item.basePrice,
      quantity,
      options: selectedOptionsForCart,
      totalPrice: currentPrice * quantity,
    })

    onClose()
  }

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{item.name}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Item Image */}
          {item.imageUrl && (
            <div className="w-full h-48 rounded-lg overflow-hidden bg-muted">
              <img src={item.imageUrl || "/placeholder.svg"} alt={item.name} className="w-full h-full object-cover" />
            </div>
          )}

          {/* Description */}
          {item.description && <p className="text-muted-foreground">{item.description}</p>}

          {/* Badges */}
          {item.badges && item.badges.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {item.badges.map((badge) => (
                <Badge key={badge} variant={badge === "spicy" ? "destructive" : "secondary"}>
                  {t(`customer.badges.${badge}`)}
                </Badge>
              ))}
            </div>
          )}

          {/* Options */}
          {item.options && item.options.length > 0 && (
            <div className="space-y-4">
              {item.options.map((option) => (
                <div key={option.id} className="space-y-3">
                  <div>
                    <h4 className="font-medium">
                      {option.name}
                      {option.required && <span className="text-destructive ml-1">*</span>}
                    </h4>
                    {option.description && <p className="text-sm text-muted-foreground">{option.description}</p>}
                  </div>

                  {option.maxChoices === 1 ? (
                    <RadioGroup
                      value={selectedOptions[option.id]?.[0] || ""}
                      onValueChange={(value) => handleOptionChange(option.id, value, false)}
                    >
                      {option.choices.map((choice) => (
                        <div key={choice.id} className="flex items-center space-x-2">
                          <RadioGroupItem value={choice.id} id={choice.id} />
                          <Label htmlFor={choice.id} className="flex-1 cursor-pointer">
                            <div className="flex justify-between items-center">
                              <span>{choice.name}</span>
                              {choice.priceDelta !== 0 && (
                                <span className="text-sm text-muted-foreground">
                                  {choice.priceDelta > 0 ? "+" : ""}
                                  {formatPrice(choice.priceDelta)}
                                </span>
                              )}
                            </div>
                          </Label>
                        </div>
                      ))}
                    </RadioGroup>
                  ) : (
                    <div className="space-y-2">
                      {option.choices.map((choice) => (
                        <div key={choice.id} className="flex items-center space-x-2">
                          <Checkbox
                            id={choice.id}
                            checked={selectedOptions[option.id]?.includes(choice.id) || false}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                handleOptionChange(option.id, choice.id, true)
                              } else {
                                handleOptionChange(option.id, choice.id, true)
                              }
                            }}
                          />
                          <Label htmlFor={choice.id} className="flex-1 cursor-pointer">
                            <div className="flex justify-between items-center">
                              <span>{choice.name}</span>
                              {choice.priceDelta !== 0 && (
                                <span className="text-sm text-muted-foreground">
                                  {choice.priceDelta > 0 ? "+" : ""}
                                  {formatPrice(choice.priceDelta)}
                                </span>
                              )}
                            </div>
                          </Label>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Quantity and Add to Cart */}
          <div className="flex items-center justify-between pt-4 border-t">
            <div className="flex items-center gap-3">
              <span className="text-sm font-medium">{t("customer.quantity")}</span>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  disabled={quantity <= 1}
                >
                  -
                </Button>
                <span className="w-8 text-center font-medium">{quantity}</span>
                <Button variant="outline" size="sm" onClick={() => setQuantity(quantity + 1)}>
                  +
                </Button>
              </div>
            </div>

            <Button onClick={handleAddToCart} disabled={!canAddToCart()} className="min-w-[120px]">
              {t("customer.addToCart")} {formatPrice(currentPrice * quantity)}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
