"use client"

import { useState } from "react"
import { useTranslation } from "react-i18next"
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { useCart } from "@/hooks/use-cart"
import { CartLineItem } from "./cart-line-item"
import { CartSummary } from "./cart-summary"
import { CartEmpty } from "./cart-empty"
import { OrderConfirmationModal } from "./order-confirmation-modal"

export function CartDrawer() {
  const { t } = useTranslation()
  const { items, isOpen, setIsOpen, clearCart } = useCart()
  const [notes, setNotes] = useState("")
  const [isPlacingOrder, setIsPlacingOrder] = useState(false)
  const [orderConfirmation, setOrderConfirmation] = useState<{ orderId: string } | null>(null)

  const handlePlaceOrder = async () => {
    if (items.length === 0) return

    setIsPlacingOrder(true)
    try {
      // Mock API call - replace with actual implementation
      await new Promise((resolve) => setTimeout(resolve, 2000))

      const orderId = `ORD-${Date.now()}`
      setOrderConfirmation({ orderId })
      clearCart()
      setNotes("")
    } catch (error) {
      console.error("Failed to place order:", error)
    } finally {
      setIsPlacingOrder(false)
    }
  }

  const handleOrderConfirmationClose = () => {
    setOrderConfirmation(null)
    setIsOpen(false)
  }

  return (
    <>
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetContent side="right" className="w-full sm:max-w-lg flex flex-col">
          <SheetHeader>
            <SheetTitle>{t("customer.cart.title")}</SheetTitle>
          </SheetHeader>

          {items.length === 0 ? (
            <CartEmpty />
          ) : (
            <div className="flex flex-col flex-1">
              {/* Cart Items */}
              <div className="flex-1 overflow-y-auto py-4 space-y-4">
                {items.map((item) => (
                  <CartLineItem key={`${item.itemId}-${JSON.stringify(item.options)}`} item={item} />
                ))}
              </div>

              {/* Notes Section */}
              <div className="border-t pt-4 space-y-3">
                <Label htmlFor="notes">{t("customer.cart.notes.label")}</Label>
                <Textarea
                  id="notes"
                  placeholder={t("customer.cart.notes.placeholder")}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={3}
                  className="resize-none"
                />
              </div>

              {/* Cart Summary */}
              <CartSummary items={items} />

              {/* Place Order Button */}
              <div className="pt-4">
                <Button
                  onClick={handlePlaceOrder}
                  disabled={items.length === 0 || isPlacingOrder}
                  className="w-full h-12 text-base font-medium"
                  size="lg"
                >
                  {isPlacingOrder ? t("customer.cart.placing") : t("customer.cart.placeOrder")}
                </Button>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>

      {/* Order Confirmation Modal */}
      {orderConfirmation && (
        <OrderConfirmationModal orderId={orderConfirmation.orderId} onClose={handleOrderConfirmationClose} />
      )}
    </>
  )
}
