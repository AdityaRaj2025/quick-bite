"use client"

import { useTranslation } from "react-i18next"

export function CartEmpty() {
  const { t } = useTranslation()

  return (
    <div className="flex flex-col items-center justify-center flex-1 text-center px-4">
      <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mb-4">
        <svg className="w-10 h-10 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-1.1 5H19M7 13v8a2 2 0 002 2h6a2 2 0 002-2v-8m-8 0V9a2 2 0 012-2h4a2 2 0 012 2v4.01"
          />
        </svg>
      </div>
      <h3 className="font-medium text-lg mb-2">{t("customer.cart.empty.title")}</h3>
      <p className="text-muted-foreground text-sm">{t("customer.cart.empty.description")}</p>
    </div>
  )
}
