"use client"

import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertTriangle } from "lucide-react"

interface OrderStatusErrorProps {
  onRetry: () => void
}

export function OrderStatusError({ onRetry }: OrderStatusErrorProps) {
  const { t } = useTranslation()

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] px-4 space-y-6">
      <div className="w-20 h-20 rounded-full bg-destructive/10 flex items-center justify-center">
        <AlertTriangle className="w-10 h-10 text-destructive" />
      </div>

      <Alert className="max-w-md">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription className="text-center">{t("customer.orderStatus.error.description")}</AlertDescription>
      </Alert>

      <Button onClick={onRetry}>{t("customer.orderStatus.error.retry")}</Button>
    </div>
  )
}
