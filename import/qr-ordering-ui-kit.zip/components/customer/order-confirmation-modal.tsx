"use client"

import { useTranslation } from "react-i18next"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { CheckCircle } from "lucide-react"

interface OrderConfirmationModalProps {
  orderId: string
  onClose: () => void
}

export function OrderConfirmationModal({ orderId, onClose }: OrderConfirmationModalProps) {
  const { t } = useTranslation()

  const handleViewOrder = () => {
    window.location.href = `/order/${orderId}`
  }

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-center">{t("customer.orderConfirmation.title")}</DialogTitle>
        </DialogHeader>

        <div className="flex flex-col items-center text-center space-y-4 py-4">
          <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/20 flex items-center justify-center">
            <CheckCircle className="w-8 h-8 text-green-600 dark:text-green-400" />
          </div>

          <div className="space-y-2">
            <p className="text-muted-foreground">{t("customer.orderConfirmation.description")}</p>
            <p className="font-mono text-sm bg-muted px-3 py-1 rounded">
              {t("customer.orderConfirmation.orderId")}: {orderId}
            </p>
          </div>

          <div className="flex flex-col gap-2 w-full">
            <Button onClick={handleViewOrder} className="w-full">
              {t("customer.orderConfirmation.viewOrder")}
            </Button>
            <Button variant="outline" onClick={onClose} className="w-full bg-transparent">
              {t("customer.orderConfirmation.continueBrowsing")}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
