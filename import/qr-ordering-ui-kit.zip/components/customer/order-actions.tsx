"use client"

import { useState } from "react"
import { useTranslation } from "react-i18next"
import { Button } from "@/components/ui/button"
import { Phone, Plus, MessageCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface OrderActionsProps {
  orderId: string
  restaurantId: string
  tableCode: string
  status: string
}

export function OrderActions({ orderId, restaurantId, tableCode, status }: OrderActionsProps) {
  const { t } = useTranslation()
  const [isCallingStaff, setIsCallingStaff] = useState(false)
  const [staffCalled, setStaffCalled] = useState(false)

  const handleCallStaff = async () => {
    setIsCallingStaff(true)
    try {
      // Mock API call - replace with actual implementation
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setStaffCalled(true)
      setTimeout(() => setStaffCalled(false), 5000) // Reset after 5 seconds
    } catch (error) {
      console.error("Failed to call staff:", error)
    } finally {
      setIsCallingStaff(false)
    }
  }

  const handleAddMoreItems = () => {
    window.location.href = `/t/${restaurantId}/${tableCode}`
  }

  return (
    <div className="space-y-4">
      {/* Staff Called Alert */}
      {staffCalled && (
        <Alert className="border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950">
          <MessageCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
          <AlertDescription className="text-green-800 dark:text-green-200">
            {t("customer.orderStatus.staffCalled")}
          </AlertDescription>
        </Alert>
      )}

      {/* Action Buttons */}
      <div className="grid gap-3">
        {/* Call Staff Button */}
        <Button
          onClick={handleCallStaff}
          disabled={isCallingStaff || staffCalled}
          variant="outline"
          className="w-full h-12 text-base bg-transparent"
        >
          <Phone className="w-5 h-5 mr-2" />
          {isCallingStaff
            ? t("customer.orderStatus.callingStaff")
            : staffCalled
              ? t("customer.orderStatus.staffNotified")
              : t("customer.orderStatus.callStaff")}
        </Button>

        {/* Add More Items Button */}
        {status !== "served" && (
          <Button onClick={handleAddMoreItems} className="w-full h-12 text-base">
            <Plus className="w-5 h-5 mr-2" />
            {t("customer.orderStatus.addMoreItems")}
          </Button>
        )}
      </div>

      {/* Help Text */}
      <div className="text-center text-sm text-muted-foreground space-y-1">
        <p>{t("customer.orderStatus.helpText")}</p>
        {status === "ready" && <p className="text-primary font-medium">{t("customer.orderStatus.readyMessage")}</p>}
      </div>
    </div>
  )
}
