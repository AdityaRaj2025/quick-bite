"use client"

import { useTranslation } from "react-i18next"
import { Separator } from "@/components/ui/separator"
import type { CartItem } from "@/types/cart"

interface CartSummaryProps {
  items: CartItem[]
}

export function CartSummary({ items }: CartSummaryProps) {
  const { t } = useTranslation()

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("ja-JP", {
      style: "currency",
      currency: "JPY",
      minimumFractionDigits: 0,
    }).format(price)
  }

  const subtotal = items.reduce((sum, item) => sum + item.totalPrice, 0)
  const taxRate = 0.1 // 10% tax
  const serviceChargeRate = 0.0 // 0% service charge (configurable)

  const tax = Math.round(subtotal * taxRate)
  const serviceCharge = Math.round(subtotal * serviceChargeRate)
  const total = subtotal + tax + serviceCharge

  return (
    <div className="border-t pt-4 space-y-2">
      <div className="flex justify-between text-sm">
        <span>{t("customer.cart.subtotal")}</span>
        <span>{formatPrice(subtotal)}</span>
      </div>

      <div className="flex justify-between text-sm">
        <span>
          {t("customer.cart.tax")} ({Math.round(taxRate * 100)}%)
        </span>
        <span>{formatPrice(tax)}</span>
      </div>

      {serviceCharge > 0 && (
        <div className="flex justify-between text-sm">
          <span>
            {t("customer.cart.serviceCharge")} ({Math.round(serviceChargeRate * 100)}%)
          </span>
          <span>{formatPrice(serviceCharge)}</span>
        </div>
      )}

      <Separator />

      <div className="flex justify-between font-semibold text-base">
        <span>{t("customer.cart.total")}</span>
        <span className="text-primary">{formatPrice(total)}</span>
      </div>
    </div>
  )
}
