"use client"

import { useTranslation } from "react-i18next"
import { CustomerLayout } from "./customer-layout"
import { OrderStatusTimeline } from "./order-status-timeline"
import { OrderDetails } from "./order-details"
import { OrderActions } from "./order-actions"
import { OrderStatusSkeleton } from "./order-status-skeleton"
import { OrderStatusError } from "./order-status-error"
import { useOrderStatus } from "@/hooks/use-order-status"

interface OrderStatusPageProps {
  orderId: string
}

export function OrderStatusPage({ orderId }: OrderStatusPageProps) {
  const { t } = useTranslation()
  const { data: order, loading, error, refetch } = useOrderStatus(orderId)

  if (loading) {
    return (
      <CustomerLayout restaurantName="Order Status">
        <OrderStatusSkeleton />
      </CustomerLayout>
    )
  }

  if (error || !order) {
    return (
      <CustomerLayout restaurantName="Order Status">
        <OrderStatusError onRetry={refetch} />
      </CustomerLayout>
    )
  }

  return (
    <CustomerLayout restaurantName={order.restaurant?.name || "Order Status"}>
      <div className="px-4 py-6 space-y-8 max-w-2xl mx-auto">
        {/* Order Header */}
        <div className="text-center space-y-2">
          <h1 className="text-2xl font-bold">{t("customer.orderStatus.title")}</h1>
          <p className="text-muted-foreground">
            {t("customer.orderStatus.orderId")}: <span className="font-mono">{orderId}</span>
          </p>
          <p className="text-sm text-muted-foreground">
            {t("customer.orderStatus.table")} {order.tableCode}
          </p>
        </div>

        {/* Status Timeline */}
        <OrderStatusTimeline currentStatus={order.status} updatedAt={order.updatedAt} />

        {/* Order Details */}
        <OrderDetails order={order} />

        {/* Action Buttons */}
        <OrderActions
          orderId={orderId}
          restaurantId={order.restaurantId}
          tableCode={order.tableCode}
          status={order.status}
        />

        {/* Last Updated */}
        <div className="text-center text-xs text-muted-foreground">
          {t("customer.orderStatus.lastUpdated")}: {new Date(order.updatedAt).toLocaleTimeString()}
        </div>
      </div>
    </CustomerLayout>
  )
}
