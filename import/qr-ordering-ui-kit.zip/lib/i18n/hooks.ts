"use client"

import { useTranslation as useI18nTranslation } from "react-i18next"

export function useTranslation(namespace?: string) {
  return useI18nTranslation(namespace)
}

export function useLanguage() {
  const { i18n } = useI18nTranslation()

  const changeLanguage = (language: string) => {
    i18n.changeLanguage(language)
  }

  const currentLanguage = i18n.language

  const supportedLanguages = [
    { code: "en", name: "English", nativeName: "English" },
    { code: "ja", name: "Japanese", nativeName: "日本語" },
    { code: "ne", name: "Nepali", nativeName: "नेपाली" },
    { code: "hi", name: "Hindi", nativeName: "हिन्दी" },
  ]

  return {
    currentLanguage,
    changeLanguage,
    supportedLanguages,
    isRTL: false, // None of our supported languages are RTL
  }
}
