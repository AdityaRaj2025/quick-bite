"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface SkipLinkProps {
  href: string
  children: React.ReactNode
  className?: string
}

export function SkipLink({ href, children, className }: SkipLinkProps) {
  return (
    <Button
      asChild
      variant="outline"
      className={cn(
        "absolute left-4 top-4 z-50 -translate-y-16 transform transition-transform focus:translate-y-0",
        className,
      )}
    >
      <a href={href}>{children}</a>
    </Button>
  )
}
