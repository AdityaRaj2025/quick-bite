"use client"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Icons, type IconName } from "../icons"
import { cn } from "@/lib/utils"

interface NavItem {
  id: string
  label: string
  icon: IconName
  href?: string
  badge?: string | number
  onClick?: () => void
}

interface MobileBottomNavProps {
  items: NavItem[]
  activeItem?: string
  onItemClick?: (item: NavItem) => void
  className?: string
}

export function MobileBottomNav({ items, activeItem, onItemClick, className }: MobileBottomNavProps) {
  return (
    <nav
      className={cn(
        "fixed bottom-0 left-0 right-0 z-50 border-t border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 mobile-bottom-nav",
        className,
      )}
      role="navigation"
      aria-label="Mobile navigation"
    >
      <div className="flex items-center justify-around px-2 py-2">
        {items.map((item) => {
          const IconComponent = Icons[item.icon]
          const isActive = activeItem === item.id

          return (
            <Button
              key={item.id}
              variant="ghost"
              size="sm"
              className={cn(
                "relative flex h-12 min-w-0 flex-1 flex-col items-center justify-center gap-1 px-1 py-1 text-xs",
                isActive ? "text-primary" : "text-muted-foreground hover:text-foreground",
              )}
              onClick={() => onItemClick?.(item)}
              aria-label={item.label}
              aria-current={isActive ? "page" : undefined}
            >
              <div className="relative">
                <IconComponent className="h-5 w-5" />
                {item.badge && (
                  <Badge variant="destructive" className="absolute -right-2 -top-2 h-4 min-w-4 px-1 text-xs">
                    {item.badge}
                  </Badge>
                )}
              </div>
              <span className="truncate leading-none">{item.label}</span>
            </Button>
          )
        })}
      </div>
    </nav>
  )
}
