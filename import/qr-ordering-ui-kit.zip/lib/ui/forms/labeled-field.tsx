import React from "react"
import type { ReactElement } from "react"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"

interface LabeledFieldProps {
  children: ReactElement
  label: string
  htmlFor?: string
  required?: boolean
  error?: string
  helpText?: string
  className?: string
  labelClassName?: string
  orientation?: "vertical" | "horizontal"
}

export function LabeledField({
  children,
  label,
  htmlFor,
  required = false,
  error,
  helpText,
  className,
  labelClassName,
  orientation = "vertical",
}: LabeledFieldProps) {
  const fieldId = htmlFor || children.props?.id || `field-${Math.random().toString(36).substr(2, 9)}`

  // Clone the child element to add the id and aria attributes
  const childWithProps = React.cloneElement(children, {
    id: fieldId,
    "aria-describedby":
      [error ? `${fieldId}-error` : undefined, helpText ? `${fieldId}-help` : undefined].filter(Boolean).join(" ") ||
      undefined,
    "aria-invalid": error ? "true" : undefined,
    className: cn(children.props?.className, error && "border-destructive focus-visible:ring-destructive"),
  })

  if (orientation === "horizontal") {
    return (
      <div className={cn("grid grid-cols-1 gap-4 sm:grid-cols-3 sm:items-start", className)}>
        <Label
          htmlFor={fieldId}
          className={cn(
            "text-sm font-medium leading-6 text-foreground sm:pt-2",
            required && "after:ml-1 after:text-destructive after:content-['*']",
            labelClassName,
          )}
        >
          {label}
        </Label>
        <div className="sm:col-span-2">
          {childWithProps}
          {helpText && (
            <p id={`${fieldId}-help`} className="mt-2 text-sm text-muted-foreground">
              {helpText}
            </p>
          )}
          {error && (
            <p id={`${fieldId}-error`} className="mt-2 text-sm text-destructive" role="alert">
              {error}
            </p>
          )}
        </div>
      </div>
    )
  }

  return (
    <div className={cn("space-y-2", className)}>
      <Label
        htmlFor={fieldId}
        className={cn(
          "text-sm font-medium leading-none text-foreground",
          required && "after:ml-1 after:text-destructive after:content-['*']",
          labelClassName,
        )}
      >
        {label}
      </Label>
      {childWithProps}
      {helpText && (
        <p id={`${fieldId}-help`} className="text-sm text-muted-foreground">
          {helpText}
        </p>
      )}
      {error && (
        <p id={`${fieldId}-error`} className="text-sm text-destructive" role="alert">
          {error}
        </p>
      )}
    </div>
  )
}
