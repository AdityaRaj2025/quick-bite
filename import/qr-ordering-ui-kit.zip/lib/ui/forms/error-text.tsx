import type React from "react"
import { cn } from "@/lib/utils"

interface ErrorTextProps {
  children: React.ReactNode
  className?: string
  id?: string
}

export function ErrorText({ children, className, id }: ErrorTextProps) {
  if (!children) return null

  return (
    <p id={id} className={cn("text-sm text-destructive", className)} role="alert" aria-live="polite">
      {children}
    </p>
  )
}
