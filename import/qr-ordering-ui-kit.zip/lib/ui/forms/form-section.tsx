import type React from "react"
import { cn } from "@/lib/utils"

interface FormSectionProps {
  children: React.ReactNode
  title?: string
  description?: string
  className?: string
  variant?: "default" | "card"
}

export function FormSection({ children, title, description, className, variant = "default" }: FormSectionProps) {
  const content = (
    <>
      {(title || description) && (
        <div className="space-y-1 pb-4">
          {title && <h3 className="text-lg font-medium leading-6 text-foreground">{title}</h3>}
          {description && <p className="text-sm text-muted-foreground">{description}</p>}
        </div>
      )}
      <div className="space-y-6">{children}</div>
    </>
  )

  if (variant === "card") {
    return (
      <div className={cn("rounded-lg border border-border bg-card p-6 text-card-foreground shadow-sm", className)}>
        {content}
      </div>
    )
  }

  return <div className={cn("space-y-6", className)}>{content}</div>
}
