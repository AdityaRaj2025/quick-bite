import type React from "react"
import { cn } from "@/lib/utils"

interface FormActionsProps {
  children: React.ReactNode
  className?: string
  align?: "left" | "center" | "right" | "between"
  sticky?: boolean
}

export function FormActions({ children, className, align = "right", sticky = false }: FormActionsProps) {
  const alignClasses = {
    left: "justify-start",
    center: "justify-center",
    right: "justify-end",
    between: "justify-between",
  }

  return (
    <div
      className={cn(
        "flex flex-col gap-3 border-t border-border pt-6 sm:flex-row sm:gap-4",
        alignClasses[align],
        sticky &&
          "sticky bottom-0 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 mobile-safe-area",
        className,
      )}
    >
      {children}
    </div>
  )
}
