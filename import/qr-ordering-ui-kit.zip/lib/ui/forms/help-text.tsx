import type React from "react"
import { cn } from "@/lib/utils"

interface HelpTextProps {
  children: React.ReactNode
  className?: string
  id?: string
}

export function HelpText({ children, className, id }: HelpTextProps) {
  if (!children) return null

  return (
    <p id={id} className={cn("text-sm text-muted-foreground", className)}>
      {children}
    </p>
  )
}
