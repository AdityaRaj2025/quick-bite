"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Badge } from "@/components/ui/badge"
import { Icons, type IconName } from "../icons"
import { cn } from "@/lib/utils"

interface SidebarItem {
  id: string
  label: string
  icon: IconName
  href?: string
  badge?: string | number
  children?: SidebarItem[]
}

interface AppSidebarProps {
  items: SidebarItem[]
  activeItem?: string
  onItemClick?: (item: SidebarItem) => void
  className?: string
  collapsible?: boolean
  defaultCollapsed?: boolean
  trigger?: React.ReactNode
}

export function AppSidebar({
  items,
  activeItem,
  onItemClick,
  className,
  collapsible = true,
  defaultCollapsed = false,
  trigger,
}: AppSidebarProps) {
  const [collapsed, setCollapsed] = useState(defaultCollapsed)
  const [mobileOpen, setMobileOpen] = useState(false)

  const SidebarContent = () => (
    <div className="flex h-full flex-col">
      <div className="flex-1 overflow-auto py-4">
        <nav className="space-y-1 px-2">
          {items.map((item) => (
            <SidebarMenuItem
              key={item.id}
              item={item}
              isActive={activeItem === item.id}
              onClick={onItemClick}
              collapsed={collapsed}
            />
          ))}
        </nav>
      </div>

      {collapsible && (
        <div className="border-t border-sidebar-border p-2">
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            onClick={() => setCollapsed(!collapsed)}
          >
            <Icons.menu className="h-4 w-4" />
            {!collapsed && <span className="ml-2">Collapse</span>}
          </Button>
        </div>
      )}
    </div>
  )

  return (
    <>
      {/* Desktop Sidebar */}
      <aside
        className={cn(
          "hidden border-r border-sidebar-border bg-sidebar text-sidebar-foreground transition-all duration-300 md:flex md:flex-col",
          collapsed ? "w-16" : "w-64",
          className,
        )}
      >
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        {trigger && <SheetTrigger asChild>{trigger}</SheetTrigger>}
        <SheetContent side="left" className="w-64 bg-sidebar p-0 text-sidebar-foreground">
          <SidebarContent />
        </SheetContent>
      </Sheet>
    </>
  )
}

function SidebarMenuItem({
  item,
  isActive,
  onClick,
  collapsed,
}: {
  item: SidebarItem
  isActive: boolean
  onClick?: (item: SidebarItem) => void
  collapsed: boolean
}) {
  const IconComponent = Icons[item.icon]

  return (
    <Button
      variant="ghost"
      className={cn(
        "w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
        isActive &&
          "bg-sidebar-primary text-sidebar-primary-foreground hover:bg-sidebar-primary hover:text-sidebar-primary-foreground",
        collapsed && "px-2",
      )}
      onClick={() => onClick?.(item)}
    >
      <IconComponent className="h-4 w-4 shrink-0" />
      {!collapsed && (
        <>
          <span className="ml-3 truncate">{item.label}</span>
          {item.badge && (
            <Badge variant="secondary" className="ml-auto h-5 px-1.5 text-xs">
              {item.badge}
            </Badge>
          )}
        </>
      )}
    </Button>
  )
}
