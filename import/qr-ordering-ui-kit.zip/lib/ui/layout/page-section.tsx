import type React from "react"
import { cn } from "@/lib/utils"

interface PageSectionProps {
  children: React.ReactNode
  title?: string
  description?: string
  className?: string
  headerActions?: React.ReactNode
  variant?: "default" | "card"
}

export function PageSection({
  children,
  title,
  description,
  className,
  headerActions,
  variant = "default",
}: PageSectionProps) {
  const content = (
    <>
      {(title || description || headerActions) && (
        <div className="mb-6 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div className="space-y-1">
            {title && <h2 className="text-lg font-semibold text-foreground">{title}</h2>}
            {description && <p className="text-sm text-muted-foreground">{description}</p>}
          </div>
          {headerActions && <div className="flex items-center gap-2">{headerActions}</div>}
        </div>
      )}
      {children}
    </>
  )

  if (variant === "card") {
    return (
      <section className={cn("rounded-lg border border-border bg-card p-6 text-card-foreground shadow-sm", className)}>
        {content}
      </section>
    )
  }

  return <section className={cn("space-y-6", className)}>{content}</section>
}
