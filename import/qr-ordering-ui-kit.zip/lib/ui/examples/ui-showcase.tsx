"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Layout Components
import { AppHeader, AppSidebar, AppContainer, PageHeader, PageSection } from "../layout"

// Form Components
import { LabeledField, FormRow, FormSection, FormActions } from "../forms"

// Table Components
import { DataTable, TableEmpty, TableError, TableSkeleton } from "../tables"

// Navigation
import { MobileBottomNav } from "../navigation/mobile-bottom-nav"

// Accessibility
import { SkipLink, ScreenReaderOnly } from "../accessibility"

// i18n
import { LanguageSwitcher, useTranslation } from "../../i18n"

// Icons
import { Icons } from "../icons"

export function UIShowcase() {
  const { t } = useTranslation()
  const [activeTab, setActiveTab] = useState("layout")
  const [sidebarItems] = useState([
    { id: "dashboard", label: t("navigation.dashboard"), icon: "dashboard" as const },
    { id: "orders", label: t("navigation.orders"), icon: "orders" as const, badge: "3" },
    { id: "menu", label: t("navigation.menu_items"), icon: "menu" as const },
    { id: "customers", label: t("navigation.customers"), icon: "customers" as const },
    { id: "analytics", label: t("navigation.analytics"), icon: "analytics" as const },
    { id: "settings", label: t("navigation.settings"), icon: "settings" as const },
  ])

  const [mobileNavItems] = useState([
    { id: "home", label: t("navigation.home"), icon: "home" as const },
    { id: "menu", label: t("navigation.menu"), icon: "menu" as const },
    { id: "cart", label: t("qr_ordering.cart"), icon: "cart" as const, badge: "2" },
    { id: "orders", label: t("navigation.orders"), icon: "orders" as const },
    { id: "profile", label: t("navigation.profile"), icon: "roles" as const },
  ])

  const sampleData = [
    { id: 1, name: "Margherita Pizza", price: "$12.99", category: "Pizza", status: "Available" },
    { id: 2, name: "Caesar Salad", price: "$8.99", category: "Salads", status: "Available" },
    { id: 3, name: "Pasta Carbonara", price: "$14.99", category: "Pasta", status: "Out of Stock" },
  ]

  const tableColumns = [
    { key: "name", title: "Name" },
    { key: "price", title: "Price" },
    { key: "category", title: "Category" },
    {
      key: "status",
      title: "Status",
      render: (value: string) => <Badge variant={value === "Available" ? "default" : "destructive"}>{value}</Badge>,
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <SkipLink href="#main-content">Skip to main content</SkipLink>

      <AppHeader
        title="QR Ordering UI Kit"
        user={{
          name: "John Doe",
          email: "john@example.com",
        }}
        onMenuClick={() => console.log("Menu clicked")}
        onLogout={() => console.log("Logout clicked")}
      />

      <div className="flex">
        <AppSidebar
          items={sidebarItems}
          activeItem="dashboard"
          onItemClick={(item) => console.log("Sidebar item clicked:", item)}
        />

        <main id="main-content" className="flex-1">
          <AppContainer>
            <PageHeader
              title="UI Component Showcase"
              description="Explore all the components in the QR Ordering UI Kit"
              breadcrumbs={[{ label: "Home", href: "/" }, { label: "Showcase" }]}
              actions={<LanguageSwitcher />}
            />

            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="layout">Layout</TabsTrigger>
                <TabsTrigger value="forms">Forms</TabsTrigger>
                <TabsTrigger value="tables">Tables</TabsTrigger>
                <TabsTrigger value="navigation">Navigation</TabsTrigger>
                <TabsTrigger value="accessibility">A11y</TabsTrigger>
              </TabsList>

              <TabsContent value="layout" className="space-y-6">
                <PageSection title="Layout Components" description="Core layout building blocks">
                  <div className="grid gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>Page Sections</CardTitle>
                        <CardDescription>Organize content with consistent spacing</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <PageSection title="Sample Section" description="This is a sample section" variant="card">
                          <p>Content goes here...</p>
                        </PageSection>
                      </CardContent>
                    </Card>
                  </div>
                </PageSection>
              </TabsContent>

              <TabsContent value="forms" className="space-y-6">
                <PageSection title="Form Components" description="Accessible form building blocks">
                  <FormSection title="User Information" description="Basic user details">
                    <FormRow columns={2}>
                      <LabeledField label="First Name" required>
                        <Input placeholder="Enter first name" />
                      </LabeledField>
                      <LabeledField label="Last Name" required>
                        <Input placeholder="Enter last name" />
                      </LabeledField>
                    </FormRow>

                    <LabeledField label="Email" required helpText="We'll never share your email with anyone else">
                      <Input type="email" placeholder="Enter email address" />
                    </LabeledField>

                    <LabeledField label="Role">
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a role" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="admin">Administrator</SelectItem>
                          <SelectItem value="manager">Manager</SelectItem>
                          <SelectItem value="staff">Staff</SelectItem>
                        </SelectContent>
                      </Select>
                    </LabeledField>

                    <FormActions>
                      <Button variant="outline">Cancel</Button>
                      <Button>Save Changes</Button>
                    </FormActions>
                  </FormSection>
                </PageSection>
              </TabsContent>

              <TabsContent value="tables" className="space-y-6">
                <PageSection title="Table Components" description="Data display with various states">
                  <div className="space-y-8">
                    <Card>
                      <CardHeader>
                        <CardTitle>Data Table</CardTitle>
                        <CardDescription>Interactive table with search and pagination</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <DataTable
                          data={sampleData}
                          columns={tableColumns}
                          searchable
                          searchPlaceholder="Search menu items..."
                        />
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle>Loading State</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <TableSkeleton columns={4} rows={3} />
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle>Empty State</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <TableEmpty
                          title="No menu items found"
                          description="Start by adding your first menu item"
                          icon={<Icons.menu className="h-12 w-12" />}
                          action={{
                            label: "Add Menu Item",
                            onClick: () => console.log("Add item clicked"),
                          }}
                        />
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle>Error State</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <TableError
                          title="Failed to load menu items"
                          description="There was an error loading the menu items. Please try again."
                          onRetry={() => console.log("Retry clicked")}
                        />
                      </CardContent>
                    </Card>
                  </div>
                </PageSection>
              </TabsContent>

              <TabsContent value="navigation" className="space-y-6">
                <PageSection title="Navigation Components" description="Mobile-first navigation patterns">
                  <Card>
                    <CardHeader>
                      <CardTitle>Mobile Bottom Navigation</CardTitle>
                      <CardDescription>Customer-facing mobile navigation</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="relative h-32 overflow-hidden rounded-lg border bg-muted">
                        <div className="absolute inset-x-0 bottom-0">
                          <MobileBottomNav
                            items={mobileNavItems}
                            activeItem="home"
                            onItemClick={(item) => console.log("Mobile nav clicked:", item)}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </PageSection>
              </TabsContent>

              <TabsContent value="accessibility" className="space-y-6">
                <PageSection title="Accessibility Features" description="Built-in accessibility components">
                  <div className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>Screen Reader Support</CardTitle>
                        <CardDescription>Hidden content for screen readers</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Button>
                          <Icons.settings className="h-4 w-4" />
                          <ScreenReaderOnly>Settings</ScreenReaderOnly>
                        </Button>
                        <p className="mt-2 text-sm text-muted-foreground">
                          The button above has hidden text for screen readers
                        </p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle>Focus Management</CardTitle>
                        <CardDescription>Proper focus states and keyboard navigation</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <Button>Focusable Button 1</Button>
                          <Button>Focusable Button 2</Button>
                          <Button>Focusable Button 3</Button>
                        </div>
                        <p className="mt-2 text-sm text-muted-foreground">
                          Try navigating with Tab key to see focus states
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                </PageSection>
              </TabsContent>
            </Tabs>
          </AppContainer>
        </main>
      </div>
    </div>
  )
}
