"use client"

import type React from "react"
import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Icons } from "../icons"
import { TableSkeleton } from "./table-skeleton"
import { TableEmpty } from "./table-empty"
import { TableError } from "./table-error"
import { cn } from "@/lib/utils"

export interface DataTableColumn<T> {
  key: keyof T | string
  title: string
  render?: (value: any, row: T, index: number) => React.ReactNode
  sortable?: boolean
  width?: string
  className?: string
}

interface DataTableProps<T> {
  data: T[]
  columns: DataTableColumn<T>[]
  loading?: boolean
  error?: string | null
  onRetry?: () => void
  searchable?: boolean
  searchPlaceholder?: string
  onSearch?: (query: string) => void
  sortable?: boolean
  onSort?: (key: string, direction: "asc" | "desc") => void
  pagination?: {
    page: number
    pageSize: number
    total: number
    onPageChange: (page: number) => void
    onPageSizeChange: (pageSize: number) => void
  }
  emptyState?: {
    title?: string
    description?: string
    icon?: React.ReactNode
    action?: {
      label: string
      onClick: () => void
    }
  }
  className?: string
}

export function DataTable<T extends Record<string, any>>({
  data,
  columns,
  loading = false,
  error = null,
  onRetry,
  searchable = false,
  searchPlaceholder = "Search...",
  onSearch,
  sortable = false,
  onSort,
  pagination,
  emptyState,
  className,
}: DataTableProps<T>) {
  const [searchQuery, setSearchQuery] = useState("")
  const [sortKey, setSortKey] = useState<string | null>(null)
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc")

  const handleSearch = (query: string) => {
    setSearchQuery(query)
    onSearch?.(query)
  }

  const handleSort = (key: string) => {
    if (!sortable || !onSort) return

    const newDirection = sortKey === key && sortDirection === "asc" ? "desc" : "asc"
    setSortKey(key)
    setSortDirection(newDirection)
    onSort(key, newDirection)
  }

  const renderCellValue = (column: DataTableColumn<T>, row: T, index: number) => {
    const value = typeof column.key === "string" ? row[column.key] : undefined

    if (column.render) {
      return column.render(value, row, index)
    }

    // Default rendering for common types
    if (typeof value === "boolean") {
      return <Badge variant={value ? "default" : "secondary"}>{value ? "Yes" : "No"}</Badge>
    }

    if (value === null || value === undefined) {
      return <span className="text-muted-foreground">—</span>
    }

    return String(value)
  }

  if (loading) {
    return (
      <div className={className}>
        {searchable && (
          <div className="mb-4">
            <Input placeholder={searchPlaceholder} disabled />
          </div>
        )}
        <TableSkeleton columns={columns.length} />
      </div>
    )
  }

  if (error) {
    return (
      <div className={className}>
        <TableError description={error} onRetry={onRetry} />
      </div>
    )
  }

  if (data.length === 0) {
    return (
      <div className={className}>
        {searchable && (
          <div className="mb-4">
            <Input placeholder={searchPlaceholder} value={searchQuery} onChange={(e) => handleSearch(e.target.value)} />
          </div>
        )}
        <TableEmpty {...emptyState} />
      </div>
    )
  }

  return (
    <div className={className}>
      {searchable && (
        <div className="mb-4">
          <Input placeholder={searchPlaceholder} value={searchQuery} onChange={(e) => handleSearch(e.target.value)} />
        </div>
      )}

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              {columns.map((column) => (
                <TableHead key={String(column.key)} className={cn(column.className)} style={{ width: column.width }}>
                  {column.sortable && sortable ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="-ml-3 h-8 data-[state=open]:bg-accent"
                      onClick={() => handleSort(String(column.key))}
                    >
                      <span>{column.title}</span>
                      {sortKey === column.key && (
                        <Icons.menu className={cn("ml-2 h-4 w-4", sortDirection === "desc" && "rotate-180")} />
                      )}
                    </Button>
                  ) : (
                    column.title
                  )}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((row, index) => (
              <TableRow key={index}>
                {columns.map((column) => (
                  <TableCell key={String(column.key)} className={column.className}>
                    {renderCellValue(column, row, index)}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {pagination && (
        <div className="flex items-center justify-between space-x-2 py-4">
          <div className="flex items-center space-x-2">
            <p className="text-sm font-medium">Rows per page</p>
            <Select
              value={`${pagination.pageSize}`}
              onValueChange={(value) => pagination.onPageSizeChange(Number(value))}
            >
              <SelectTrigger className="h-8 w-[70px]">
                <SelectValue placeholder={pagination.pageSize} />
              </SelectTrigger>
              <SelectContent side="top">
                {[10, 20, 30, 40, 50].map((pageSize) => (
                  <SelectItem key={pageSize} value={`${pageSize}`}>
                    {pageSize}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-6 lg:space-x-8">
            <div className="flex w-[100px] items-center justify-center text-sm font-medium">
              Page {pagination.page} of {Math.ceil(pagination.total / pagination.pageSize)}
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                className="h-8 w-8 p-0 bg-transparent"
                onClick={() => pagination.onPageChange(1)}
                disabled={pagination.page <= 1}
              >
                <span className="sr-only">Go to first page</span>
                <Icons.menu className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                className="h-8 w-8 p-0 bg-transparent"
                onClick={() => pagination.onPageChange(pagination.page - 1)}
                disabled={pagination.page <= 1}
              >
                <span className="sr-only">Go to previous page</span>
                <Icons.menu className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                className="h-8 w-8 p-0 bg-transparent"
                onClick={() => pagination.onPageChange(pagination.page + 1)}
                disabled={pagination.page >= Math.ceil(pagination.total / pagination.pageSize)}
              >
                <span className="sr-only">Go to next page</span>
                <Icons.menu className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                className="h-8 w-8 p-0 bg-transparent"
                onClick={() => pagination.onPageChange(Math.ceil(pagination.total / pagination.pageSize))}
                disabled={pagination.page >= Math.ceil(pagination.total / pagination.pageSize)}
              >
                <span className="sr-only">Go to last page</span>
                <Icons.menu className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
