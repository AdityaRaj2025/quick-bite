"use client"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Icons } from "../icons"
import { cn } from "@/lib/utils"

interface TableErrorProps {
  title?: string
  description?: string
  onRetry?: () => void
  className?: string
}

export function TableError({
  title = "Failed to load data",
  description = "There was an error loading the data. Please try again.",
  onRetry,
  className,
}: TableErrorProps) {
  return (
    <div className={cn("py-8", className)}>
      <Alert variant="destructive">
        <Icons.settings className="h-4 w-4" />
        <AlertTitle>{title}</AlertTitle>
        <AlertDescription className="mt-2">
          {description}
          {onRetry && (
            <Button variant="outline" size="sm" onClick={onRetry} className="mt-3 bg-transparent">
              Try again
            </Button>
          )}
        </AlertDescription>
      </Alert>
    </div>
  )
}
