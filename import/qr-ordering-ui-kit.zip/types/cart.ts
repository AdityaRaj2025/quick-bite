export interface CartItemOption {
  optionId: string
  optionName: string
  choiceId: string
  choiceName: string
  priceDelta: number
}

export interface CartItem {
  itemId: string
  name: string
  basePrice: number
  quantity: number
  options: CartItemOption[]
  totalPrice: number
}

export interface CartState {
  items: CartItem[]
  isOpen: boolean
}
