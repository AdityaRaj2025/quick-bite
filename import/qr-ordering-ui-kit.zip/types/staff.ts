export type OrderStatus = "placed" | "acknowledged" | "in_kitchen" | "ready" | "served" | "cancelled"

export interface StaffOrder {
  id: string
  tableCode: string
  tableName: string
  status: OrderStatus
  items: StaffOrderItem[]
  notes?: string
  placedAt: string
  acknowledgedAt?: string
  kitchenAt?: string
  readyAt?: string
  servedAt?: string
  total: number
}

export interface StaffOrderItem {
  id: string
  name: string
  quantity: number
  price: number
  modifiers?: string[]
  notes?: string
  course?: "appetizer" | "main" | "dessert" | "drink"
}

export interface OrderAction {
  type: "acknowledge" | "send_to_kitchen" | "mark_ready" | "mark_served" | "cancel"
  orderId: string
  timestamp: string
}
