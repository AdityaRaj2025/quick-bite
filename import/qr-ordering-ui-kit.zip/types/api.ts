// API Types for QR Ordering System
// These types match the API contracts defined in docs/api-contracts.md

export interface I18nText {
  en: string
  ja: string
  ne: string
  hi: string
}

// Auth Types
export interface SignupRequest {
  email: string
  password: string
  role: "owner" | "manager" | "staff" | "kitchen"
  restaurantName: string
}

export interface LoginRequest {
  email: string
  password: string
}

export interface AuthResponse {
  userId: string
  restaurantId: string
  token: string
  user: User
  restaurant: Restaurant
}

export interface User {
  id: string
  email: string
  role: "owner" | "manager" | "staff" | "kitchen"
  name: string
  restaurantId: string
  isActive: boolean
  createdAt: string
  updatedAt: string
}

export interface Restaurant {
  id: string
  name: string
  status: "onboarding" | "active" | "suspended"
  locale: string
  timezone: string
  settings: {
    taxRate: number
    serviceChargeRate: number
    currency: "JPY"
  }
  createdAt: string
  updatedAt: string
}

// Menu Types
export interface Category {
  id: string
  nameI18n: I18nText
  sortOrder: number
  isActive: boolean
  createdAt: string
  updatedAt: string
}

export interface MenuItem {
  id: string
  categoryId: string
  nameI18n: I18nText
  descriptionI18n?: I18nText
  priceJpy: number
  imageUrl?: string
  allergens: string[]
  badges: string[]
  isActive: boolean
  sortOrder: number
  optionGroups?: string[]
  createdAt: string
  updatedAt: string
}

export interface OptionGroup {
  id: string
  nameI18n: I18nText
  minSelections: number
  maxSelections: number
  options: Option[]
}

export interface Option {
  id: string
  nameI18n: I18nText
  priceDeltaJpy: number
}

export interface MenuResponse {
  restaurant: {
    id: string
    name: string
    locale: string
  }
  categories: Category[]
  items: MenuItem[]
  optionGroups: OptionGroup[]
}

// Table Types
export interface Table {
  id: string
  code: string
  displayName: string
  isActive: boolean
  qrUrl?: string
  createdAt: string
}

export interface CreateTableRequest {
  code: string
  displayName: string
}

export interface QRCodeRequest {
  url: string
  format: "png" | "svg"
  size: number
}

export interface QRCodeResponse {
  dataUrl: string
  format: string
  size: number
}

// Order Types
export interface OrderItem {
  itemId: string
  nameSnapshot: string
  quantity: number
  basePriceJpy: number
  lineTotalJpy: number
  options?: OrderOption[]
}

export interface OrderOption {
  optionId?: string
  nameSnapshot: string
  priceDeltaJpy: number
}

export interface CreateOrderRequest {
  restaurantId: string
  tableCode: string
  locale: string
  items: OrderItem[]
  subtotalJpy: number
  taxJpy: number
  serviceChargeJpy: number
  totalJpy: number
  notes?: string
}

export interface CreateOrderResponse {
  orderId: string
  status: OrderStatus
  estimatedReadyTime: string
  orderNumber: string
  queuePosition: number
}

export type OrderStatus = "placed" | "acknowledged" | "in_kitchen" | "ready" | "served" | "cancelled"

export interface OrderStatusChange {
  status: OrderStatus
  timestamp: string
}

export interface Order {
  id: string
  orderNumber: string
  restaurantId: string
  tableCode: string
  tableName: string
  status: OrderStatus
  items: OrderItem[]
  subtotalJpy: number
  taxJpy: number
  serviceChargeJpy: number
  totalJpy: number
  notes?: string
  timeline: OrderStatusChange[]
  placedAt: string
  readyAt?: string
  servedAt?: string
  customerCount?: number
  estimatedReadyTime?: string
}

export interface UpdateOrderStatusRequest {
  toStatus: OrderStatus
}

export interface UpdateOrderStatusResponse {
  ok: boolean
  orderId: string
  status: OrderStatus
  updatedAt: string
}

// KDS Types
export interface KDSTicket {
  id: string
  orderNumber: string
  tableCode: string
  status: OrderStatus
  items: KDSItem[]
  notes?: string
  placedAt: string
  cookingTime: string
}

export interface KDSItem {
  nameSnapshot: string
  quantity: number
  options?: string[]
  course: string
}

// Print Types
export interface PrintJobRequest {
  restaurantId: string
  orderId: string
  printerType: "kitchen" | "receipt"
}

export interface PrintJobResponse {
  jobId: string
  status: "queued" | "printing" | "completed" | "failed"
  createdAt: string
}

// Error Types
export interface APIError {
  error: {
    code: string
    message: string
    details?: string[]
  }
}

// Pagination Types
export interface PaginationParams {
  page?: number
  limit?: number
  sort?: string
  order?: "asc" | "desc"
}

export interface PaginatedResponse<T> {
  data: T[]
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
    hasNext: boolean
    hasPrev: boolean
  }
}

// Common Request/Response Types
export interface SuccessResponse {
  ok: boolean
}

export interface CreateCategoryRequest {
  nameI18n: I18nText
  sortOrder?: number
}

export interface UpdateCategoryRequest {
  nameI18n?: I18nText
  sortOrder?: number
  isActive?: boolean
}

export interface CreateMenuItemRequest {
  categoryId?: string
  nameI18n: I18nText
  descriptionI18n?: I18nText
  priceJpy: number
  imageUrl?: string
  allergens?: string[]
  badges?: string[]
  sortOrder?: number
  optionGroups?: string[]
}

export interface UpdateMenuItemRequest {
  categoryId?: string
  nameI18n?: I18nText
  descriptionI18n?: I18nText
  priceJpy?: number
  imageUrl?: string
  allergens?: string[]
  badges?: string[]
  isActive?: boolean
  sortOrder?: number
  optionGroups?: string[]
}
