export interface OrderItemOption {
  nameSnapshot: string
  priceDeltaJpy: number
}

export interface OrderItem {
  itemId: string
  nameSnapshot: string
  quantity: number
  basePriceJpy: number
  lineTotalJpy: number
  options?: OrderItemOption[]
}

export interface Order {
  id: string
  restaurantId: string
  tableCode: string
  locale: string
  status: "placed" | "acknowledged" | "in_kitchen" | "ready" | "served"
  items: OrderItem[]
  notes?: string
  subtotalJpy: number
  taxJpy: number
  serviceChargeJpy: number
  totalJpy: number
  createdAt: string
  updatedAt: string
  restaurant?: {
    name: string
  }
}
