export interface Tenant {
  id: string
  restaurantName: string
  plan: "starter" | "professional" | "enterprise"
  status: "active" | "inactive" | "suspended" | "trial"
  lastActive: string
  createdAt: string
  contactEmail: string
  contactName: string
  domain?: string
  environment: "production" | "staging"
  usageMetrics: {
    ordersToday: number
    ordersThisMonth: number
    dailyActiveUsers: number
    monthlyActiveUsers: number
    apiCalls: number
    storageUsed: number // MB
  }
  featureFlags: string[]
  billingInfo: {
    seats: number
    quota: {
      orders: number
      apiCalls: number
      storage: number // MB
    }
    paymentStatus: "paid" | "pending" | "overdue" | "failed"
    nextBillingDate: string
    amount: number
  }
}

export interface UsageData {
  tenantId: string
  date: string
  orders: number
  activeUsers: number
  apiCalls: number
  errors: number
  responseTime: number // ms
}

export interface HealthStatus {
  service: "qr" | "menu" | "order" | "print" | "auth"
  status: "healthy" | "warning" | "critical"
  uptime: number // percentage
  latency: number // ms
  lastIncident?: string
  alertThresholds: {
    latency: number
    errorRate: number
    uptime: number
  }
}

export interface LogEntry {
  id: string
  timestamp: string
  service: string
  tenantId: string
  severity: "info" | "warning" | "error" | "critical"
  message: string
  details?: Record<string, any>
}

export interface BillingRecord {
  tenantId: string
  period: string
  amount: number
  status: "paid" | "pending" | "overdue" | "failed"
  dueDate: string
  items: {
    description: string
    quantity: number
    unitPrice: number
    total: number
  }[]
}
