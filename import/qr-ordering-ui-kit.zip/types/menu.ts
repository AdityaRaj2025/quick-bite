export interface MenuCategory {
  id: string
  name: string
  description?: string
  sortOrder: number
}

export interface MenuItemChoice {
  id: string
  name: string
  priceDelta: number
}

export interface MenuItemOption {
  id: string
  name: string
  description?: string
  required: boolean
  minChoices: number
  maxChoices: number
  choices: MenuItemChoice[]
}

export interface MenuItem {
  id: string
  categoryId: string
  name: string
  description?: string
  basePrice: number
  imageUrl?: string
  badges?: string[]
  options?: MenuItemOption[]
  available: boolean
  sortOrder: number
}

export interface Restaurant {
  id: string
  name: string
  description?: string
}

export interface MenuData {
  restaurant: Restaurant
  categories: MenuCategory[]
  items: MenuItem[]
}
