# QR Ordering System - API Contracts

## Overview

This document defines the REST API contracts for the QR ordering system microservices. These contracts are designed for frontend integration and mocking.

## Common Conventions

### Authentication
- Bearer token in `Authorization` header: `Authorization: Bearer <token>`
- Token obtained from login endpoint

### Internationalization
- i18n fields use object format: `{ en: "English", ja: "日本語", ne: "नेपाली", hi: "हिंदी" }`

### Money
- All monetary values are integers in Japanese Yen (JPY)
- Example: ¥1,500 = `1500`

### Error Responses
\`\`\`json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": ["Email is required", "Password must be at least 8 characters"]
  }
}
\`\`\`

### Common HTTP Status Codes
- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `422` - Validation Error
- `500` - Internal Server Error

---

## 1. Tenant/Auth Service

### POST /api/auth/signup
Register a new restaurant owner and create restaurant.

**Request:**
\`\`\`json
{
  "email": "owner@restaurant.com",
  "password": "securepassword123",
  "role": "owner",
  "restaurantName": "Sakura Sushi"
}
\`\`\`

**Response (201):**
\`\`\`json
{
  "userId": "usr_abc123",
  "restaurantId": "rest_xyz789",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "usr_abc123",
    "email": "owner@restaurant.com",
    "role": "owner",
    "name": "Restaurant Owner"
  },
  "restaurant": {
    "id": "rest_xyz789",
    "name": "Sakura Sushi",
    "status": "onboarding"
  }
}
\`\`\`

### POST /api/auth/login
Authenticate user and get access token.

**Request:**
\`\`\`json
{
  "email": "owner@restaurant.com",
  "password": "securepassword123"
}
\`\`\`

**Response (200):**
\`\`\`json
{
  "userId": "usr_abc123",
  "role": "owner",
  "restaurantId": "rest_xyz789",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "usr_abc123",
    "email": "owner@restaurant.com",
    "role": "owner",
    "name": "Restaurant Owner"
  },
  "restaurant": {
    "id": "rest_xyz789",
    "name": "Sakura Sushi",
    "status": "active"
  }
}
\`\`\`

---

## 2. Menu Service

### GET /api/menu/:restaurantId
Get public menu for customers.

**Response (200):**
\`\`\`json
{
  "restaurant": {
    "id": "rest_xyz789",
    "name": "Sakura Sushi",
    "locale": "ja"
  },
  "categories": [
    {
      "id": "cat_001",
      "nameI18n": {
        "en": "Appetizers",
        "ja": "前菜",
        "ne": "भोजन सुरु",
        "hi": "स्टार्टर"
      },
      "sortOrder": 1,
      "isActive": true
    }
  ],
  "items": [
    {
      "id": "item_001",
      "categoryId": "cat_001",
      "nameI18n": {
        "en": "Pork Gyoza",
        "ja": "豚餃子",
        "ne": "सुँगुरको मोमो",
        "hi": "पोर्क गयोज़ा"
      },
      "descriptionI18n": {
        "en": "Pan-fried pork dumplings with dipping sauce",
        "ja": "焼き豚餃子、タレ付き",
        "ne": "तेलमा भुटेको सुँगुरको मोमो",
        "hi": "तली हुई पोर्क डम्पलिंग"
      },
      "priceJpy": 800,
      "imageUrl": "/images/pork-gyoza.jpg",
      "allergens": ["gluten", "soy"],
      "badges": ["popular"],
      "isActive": true,
      "sortOrder": 1,
      "optionGroups": ["opt_group_001"]
    }
  ],
  "optionGroups": [
    {
      "id": "opt_group_001",
      "nameI18n": {
        "en": "Quantity",
        "ja": "数量",
        "ne": "संख्या",
        "hi": "मात्रा"
      },
      "minSelections": 1,
      "maxSelections": 1,
      "options": [
        {
          "id": "opt_001",
          "nameI18n": {
            "en": "6 pieces",
            "ja": "6個",
            "ne": "६ थान",
            "hi": "6 टुकड़े"
          },
          "priceDeltaJpy": 0
        },
        {
          "id": "opt_002",
          "nameI18n": {
            "en": "12 pieces",
            "ja": "12個",
            "ne": "१२ थान",
            "hi": "12 टुकड़े"
          },
          "priceDeltaJpy": 400
        }
      ]
    }
  ]
}
\`\`\`

### POST /api/admin/:restaurantId/categories
Create new category.

**Headers:** `Authorization: Bearer <token>`

**Request:**
\`\`\`json
{
  "nameI18n": {
    "en": "Desserts",
    "ja": "デザート",
    "ne": "मिठाई",
    "hi": "मिठाई"
  },
  "sortOrder": 5
}
\`\`\`

**Response (201):**
\`\`\`json
{
  "id": "cat_005",
  "nameI18n": {
    "en": "Desserts",
    "ja": "デザート",
    "ne": "मिठाई",
    "hi": "मिठाई"
  },
  "sortOrder": 5,
  "isActive": true,
  "createdAt": "2024-01-15T10:30:00Z",
  "updatedAt": "2024-01-15T10:30:00Z"
}
\`\`\`

### PATCH /api/admin/:restaurantId/categories/:id
Update category.

**Headers:** `Authorization: Bearer <token>`

**Request:**
\`\`\`json
{
  "nameI18n": {
    "en": "Sweet Desserts",
    "ja": "甘いデザート",
    "ne": "मिठो मिठाई",
    "hi": "मीठी मिठाई"
  },
  "isActive": false
}
\`\`\`

**Response (200):**
\`\`\`json
{
  "id": "cat_005",
  "nameI18n": {
    "en": "Sweet Desserts",
    "ja": "甘いデザート",
    "ne": "मिठो मिठाई",
    "hi": "मीठी मिठाई"
  },
  "sortOrder": 5,
  "isActive": false,
  "updatedAt": "2024-01-15T11:45:00Z"
}
\`\`\`

### POST /api/admin/:restaurantId/items
Create new menu item.

**Headers:** `Authorization: Bearer <token>`

**Request:**
\`\`\`json
{
  "categoryId": "cat_005",
  "nameI18n": {
    "en": "Mochi Ice Cream",
    "ja": "もちアイス",
    "ne": "मोची आइसक्रिम",
    "hi": "मोची आइसक्रीम"
  },
  "descriptionI18n": {
    "en": "Traditional Japanese ice cream wrapped in soft mochi",
    "ja": "柔らかいもちに包まれた伝統的な日本のアイスクリーム",
    "ne": "नरम मोचीमा बेरिएको परम्परागत जापानी आइसक्रिम",
    "hi": "नरम मोची में लिपटी पारंपरिक जापानी आइसक्रीम"
  },
  "priceJpy": 600,
  "imageUrl": "/images/mochi-ice-cream.jpg",
  "allergens": ["dairy"],
  "badges": ["vegetarian"],
  "sortOrder": 1
}
\`\`\`

**Response (201):**
\`\`\`json
{
  "id": "item_020",
  "categoryId": "cat_005",
  "nameI18n": {
    "en": "Mochi Ice Cream",
    "ja": "もちアイス",
    "ne": "मोची आइसक्रिम",
    "hi": "मोची आइसक्रीम"
  },
  "descriptionI18n": {
    "en": "Traditional Japanese ice cream wrapped in soft mochi",
    "ja": "柔らかいもちに包まれた伝統的な日本のアイスクリーム",
    "ne": "नरम मोचीमा बेरिएको परम्परागत जापानी आइसक्रिम",
    "hi": "नरम मोची में लिपटी पारंपरिक जापानी आइसक्रीम"
  },
  "priceJpy": 600,
  "imageUrl": "/images/mochi-ice-cream.jpg",
  "allergens": ["dairy"],
  "badges": ["vegetarian"],
  "isActive": true,
  "sortOrder": 1,
  "createdAt": "2024-01-15T12:00:00Z",
  "updatedAt": "2024-01-15T12:00:00Z"
}
\`\`\`

### PATCH /api/admin/:restaurantId/items/:id
Update menu item.

**Headers:** `Authorization: Bearer <token>`

**Request:**
\`\`\`json
{
  "priceJpy": 650,
  "isActive": true,
  "badges": ["vegetarian", "popular"]
}
\`\`\`

**Response (200):**
\`\`\`json
{
  "id": "item_020",
  "categoryId": "cat_005",
  "nameI18n": {
    "en": "Mochi Ice Cream",
    "ja": "もちアイス",
    "ne": "मोची आइसक्रिम",
    "hi": "मोची आइसक्रीम"
  },
  "priceJpy": 650,
  "badges": ["vegetarian", "popular"],
  "isActive": true,
  "updatedAt": "2024-01-15T13:30:00Z"
}
\`\`\`

---

## 3. Table & QR Service

### GET /api/admin/:restaurantId/tables
Get all tables for restaurant.

**Headers:** `Authorization: Bearer <token>`

**Response (200):**
\`\`\`json
[
  {
    "id": "tbl_001",
    "code": "T01",
    "displayName": "Table 1",
    "isActive": true,
    "createdAt": "2024-01-10T09:00:00Z"
  },
  {
    "id": "tbl_002",
    "code": "T02",
    "displayName": "Table 2",
    "isActive": true,
    "createdAt": "2024-01-10T09:00:00Z"
  },
  {
    "id": "tbl_003",
    "code": "BAR01",
    "displayName": "Bar Counter 1",
    "isActive": false,
    "createdAt": "2024-01-10T09:00:00Z"
  }
]
\`\`\`

### POST /api/admin/:restaurantId/tables
Create new table.

**Headers:** `Authorization: Bearer <token>`

**Request:**
\`\`\`json
{
  "code": "T10",
  "displayName": "Table 10"
}
\`\`\`

**Response (201):**
\`\`\`json
{
  "id": "tbl_010",
  "code": "T10",
  "displayName": "Table 10",
  "isActive": true,
  "qrUrl": "https://app.example.com/t/rest_xyz789/T10",
  "createdAt": "2024-01-15T14:00:00Z"
}
\`\`\`

### POST /api/qrcode
Generate QR code for given URL.

**Request:**
\`\`\`json
{
  "url": "https://app.example.com/t/rest_xyz789/T01?lang=ja",
  "format": "png",
  "size": 256
}
\`\`\`

**Response (200):**
\`\`\`json
{
  "dataUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEA...",
  "format": "png",
  "size": 256
}
\`\`\`

---

## 4. Order Service

### POST /api/orders
Create new order from customer.

**Request:**
\`\`\`json
{
  "restaurantId": "rest_xyz789",
  "tableCode": "T01",
  "locale": "ja",
  "items": [
    {
      "itemId": "item_001",
      "nameSnapshot": "Pork Gyoza",
      "quantity": 2,
      "basePriceJpy": 800,
      "lineTotalJpy": 1600,
      "options": [
        {
          "optionId": "opt_001",
          "nameSnapshot": "6 pieces",
          "priceDeltaJpy": 0
        }
      ]
    },
    {
      "itemId": "item_015",
      "nameSnapshot": "Salmon Sashimi",
      "quantity": 1,
      "basePriceJpy": 1200,
      "lineTotalJpy": 1200
    }
  ],
  "subtotalJpy": 2800,
  "taxJpy": 280,
  "serviceChargeJpy": 140,
  "totalJpy": 3220,
  "notes": "No wasabi please"
}
\`\`\`

**Response (201):**
\`\`\`json
{
  "orderId": "ord_abc123",
  "status": "placed",
  "estimatedReadyTime": "2024-01-15T15:30:00Z",
  "orderNumber": "A001",
  "queuePosition": 3
}
\`\`\`

### GET /api/orders/active/:restaurantId
Get active orders for restaurant (staff/kitchen view).

**Headers:** `Authorization: Bearer <token>`

**Response (200):**
\`\`\`json
[
  {
    "id": "ord_abc123",
    "orderNumber": "A001",
    "status": "placed",
    "tableCode": "T01",
    "tableName": "Table 1",
    "customerCount": 2,
    "items": [
      {
        "id": "item_001",
        "nameSnapshot": "Pork Gyoza",
        "quantity": 2,
        "basePriceJpy": 800,
        "lineTotalJpy": 1600,
        "options": [
          {
            "nameSnapshot": "6 pieces",
            "priceDeltaJpy": 0
          }
        ]
      }
    ],
    "subtotalJpy": 2800,
    "totalJpy": 3220,
    "notes": "No wasabi please",
    "placedAt": "2024-01-15T15:00:00Z",
    "estimatedReadyTime": "2024-01-15T15:30:00Z"
  }
]
\`\`\`

### POST /api/orders/:id/status
Update order status.

**Headers:** `Authorization: Bearer <token>`

**Request:**
\`\`\`json
{
  "toStatus": "in_kitchen"
}
\`\`\`

**Response (200):**
\`\`\`json
{
  "ok": true,
  "orderId": "ord_abc123",
  "status": "in_kitchen",
  "updatedAt": "2024-01-15T15:05:00Z"
}
\`\`\`

### GET /api/orders/:id
Get specific order details.

**Response (200):**
\`\`\`json
{
  "id": "ord_abc123",
  "orderNumber": "A001",
  "status": "ready",
  "tableCode": "T01",
  "tableName": "Table 1",
  "items": [
    {
      "id": "item_001",
      "nameSnapshot": "Pork Gyoza",
      "quantity": 2,
      "basePriceJpy": 800,
      "lineTotalJpy": 1600,
      "options": [
        {
          "nameSnapshot": "6 pieces",
          "priceDeltaJpy": 0
        }
      ]
    }
  ],
  "subtotalJpy": 2800,
  "taxJpy": 280,
  "serviceChargeJpy": 140,
  "totalJpy": 3220,
  "notes": "No wasabi please",
  "timeline": [
    {
      "status": "placed",
      "timestamp": "2024-01-15T15:00:00Z"
    },
    {
      "status": "acknowledged",
      "timestamp": "2024-01-15T15:02:00Z"
    },
    {
      "status": "in_kitchen",
      "timestamp": "2024-01-15T15:05:00Z"
    },
    {
      "status": "ready",
      "timestamp": "2024-01-15T15:25:00Z"
    }
  ],
  "placedAt": "2024-01-15T15:00:00Z",
  "readyAt": "2024-01-15T15:25:00Z"
}
\`\`\`

---

## 5. Print/KDS Service (Optional)

### GET /api/kds/tickets/:restaurantId
Get tickets for kitchen display.

**Headers:** `Authorization: Bearer <token>`

**Response (200):**
\`\`\`json
[
  {
    "id": "ord_abc123",
    "orderNumber": "A001",
    "tableCode": "T01",
    "status": "in_kitchen",
    "items": [
      {
        "nameSnapshot": "Pork Gyoza",
        "quantity": 2,
        "options": ["6 pieces"],
        "course": "appetizer"
      },
      {
        "nameSnapshot": "Salmon Sashimi",
        "quantity": 1,
        "course": "sashimi"
      }
    ],
    "notes": "No wasabi please",
    "placedAt": "2024-01-15T15:00:00Z",
    "cookingTime": "00:25:00"
  }
]
\`\`\`

### POST /api/print-jobs
Send order to printer.

**Headers:** `Authorization: Bearer <token>`

**Request:**
\`\`\`json
{
  "restaurantId": "rest_xyz789",
  "orderId": "ord_abc123",
  "printerType": "kitchen"
}
\`\`\`

**Response (201):**
\`\`\`json
{
  "jobId": "job_print_001",
  "status": "queued",
  "createdAt": "2024-01-15T15:00:00Z"
}
\`\`\`

---

## Data Models

### User
\`\`\`typescript
interface User {
  id: string;
  email: string;
  role: 'owner' | 'manager' | 'staff' | 'kitchen';
  name: string;
  restaurantId: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}
\`\`\`

### Restaurant
\`\`\`typescript
interface Restaurant {
  id: string;
  name: string;
  status: 'onboarding' | 'active' | 'suspended';
  locale: string;
  timezone: string;
  settings: {
    taxRate: number; // 0.10 for 10%
    serviceChargeRate: number; // 0.05 for 5%
    currency: 'JPY';
  };
  createdAt: string;
  updatedAt: string;
}
\`\`\`

### Category
\`\`\`typescript
interface Category {
  id: string;
  nameI18n: I18nText;
  sortOrder: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}
\`\`\`

### MenuItem
\`\`\`typescript
interface MenuItem {
  id: string;
  categoryId: string;
  nameI18n: I18nText;
  descriptionI18n?: I18nText;
  priceJpy: number;
  imageUrl?: string;
  allergens: string[];
  badges: string[];
  isActive: boolean;
  sortOrder: number;
  optionGroups?: string[];
  createdAt: string;
  updatedAt: string;
}
\`\`\`

### Order
\`\`\`typescript
interface Order {
  id: string;
  orderNumber: string;
  restaurantId: string;
  tableCode: string;
  tableName: string;
  status: 'placed' | 'acknowledged' | 'in_kitchen' | 'ready' | 'served' | 'cancelled';
  items: OrderItem[];
  subtotalJpy: number;
  taxJpy: number;
  serviceChargeJpy: number;
  totalJpy: number;
  notes?: string;
  timeline: OrderStatusChange[];
  placedAt: string;
  readyAt?: string;
  servedAt?: string;
}
\`\`\`

### I18nText
\`\`\`typescript
interface I18nText {
  en: string;
  ja: string;
  ne: string;
  hi: string;
}
\`\`\`

---

## Error Codes

| Code | Description |
|------|-------------|
| `VALIDATION_ERROR` | Request validation failed |
| `UNAUTHORIZED` | Authentication required |
| `FORBIDDEN` | Insufficient permissions |
| `NOT_FOUND` | Resource not found |
| `DUPLICATE_ERROR` | Resource already exists |
| `BUSINESS_RULE_ERROR` | Business logic violation |
| `RATE_LIMIT_ERROR` | Too many requests |
| `INTERNAL_ERROR` | Server error |

---

## Rate Limiting

- Customer endpoints: 100 requests per minute per IP
- Admin endpoints: 1000 requests per minute per user
- Auth endpoints: 10 requests per minute per IP

---

## Pagination

For list endpoints that return large datasets:

**Query Parameters:**
- `page` - Page number (default: 1)
- `limit` - Items per page (default: 20, max: 100)
- `sort` - Sort field (default: `createdAt`)
- `order` - Sort order: `asc` or `desc` (default: `desc`)

**Response Format:**
\`\`\`json
{
  "data": [...],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "totalPages": 8,
    "hasNext": true,
    "hasPrev": false
  }
}
