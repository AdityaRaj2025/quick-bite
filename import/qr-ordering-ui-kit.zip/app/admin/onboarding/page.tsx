import { OnboardingWizard } from "@/components/admin/onboarding/onboarding-wizard"

export default function OnboardingPage() {
  return <OnboardingWizard />
}
