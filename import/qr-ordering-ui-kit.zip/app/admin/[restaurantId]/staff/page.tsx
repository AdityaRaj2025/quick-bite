import { StaffManagement } from "@/components/admin/staff/staff-management"

export default function StaffPage({
  params,
}: {
  params: { restaurantId: string }
}) {
  return <StaffManagement restaurantId={params.restaurantId} />
}
