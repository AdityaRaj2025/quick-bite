import { MenuManagement } from "@/components/admin/menu/menu-management"

export default function MenuPage({
  params,
}: {
  params: { restaurantId: string }
}) {
  return <MenuManagement restaurantId={params.restaurantId} />
}
