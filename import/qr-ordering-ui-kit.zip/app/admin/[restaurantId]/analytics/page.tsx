import { AnalyticsDashboard } from "@/components/admin/analytics/analytics-dashboard"

export default function AnalyticsPage({
  params,
}: {
  params: { restaurantId: string }
}) {
  return <AnalyticsDashboard restaurantId={params.restaurantId} />
}
