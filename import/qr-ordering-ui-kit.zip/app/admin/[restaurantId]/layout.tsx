import type React from "react"
import { AdminShell } from "@/components/admin/admin-shell"
import { I18nProvider } from "@/lib/i18n"

export default function AdminLayout({
  children,
  params,
}: {
  children: React.ReactNode
  params: { restaurantId: string }
}) {
  return (
    <I18nProvider>
      <AdminShell restaurantId={params.restaurantId}>{children}</AdminShell>
    </I18nProvider>
  )
}
