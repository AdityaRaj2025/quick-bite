import { CategoriesManagement } from "@/components/admin/menu/categories-management"

export default function CategoriesPage({
  params,
}: {
  params: { restaurantId: string }
}) {
  return <CategoriesManagement restaurantId={params.restaurantId} />
}
