import { PrintersManagement } from "@/components/admin/printers/printers-management"

export default function PrintersPage({
  params,
}: {
  params: { restaurantId: string }
}) {
  return <PrintersManagement restaurantId={params.restaurantId} />
}
