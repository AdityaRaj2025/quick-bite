import { TablesManagement } from "@/components/admin/tables/tables-management"

export default function TablesPage({
  params,
}: {
  params: { restaurantId: string }
}) {
  return <TablesManagement restaurantId={params.restaurantId} />
}
