import { RestaurantSettings } from "@/components/admin/settings/restaurant-settings"

export default function SettingsPage({
  params,
}: {
  params: { restaurantId: string }
}) {
  return <RestaurantSettings restaurantId={params.restaurantId} />
}
