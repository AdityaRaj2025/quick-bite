import { AdminDashboard } from "@/components/admin/admin-dashboard"

export default function AdminDashboardPage({
  params,
}: {
  params: { restaurantId: string }
}) {
  return <AdminDashboard restaurantId={params.restaurantId} />
}
