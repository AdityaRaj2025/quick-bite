import { OptionsManagement } from "@/components/admin/menu/options-management"

export default function OptionsPage({
  params,
}: {
  params: { restaurantId: string }
}) {
  return <OptionsManagement restaurantId={params.restaurantId} />
}
