import { redirect } from "next/navigation"

export default function OperatorPage() {
  redirect("/operator/tenants")
}
