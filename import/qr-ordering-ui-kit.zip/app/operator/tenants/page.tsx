import { TenantsManagement } from "@/components/operator/tenants-management"

export default function TenantsPage() {
  return <TenantsManagement />
}
