import { BillingManagement } from "@/components/operator/billing-management"

export default function BillingPage() {
  return <BillingManagement />
}
