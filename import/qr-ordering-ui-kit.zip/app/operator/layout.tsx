import type React from "react"
import { Inter } from "next/font/google"
import { OperatorShell } from "@/components/operator/operator-shell"

const inter = Inter({ subsets: ["latin"] })

export default function OperatorLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className={`${inter.className} antialiased`}>
      <OperatorShell>{children}</OperatorShell>
    </div>
  )
}
