import { UsageAnalytics } from "@/components/operator/usage-analytics"

export default function UsagePage() {
  return <UsageAnalytics />
}
