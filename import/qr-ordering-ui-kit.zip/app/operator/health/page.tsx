import { HealthMonitoring } from "@/components/operator/health-monitoring"

export default function HealthPage() {
  return <HealthMonitoring />
}
