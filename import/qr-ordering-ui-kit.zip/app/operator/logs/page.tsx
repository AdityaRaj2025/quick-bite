import { LogsViewer } from "@/components/operator/logs-viewer"

export default function LogsPage() {
  return <LogsViewer />
}
