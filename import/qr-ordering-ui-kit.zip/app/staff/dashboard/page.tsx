import { StaffDashboard } from "@/components/staff/staff-dashboard"

export default function StaffDashboardPage() {
  return <StaffDashboard />
}
