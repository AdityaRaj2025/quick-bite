import { MenuPage } from "@/components/customer/menu-page"

interface MenuPageProps {
  params: {
    restaurantId: string
    tableCode: string
  }
}

export default function CustomerMenuPage({ params }: MenuPageProps) {
  return <MenuPage restaurantId={params.restaurantId} tableCode={params.tableCode} />
}

export async function generateMetadata({ params }: MenuPageProps) {
  return {
    title: `Menu - Table ${params.tableCode}`,
    description: "Browse our menu and place your order",
    viewport: "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no",
  }
}
