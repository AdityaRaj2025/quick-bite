import { OrderStatusPage } from "@/components/customer/order-status-page"

interface OrderStatusPageProps {
  params: {
    orderId: string
  }
}

export default function CustomerOrderStatusPage({ params }: OrderStatusPageProps) {
  return <OrderStatusPage orderId={params.orderId} />
}

export async function generateMetadata({ params }: OrderStatusPageProps) {
  return {
    title: `Order Status - ${params.orderId}`,
    description: "Track your order status",
    viewport: "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no",
  }
}
