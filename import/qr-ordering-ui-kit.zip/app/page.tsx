import { UIShowcase } from "@/lib/ui/examples/ui-showcase"

export default function HomePage() {
  return <UIShowcase />
}
