import { KDSInterface } from "@/components/staff/kds-interface"

export default function KDSPage() {
  return <KDSInterface />
}
