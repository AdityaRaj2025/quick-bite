"use client"

import { useState, useEffect } from "react"
import type { MenuData } from "@/types/menu"

interface UseMenuResult {
  data: MenuData | null
  loading: boolean
  error: string | null
}

// Mock menu data
const mockMenuData: MenuData = {
  restaurant: {
    id: "rest-1",
    name: "Sakura Sushi & Grill",
    description: "Authentic Japanese cuisine with modern flair",
  },
  categories: [
    {
      id: "appetizers",
      name: "Appetizers",
      description: "Start your meal with our delicious appetizers",
      sortOrder: 1,
    },
    {
      id: "sushi",
      name: "Sushi & Sashimi",
      description: "Fresh fish prepared by our expert chefs",
      sortOrder: 2,
    },
    {
      id: "mains",
      name: "Main Dishes",
      description: "Hearty dishes to satisfy your appetite",
      sortOrder: 3,
    },
    {
      id: "desserts",
      name: "Desserts",
      description: "Sweet endings to your meal",
      sortOrder: 4,
    },
  ],
  items: [
    // Appetizers
    {
      id: "gyoza",
      categoryId: "appetizers",
      name: "Pork Gyoza",
      description: "Pan-fried dumplings with savory pork filling",
      basePrice: 680,
      imageUrl: "/pork-gyoza.png",
      badges: [],
      available: true,
      sortOrder: 1,
    },
    {
      id: "edamame",
      categoryId: "appetizers",
      name: "Edamame",
      description: "Steamed young soybeans with sea salt",
      basePrice: 420,
      imageUrl: "/edamame-soybeans.png",
      badges: ["vegan"],
      available: true,
      sortOrder: 2,
    },
    // Sushi
    {
      id: "salmon-sashimi",
      categoryId: "sushi",
      name: "Salmon Sashimi",
      description: "Fresh Atlantic salmon, 6 pieces",
      basePrice: 1280,
      imageUrl: "/salmon-sashimi.png",
      badges: [],
      available: true,
      sortOrder: 1,
    },
    {
      id: "spicy-tuna-roll",
      categoryId: "sushi",
      name: "Spicy Tuna Roll",
      description: "Tuna, spicy mayo, cucumber, sesame seeds",
      basePrice: 980,
      imageUrl: "/spicy-tuna-roll.png",
      badges: ["spicy"],
      available: true,
      sortOrder: 2,
    },
    // Mains
    {
      id: "chicken-teriyaki",
      categoryId: "mains",
      name: "Chicken Teriyaki",
      description: "Grilled chicken with teriyaki glaze, served with rice",
      basePrice: 1480,
      imageUrl: "/chicken-teriyaki-rice.png",
      badges: [],
      available: true,
      sortOrder: 1,
      options: [
        {
          id: "rice-type",
          name: "Rice Type",
          description: "Choose your preferred rice",
          required: true,
          minChoices: 1,
          maxChoices: 1,
          choices: [
            { id: "white-rice", name: "White Rice", priceDelta: 0 },
            { id: "brown-rice", name: "Brown Rice", priceDelta: 100 },
            { id: "fried-rice", name: "Fried Rice", priceDelta: 200 },
          ],
        },
        {
          id: "extras",
          name: "Extras",
          description: "Add extra items",
          required: false,
          minChoices: 0,
          maxChoices: 3,
          choices: [
            { id: "extra-sauce", name: "Extra Teriyaki Sauce", priceDelta: 50 },
            { id: "vegetables", name: "Steamed Vegetables", priceDelta: 150 },
            { id: "miso-soup", name: "Miso Soup", priceDelta: 200 },
          ],
        },
      ],
    },
    {
      id: "beef-ramen",
      categoryId: "mains",
      name: "Beef Ramen",
      description: "Rich tonkotsu broth with tender beef and fresh noodles",
      basePrice: 1680,
      imageUrl: "/placeholder-i8mwe.png",
      badges: ["spicy"],
      available: true,
      sortOrder: 2,
      options: [
        {
          id: "spice-level",
          name: "Spice Level",
          required: true,
          minChoices: 1,
          maxChoices: 1,
          choices: [
            { id: "mild", name: "Mild", priceDelta: 0 },
            { id: "medium", name: "Medium", priceDelta: 0 },
            { id: "hot", name: "Hot", priceDelta: 0 },
            { id: "extra-hot", name: "Extra Hot", priceDelta: 0 },
          ],
        },
      ],
    },
    // Desserts
    {
      id: "mochi-ice-cream",
      categoryId: "desserts",
      name: "Mochi Ice Cream",
      description: "Sweet rice cake filled with ice cream, 3 pieces",
      basePrice: 580,
      imageUrl: "/mochi-ice-cream.png",
      badges: [],
      available: true,
      sortOrder: 1,
      options: [
        {
          id: "flavors",
          name: "Flavors",
          description: "Choose your flavors (3 pieces)",
          required: true,
          minChoices: 1,
          maxChoices: 3,
          choices: [
            { id: "vanilla", name: "Vanilla", priceDelta: 0 },
            { id: "strawberry", name: "Strawberry", priceDelta: 0 },
            { id: "green-tea", name: "Green Tea", priceDelta: 0 },
            { id: "red-bean", name: "Red Bean", priceDelta: 50 },
          ],
        },
      ],
    },
  ],
}

export function useMenu(restaurantId: string): UseMenuResult {
  const [data, setData] = useState<MenuData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchMenu = async () => {
      setLoading(true)
      setError(null)

      try {
        // Simulate API call delay
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Mock API call
        // const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/menu/${restaurantId}`)
        // const menuData = await response.json()

        // For now, return mock data
        setData(mockMenuData)
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load menu")
      } finally {
        setLoading(false)
      }
    }

    if (restaurantId) {
      fetchMenu()
    }
  }, [restaurantId])

  return { data, loading, error }
}
