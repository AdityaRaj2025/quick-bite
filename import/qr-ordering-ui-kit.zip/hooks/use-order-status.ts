"use client"

import { useState, useEffect, useCallback } from "react"
import type { Order } from "@/types/order"

interface UseOrderStatusResult {
  data: Order | null
  loading: boolean
  error: string | null
  refetch: () => void
}

// Mock order data
const createMockOrder = (orderId: string): Order => ({
  id: orderId,
  restaurantId: "rest-1",
  tableCode: "A12",
  locale: "en",
  status: "in_kitchen",
  items: [
    {
      itemId: "chicken-teriyaki",
      nameSnapshot: "Chicken Teriyaki",
      quantity: 1,
      basePriceJpy: 1480,
      lineTotalJpy: 1630,
      options: [
        { nameSnapshot: "Brown Rice", priceDeltaJpy: 100 },
        { nameSnapshot: "Extra Teriyaki Sauce", priceDeltaJpy: 50 },
      ],
    },
    {
      itemId: "gyoza",
      nameSnapshot: "Pork Gyoza",
      quantity: 2,
      basePriceJpy: 680,
      lineTotalJpy: 1360,
    },
    {
      itemId: "mochi-ice-cream",
      nameSnapshot: "Mochi Ice Cream",
      quantity: 1,
      basePriceJpy: 580,
      lineTotalJpy: 580,
    },
  ],
  notes: "Please make the chicken extra crispy. No onions in the gyoza.",
  subtotalJpy: 3570,
  taxJpy: 357,
  serviceChargeJpy: 0,
  totalJpy: 3927,
  createdAt: new Date(Date.now() - 25 * 60 * 1000).toISOString(), // 25 minutes ago
  updatedAt: new Date(Date.now() - 10 * 60 * 1000).toISOString(), // 10 minutes ago
  restaurant: {
    name: "Sakura Sushi & Grill",
  },
})

const statusProgression = ["placed", "acknowledged", "in_kitchen", "ready", "served"] as const

export function useOrderStatus(orderId: string): UseOrderStatusResult {
  const [data, setData] = useState<Order | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchOrderStatus = useCallback(async () => {
    if (!orderId) return

    try {
      setError(null)

      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 500))

      // Mock API call
      // const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/orders/${orderId}`)
      // const orderData = await response.json()

      // For demo purposes, simulate status progression over time
      const mockOrder = createMockOrder(orderId)
      const orderAge = Date.now() - new Date(mockOrder.createdAt).getTime()
      const minutesOld = Math.floor(orderAge / (1000 * 60))

      // Progress status based on order age
      let currentStatus = "placed"
      if (minutesOld >= 2) currentStatus = "acknowledged"
      if (minutesOld >= 5) currentStatus = "in_kitchen"
      if (minutesOld >= 20) currentStatus = "ready"
      if (minutesOld >= 30) currentStatus = "served"

      const updatedOrder = {
        ...mockOrder,
        status: currentStatus as Order["status"],
        updatedAt: new Date().toISOString(),
      }

      setData(updatedOrder)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load order status")
    } finally {
      setLoading(false)
    }
  }, [orderId])

  const refetch = useCallback(() => {
    setLoading(true)
    fetchOrderStatus()
  }, [fetchOrderStatus])

  // Initial fetch
  useEffect(() => {
    fetchOrderStatus()
  }, [fetchOrderStatus])

  // Polling for live updates (every 30 seconds)
  useEffect(() => {
    if (!data || data.status === "served") return

    const interval = setInterval(() => {
      fetchOrderStatus()
    }, 30000) // 30 seconds

    return () => clearInterval(interval)
  }, [data, fetchOrderStatus])

  return { data, loading, error, refetch }
}
