"use client"

import { useState, useEffect, useCallback } from "react"
import type { StaffOrder, OrderStatus } from "@/types/staff"

// Mock data for development
const mockOrders: StaffOrder[] = [
  {
    id: "1",
    tableCode: "T01",
    tableName: "Table 1",
    status: "placed",
    items: [
      { id: "1", name: "Pork Gyoza", quantity: 2, price: 8.5, course: "appetizer" },
      { id: "2", name: "Chicken Teriyaki Rice", quantity: 1, price: 14.5, modifiers: ["Extra sauce"], course: "main" },
    ],
    notes: "Customer has nut allergy",
    placedAt: new Date(Date.now() - 5 * 60000).toISOString(),
    total: 31.5,
  },
  {
    id: "2",
    tableCode: "T03",
    tableName: "Table 3",
    status: "in_kitchen",
    items: [
      { id: "3", name: "Salmon Sashimi", quantity: 1, price: 16.0, course: "appetizer" },
      { id: "4", name: "Spicy Tuna Roll", quantity: 2, price: 12.0, course: "main" },
    ],
    placedAt: new Date(Date.now() - 15 * 60000).toISOString(),
    acknowledgedAt: new Date(Date.now() - 12 * 60000).toISOString(),
    kitchenAt: new Date(Date.now() - 10 * 60000).toISOString(),
    total: 40.0,
  },
  {
    id: "3",
    tableCode: "T05",
    tableName: "Table 5",
    status: "ready",
    items: [
      { id: "5", name: "Edamame", quantity: 1, price: 5.5, course: "appetizer" },
      { id: "6", name: "Mochi Ice Cream", quantity: 3, price: 6.0, course: "dessert" },
    ],
    placedAt: new Date(Date.now() - 25 * 60000).toISOString(),
    acknowledgedAt: new Date(Date.now() - 22 * 60000).toISOString(),
    kitchenAt: new Date(Date.now() - 20 * 60000).toISOString(),
    readyAt: new Date(Date.now() - 2 * 60000).toISOString(),
    total: 23.5,
  },
]

export function useStaffOrders(restaurantId?: string, pollingInterval = 30000) {
  const [orders, setOrders] = useState<StaffOrder[]>(mockOrders)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [lastFetch, setLastFetch] = useState<number>(0)

  const debouncedFetch = useCallback(
    (() => {
      let timeoutId: NodeJS.Timeout
      return () => {
        clearTimeout(timeoutId)
        timeoutId = setTimeout(() => {
          const now = Date.now()
          // Only fetch if enough time has passed since last fetch
          if (now - lastFetch > 5000) {
            fetchOrders()
          }
        }, 1000)
      }
    })(),
    [lastFetch],
  )

  // Mock API call
  const fetchOrders = async () => {
    setLoading(true)
    try {
      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 500))

      const shouldAddNewOrder = Math.random() < 0.1 // 10% chance
      let updatedOrders = [...mockOrders]

      if (shouldAddNewOrder) {
        const newOrder: StaffOrder = {
          id: `new-${Date.now()}`,
          tableCode: `T${Math.floor(Math.random() * 20) + 1}`,
          tableName: `Table ${Math.floor(Math.random() * 20) + 1}`,
          status: "placed",
          items: [{ id: "new", name: "New Order Item", quantity: 1, price: 12.0, course: "main" }],
          placedAt: new Date().toISOString(),
          total: 12.0,
        }
        updatedOrders = [newOrder, ...updatedOrders]
      }

      setOrders(updatedOrders)
      setError(null)
      setLastFetch(Date.now())
    } catch (err) {
      setError("Failed to fetch orders")
    } finally {
      setLoading(false)
    }
  }

  // Mock order status update
  const updateOrderStatus = async (orderId: string, newStatus: OrderStatus) => {
    try {
      setOrders((prev) =>
        prev.map((order) => {
          if (order.id === orderId) {
            const now = new Date().toISOString()
            const updates: Partial<StaffOrder> = { status: newStatus }

            switch (newStatus) {
              case "acknowledged":
                updates.acknowledgedAt = now
                break
              case "in_kitchen":
                updates.kitchenAt = now
                break
              case "ready":
                updates.readyAt = now
                break
              case "served":
                updates.servedAt = now
                break
            }

            return { ...order, ...updates }
          }
          return order
        }),
      )
    } catch (err) {
      setError("Failed to update order status")
    }
  }

  useEffect(() => {
    const interval = setInterval(debouncedFetch, pollingInterval)
    return () => clearInterval(interval)
  }, [debouncedFetch, pollingInterval])

  // Initial fetch
  useEffect(() => {
    fetchOrders()
  }, [restaurantId])

  const ordersByStatus = {
    placed: orders.filter((o) => o.status === "placed"),
    acknowledged: orders.filter((o) => o.status === "acknowledged"),
    in_kitchen: orders.filter((o) => o.status === "in_kitchen"),
    ready: orders.filter((o) => o.status === "ready"),
    served: orders.filter((o) => o.status === "served"),
    cancelled: orders.filter((o) => o.status === "cancelled"),
  }

  return {
    orders,
    ordersByStatus,
    loading,
    error,
    updateOrderStatus,
    refetch: fetchOrders,
    debouncedRefetch: debouncedFetch,
  }
}
