"use client"

import { useState, useEffect, useCallback } from "react"
import type { CartItem, CartItemOption } from "@/types/cart"

interface UseCartResult {
  items: CartItem[]
  isOpen: boolean
  setIsOpen: (open: boolean) => void
  addItem: (item: Omit<CartItem, "id">) => void
  removeItem: (itemId: string, options: CartItemOption[]) => void
  updateItemQuantity: (itemId: string, options: CartItemOption[], quantity: number) => void
  clearCart: () => void
  getTotalItems: () => number
  getTotalPrice: () => number
}

const CART_STORAGE_KEY = "qr-ordering-cart"

export function useCart(): UseCartResult {
  const [items, setItems] = useState<CartItem[]>([])
  const [isOpen, setIsOpen] = useState(false)

  // Load cart from localStorage on mount
  useEffect(() => {
    try {
      const savedCart = localStorage.getItem(CART_STORAGE_KEY)
      if (savedCart) {
        setItems(JSON.parse(savedCart))
      }
    } catch (error) {
      console.error("Failed to load cart from localStorage:", error)
    }
  }, [])

  // Save cart to localStorage whenever items change
  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items))
    } catch (error) {
      console.error("Failed to save cart to localStorage:", error)
    }
  }, [items])

  // Generate a unique key for cart items based on itemId and options
  const getItemKey = useCallback((itemId: string, options: CartItemOption[]) => {
    const optionsKey = options
      .sort((a, b) => a.optionId.localeCompare(b.optionId))
      .map((opt) => `${opt.optionId}:${opt.choiceId}`)
      .join("|")
    return `${itemId}${optionsKey ? `|${optionsKey}` : ""}`
  }, [])

  const addItem = useCallback(
    (newItem: Omit<CartItem, "id">) => {
      setItems((currentItems) => {
        const itemKey = getItemKey(newItem.itemId, newItem.options)
        const existingItemIndex = currentItems.findIndex((item) => getItemKey(item.itemId, item.options) === itemKey)

        if (existingItemIndex >= 0) {
          // Update existing item quantity
          const updatedItems = [...currentItems]
          const existingItem = updatedItems[existingItemIndex]
          updatedItems[existingItemIndex] = {
            ...existingItem,
            quantity: existingItem.quantity + newItem.quantity,
            totalPrice: (existingItem.quantity + newItem.quantity) * (newItem.totalPrice / newItem.quantity),
          }
          return updatedItems
        } else {
          // Add new item
          return [...currentItems, newItem]
        }
      })
    },
    [getItemKey],
  )

  const removeItem = useCallback(
    (itemId: string, options: CartItemOption[]) => {
      setItems((currentItems) => {
        const itemKey = getItemKey(itemId, options)
        return currentItems.filter((item) => getItemKey(item.itemId, item.options) !== itemKey)
      })
    },
    [getItemKey],
  )

  const updateItemQuantity = useCallback(
    (itemId: string, options: CartItemOption[], quantity: number) => {
      if (quantity <= 0) {
        removeItem(itemId, options)
        return
      }

      setItems((currentItems) => {
        const itemKey = getItemKey(itemId, options)
        return currentItems.map((item) => {
          if (getItemKey(item.itemId, item.options) === itemKey) {
            const pricePerItem = item.totalPrice / item.quantity
            return {
              ...item,
              quantity,
              totalPrice: quantity * pricePerItem,
            }
          }
          return item
        })
      })
    },
    [getItemKey, removeItem],
  )

  const clearCart = useCallback(() => {
    setItems([])
  }, [])

  const getTotalItems = useCallback(() => {
    return items.reduce((total, item) => total + item.quantity, 0)
  }, [items])

  const getTotalPrice = useCallback(() => {
    return items.reduce((total, item) => total + item.totalPrice, 0)
  }, [items])

  return {
    items,
    isOpen,
    setIsOpen,
    addItem,
    removeItem,
    updateItemQuantity,
    clearCart,
    getTotalItems,
    getTotalPrice,
  }
}
